self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "025e125291aaa8475d734d1d7f31c97a",
    "url": "/index.html"
  },
  {
    "revision": "abd5874ff19c50827414",
    "url": "/static/css/14.9ba107ea.chunk.css"
  },
  {
    "revision": "8c4829542eb29d85b1eb",
    "url": "/static/css/main.ba93368c.chunk.css"
  },
  {
    "revision": "f899a5edff913af5fd8d",
    "url": "/static/js/0.885d23f7.chunk.js"
  },
  {
    "revision": "9644cd68ab61318661b1",
    "url": "/static/js/1.4041e47d.chunk.js"
  },
  {
    "revision": "f453f61d38aa2b0b660a",
    "url": "/static/js/10.19de0bbf.chunk.js"
  },
  {
    "revision": "d856ad0385340e069de2",
    "url": "/static/js/11.08217197.chunk.js"
  },
  {
    "revision": "abd5874ff19c50827414",
    "url": "/static/js/14.a3c5c97d.chunk.js"
  },
  {
    "revision": "d3362a48fe4e7921a522",
    "url": "/static/js/15.adab6606.chunk.js"
  },
  {
    "revision": "1dccab9facd4e6754a19",
    "url": "/static/js/16.b1f2f418.chunk.js"
  },
  {
    "revision": "8697ab368b9687882631",
    "url": "/static/js/17.9f2ffea5.chunk.js"
  },
  {
    "revision": "273fc441df28e70904d0",
    "url": "/static/js/18.a4fdd0ce.chunk.js"
  },
  {
    "revision": "53b5251c97c50fea43a3",
    "url": "/static/js/19.18255657.chunk.js"
  },
  {
    "revision": "7c8b064e75c7780a4856",
    "url": "/static/js/2.d15e97bb.chunk.js"
  },
  {
    "revision": "9d4c7b6e813bb8f3d928",
    "url": "/static/js/20.02330f50.chunk.js"
  },
  {
    "revision": "a6eb7484deb76c3203fa",
    "url": "/static/js/21.c7f588ff.chunk.js"
  },
  {
    "revision": "e0bf27106c1efc8cf47a",
    "url": "/static/js/22.0b4e0205.chunk.js"
  },
  {
    "revision": "d2eac5d834df12835d29",
    "url": "/static/js/23.72b748f0.chunk.js"
  },
  {
    "revision": "c409acb5707ba7257e6d",
    "url": "/static/js/24.257191b5.chunk.js"
  },
  {
    "revision": "dd3298306ae23f98258e",
    "url": "/static/js/25.67e12f96.chunk.js"
  },
  {
    "revision": "0ce7ad91b8fcd58b9c91",
    "url": "/static/js/26.ccf9328f.chunk.js"
  },
  {
    "revision": "dbfb8ac6c1c1a1c8ad93",
    "url": "/static/js/27.f83732a1.chunk.js"
  },
  {
    "revision": "d0d5bca787c2dc678c1d",
    "url": "/static/js/28.f8377406.chunk.js"
  },
  {
    "revision": "52a4505a4274ec48a414",
    "url": "/static/js/29.d455cd2c.chunk.js"
  },
  {
    "revision": "df5b00eafabcc10c1538",
    "url": "/static/js/3.95caa87b.chunk.js"
  },
  {
    "revision": "88906292658170163fa7",
    "url": "/static/js/30.770f6de4.chunk.js"
  },
  {
    "revision": "75b4261fe8f9d2135f5d",
    "url": "/static/js/31.bae2bdf7.chunk.js"
  },
  {
    "revision": "550e724de85e400e0289",
    "url": "/static/js/32.2cfb01df.chunk.js"
  },
  {
    "revision": "af40f21513301b2856d2",
    "url": "/static/js/33.f5f4b9ed.chunk.js"
  },
  {
    "revision": "0640aa86c4cbf92a374e",
    "url": "/static/js/34.8a2127c8.chunk.js"
  },
  {
    "revision": "3503b713d781607959c1",
    "url": "/static/js/35.3a1d0092.chunk.js"
  },
  {
    "revision": "e3901b70c1d3871bd055",
    "url": "/static/js/36.1d86c8ec.chunk.js"
  },
  {
    "revision": "ed7b6f346b14b95005d9",
    "url": "/static/js/37.50c1975c.chunk.js"
  },
  {
    "revision": "27d9dc978d769e58ebe4",
    "url": "/static/js/38.4f4729dd.chunk.js"
  },
  {
    "revision": "39b5ac7082301e4c346d",
    "url": "/static/js/39.87f59e0f.chunk.js"
  },
  {
    "revision": "5482a455983585536996",
    "url": "/static/js/4.a609fe31.chunk.js"
  },
  {
    "revision": "9dc6d5bcce69c4b1e739",
    "url": "/static/js/40.3f8f881e.chunk.js"
  },
  {
    "revision": "12085ba1f4d01d1dcfc7",
    "url": "/static/js/41.cc2cea1c.chunk.js"
  },
  {
    "revision": "19e0b417e5de63f3f9d8",
    "url": "/static/js/42.bc86c406.chunk.js"
  },
  {
    "revision": "3cb84c903c11b1d7a9cd",
    "url": "/static/js/5.01c08fcc.chunk.js"
  },
  {
    "revision": "867ade80f29b244ccd09",
    "url": "/static/js/6.3fb58ec3.chunk.js"
  },
  {
    "revision": "4719b47fda9a65b1cf59",
    "url": "/static/js/7.d3942779.chunk.js"
  },
  {
    "revision": "cd7dae362c56c0d61be7",
    "url": "/static/js/8.af6b0940.chunk.js"
  },
  {
    "revision": "598f773eb76c294639ff",
    "url": "/static/js/9.b7390138.chunk.js"
  },
  {
    "revision": "8c4829542eb29d85b1eb",
    "url": "/static/js/main.8e162006.chunk.js"
  },
  {
    "revision": "6ab118a4c77964b06c96",
    "url": "/static/js/runtime~main.81511053.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);