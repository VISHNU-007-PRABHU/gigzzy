self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e08d34c2572e8a8ee4338ef8623fae5d",
    "url": "/index.html"
  },
  {
    "revision": "125c0f42bdc8b38a2e93",
    "url": "/static/css/20.18585a14.chunk.css"
  },
  {
    "revision": "c267a1915876b6e54629",
    "url": "/static/css/28.051905ae.chunk.css"
  },
  {
    "revision": "5cd6439d851822e8cb7d",
    "url": "/static/css/29.3a6be942.chunk.css"
  },
  {
    "revision": "b44e6f53b5f55fe68803",
    "url": "/static/css/30.88292131.chunk.css"
  },
  {
    "revision": "1752c80a02250908b452",
    "url": "/static/css/35.cb85cd3b.chunk.css"
  },
  {
    "revision": "cdee02ee8184eb83fc89",
    "url": "/static/css/37.11000f17.chunk.css"
  },
  {
    "revision": "5cbbe3b46ead63c57368",
    "url": "/static/css/40.11000f17.chunk.css"
  },
  {
    "revision": "f96de4ef101572f45b04",
    "url": "/static/css/45.28450e03.chunk.css"
  },
  {
    "revision": "99b63d618396209dfb07",
    "url": "/static/css/46.ecaf69fb.chunk.css"
  },
  {
    "revision": "414732ecf732b4b40abe",
    "url": "/static/css/50.f9b90304.chunk.css"
  },
  {
    "revision": "5dd44e7b7782ee2e06b8",
    "url": "/static/css/51.11000f17.chunk.css"
  },
  {
    "revision": "c5febd09af08ecc78cde",
    "url": "/static/css/53.9142c0f9.chunk.css"
  },
  {
    "revision": "9378be0c135f15af100a",
    "url": "/static/css/54.9142c0f9.chunk.css"
  },
  {
    "revision": "ec6e7fc92530685f892b",
    "url": "/static/css/55.0724d5f1.chunk.css"
  },
  {
    "revision": "441b226169b1d29c1f17",
    "url": "/static/css/56.3a6be942.chunk.css"
  },
  {
    "revision": "c98cb1b9a9667b521a0e",
    "url": "/static/css/57.3a6be942.chunk.css"
  },
  {
    "revision": "e9190f95b5ea712da45b",
    "url": "/static/css/61.cdaf15d1.chunk.css"
  },
  {
    "revision": "13cb4d9279c2de3a6490",
    "url": "/static/css/63.5b5fb56a.chunk.css"
  },
  {
    "revision": "a745c8b007430197bde8",
    "url": "/static/css/main.777ddbbe.chunk.css"
  },
  {
    "revision": "4016a970388eb9e3756f",
    "url": "/static/js/0.f64129e8.chunk.js"
  },
  {
    "revision": "8f0a5cb6540608110a11",
    "url": "/static/js/1.8f887495.chunk.js"
  },
  {
    "revision": "47bde967403803f7bed7",
    "url": "/static/js/10.8aa3c7b3.chunk.js"
  },
  {
    "revision": "8077191988ae984b3596",
    "url": "/static/js/100.650cd708.chunk.js"
  },
  {
    "revision": "d04a959ec68a19641f95",
    "url": "/static/js/101.51eba683.chunk.js"
  },
  {
    "revision": "32d643d11b25135e055f",
    "url": "/static/js/102.0cb99de1.chunk.js"
  },
  {
    "revision": "b7490cd747b97801f55b",
    "url": "/static/js/103.02a545fb.chunk.js"
  },
  {
    "revision": "604f3d49fcc6641895f5",
    "url": "/static/js/104.aae6e360.chunk.js"
  },
  {
    "revision": "d78262a8d4fdd21f7979",
    "url": "/static/js/105.3a88b17b.chunk.js"
  },
  {
    "revision": "43101b720180b3d9f1bf",
    "url": "/static/js/106.496accfe.chunk.js"
  },
  {
    "revision": "efb2701d8584df86337b",
    "url": "/static/js/107.dd30f4b5.chunk.js"
  },
  {
    "revision": "ae276f35be0761107cfe",
    "url": "/static/js/108.0eb49020.chunk.js"
  },
  {
    "revision": "94a4e67652bdd3934bdf",
    "url": "/static/js/109.3f7f7139.chunk.js"
  },
  {
    "revision": "1b7d7c4f8d1e68dc2a33",
    "url": "/static/js/11.0ee4f660.chunk.js"
  },
  {
    "revision": "989269dab2963f937c2a",
    "url": "/static/js/110.dc86df18.chunk.js"
  },
  {
    "revision": "68667a121671bb690683",
    "url": "/static/js/111.39344031.chunk.js"
  },
  {
    "revision": "e5e77c67aad72e5a875d",
    "url": "/static/js/112.c511004f.chunk.js"
  },
  {
    "revision": "ace4f2a2f7d19703a620",
    "url": "/static/js/113.ee2f857a.chunk.js"
  },
  {
    "revision": "11bad6eda3e8e3d5b709",
    "url": "/static/js/114.1bb12c24.chunk.js"
  },
  {
    "revision": "d56677c400c21488cf1f",
    "url": "/static/js/115.1660a543.chunk.js"
  },
  {
    "revision": "21095b0fd0ace26c4b55",
    "url": "/static/js/12.96e7e2d2.chunk.js"
  },
  {
    "revision": "8da0560ffc4060e5fad9",
    "url": "/static/js/13.4765cd55.chunk.js"
  },
  {
    "revision": "a6409fbf81ea46ee47ca",
    "url": "/static/js/14.84d9552f.chunk.js"
  },
  {
    "revision": "9859f7eddcec99ab00ac",
    "url": "/static/js/15.ceabce50.chunk.js"
  },
  {
    "revision": "bf21a1465fa2466b2255",
    "url": "/static/js/16.6aebd1db.chunk.js"
  },
  {
    "revision": "50498a0bd2098589d308",
    "url": "/static/js/17.da9aee37.chunk.js"
  },
  {
    "revision": "253596aa4a16c991d090",
    "url": "/static/js/18.a8d532f1.chunk.js"
  },
  {
    "revision": "a820e654b962d532e910",
    "url": "/static/js/19.59379f7f.chunk.js"
  },
  {
    "revision": "b7d4ba4aa1714ad0f82f",
    "url": "/static/js/2.7588b811.chunk.js"
  },
  {
    "revision": "125c0f42bdc8b38a2e93",
    "url": "/static/js/20.81b1f7c5.chunk.js"
  },
  {
    "revision": "1973a6eb0ec441c54d88",
    "url": "/static/js/21.034425a0.chunk.js"
  },
  {
    "revision": "3ef221f214ec4e50189a",
    "url": "/static/js/22.597b0a4d.chunk.js"
  },
  {
    "revision": "1264467ac3d7f2aeb150",
    "url": "/static/js/23.f8c38593.chunk.js"
  },
  {
    "revision": "e6ef0d076679432add6a",
    "url": "/static/js/24.e68f24a9.chunk.js"
  },
  {
    "revision": "25661387c8a3a0fe6a28",
    "url": "/static/js/25.32e4f29c.chunk.js"
  },
  {
    "revision": "c267a1915876b6e54629",
    "url": "/static/js/28.4802956c.chunk.js"
  },
  {
    "revision": "5cd6439d851822e8cb7d",
    "url": "/static/js/29.681fcf24.chunk.js"
  },
  {
    "revision": "34e8b082ea03e7c453fd",
    "url": "/static/js/3.6979d674.chunk.js"
  },
  {
    "revision": "b44e6f53b5f55fe68803",
    "url": "/static/js/30.39f6e759.chunk.js"
  },
  {
    "revision": "81389607f42999fbe3b5",
    "url": "/static/js/31.46c05b8a.chunk.js"
  },
  {
    "revision": "3dc16ced88241a4c5b9c",
    "url": "/static/js/32.71fc5dd5.chunk.js"
  },
  {
    "revision": "3fe6f771c6d6c1dbe6d2",
    "url": "/static/js/33.43f93bb9.chunk.js"
  },
  {
    "revision": "3d08e79bdb4c524257eb",
    "url": "/static/js/34.dfc31b9a.chunk.js"
  },
  {
    "revision": "1752c80a02250908b452",
    "url": "/static/js/35.e546929e.chunk.js"
  },
  {
    "revision": "6f85dc0abeafaa7b20c8",
    "url": "/static/js/36.aca38bc7.chunk.js"
  },
  {
    "revision": "cdee02ee8184eb83fc89",
    "url": "/static/js/37.2df9878e.chunk.js"
  },
  {
    "revision": "ec6589a82679d8559826",
    "url": "/static/js/38.135a7499.chunk.js"
  },
  {
    "revision": "79d4aa800cdc6c569ad6",
    "url": "/static/js/39.01dbe323.chunk.js"
  },
  {
    "revision": "365556d44f542e5099d7",
    "url": "/static/js/4.a7c8bd57.chunk.js"
  },
  {
    "revision": "5cbbe3b46ead63c57368",
    "url": "/static/js/40.3f24d6eb.chunk.js"
  },
  {
    "revision": "d37fb660026b75fb8dda",
    "url": "/static/js/41.558aa5e7.chunk.js"
  },
  {
    "revision": "f7e9622af92b4d4251c2",
    "url": "/static/js/42.8a9ebce5.chunk.js"
  },
  {
    "revision": "b0877f69c92af1c944dc",
    "url": "/static/js/43.ccbf7ff1.chunk.js"
  },
  {
    "revision": "fef8853ec5c34ac8f20d",
    "url": "/static/js/44.ba48993f.chunk.js"
  },
  {
    "revision": "f96de4ef101572f45b04",
    "url": "/static/js/45.ae2474e5.chunk.js"
  },
  {
    "revision": "99b63d618396209dfb07",
    "url": "/static/js/46.bd14b885.chunk.js"
  },
  {
    "revision": "01df550d9dc01b1c8b46",
    "url": "/static/js/47.26985e5e.chunk.js"
  },
  {
    "revision": "c2909b024c29e99cf57a",
    "url": "/static/js/48.64870df8.chunk.js"
  },
  {
    "revision": "ed2b78344ec8f87b62f8",
    "url": "/static/js/49.7ca75991.chunk.js"
  },
  {
    "revision": "7c2b204e003015e6cef1",
    "url": "/static/js/5.8301c229.chunk.js"
  },
  {
    "revision": "414732ecf732b4b40abe",
    "url": "/static/js/50.1ab9b5af.chunk.js"
  },
  {
    "revision": "5dd44e7b7782ee2e06b8",
    "url": "/static/js/51.311baf5e.chunk.js"
  },
  {
    "revision": "bb5d7806aaaf1f21dedd",
    "url": "/static/js/52.5c315c69.chunk.js"
  },
  {
    "revision": "c5febd09af08ecc78cde",
    "url": "/static/js/53.9c3c84db.chunk.js"
  },
  {
    "revision": "9378be0c135f15af100a",
    "url": "/static/js/54.7148f4d9.chunk.js"
  },
  {
    "revision": "ec6e7fc92530685f892b",
    "url": "/static/js/55.1a5d9dd7.chunk.js"
  },
  {
    "revision": "441b226169b1d29c1f17",
    "url": "/static/js/56.84f129b6.chunk.js"
  },
  {
    "revision": "c98cb1b9a9667b521a0e",
    "url": "/static/js/57.54d77705.chunk.js"
  },
  {
    "revision": "f4cfcc088c84ff4b0038",
    "url": "/static/js/58.29edcb73.chunk.js"
  },
  {
    "revision": "6e970dcd986a3f8174e5",
    "url": "/static/js/59.6664655a.chunk.js"
  },
  {
    "revision": "975012c6f5581b37ed82",
    "url": "/static/js/6.76ae03c1.chunk.js"
  },
  {
    "revision": "f6a5f0c660dcd542cd8c",
    "url": "/static/js/60.7a185f6d.chunk.js"
  },
  {
    "revision": "e9190f95b5ea712da45b",
    "url": "/static/js/61.16acd62c.chunk.js"
  },
  {
    "revision": "a3409ab037463d7fe696",
    "url": "/static/js/62.b5b75241.chunk.js"
  },
  {
    "revision": "13cb4d9279c2de3a6490",
    "url": "/static/js/63.753c7d0f.chunk.js"
  },
  {
    "revision": "56bea0391ced89ed346e",
    "url": "/static/js/64.c48d4ec3.chunk.js"
  },
  {
    "revision": "79c8ec1d6e571823fb51",
    "url": "/static/js/65.980fee92.chunk.js"
  },
  {
    "revision": "53d6070c606feb79162b",
    "url": "/static/js/66.09605a3d.chunk.js"
  },
  {
    "revision": "e8fe8a440298a3ad4e0e",
    "url": "/static/js/67.5562042d.chunk.js"
  },
  {
    "revision": "8e568e783207124162dd",
    "url": "/static/js/68.83fd2b22.chunk.js"
  },
  {
    "revision": "f27508715707938d594e",
    "url": "/static/js/69.961d6234.chunk.js"
  },
  {
    "revision": "086309705790f6980b4e",
    "url": "/static/js/7.ebaf9f50.chunk.js"
  },
  {
    "revision": "1a0785af6df4fdd2839f",
    "url": "/static/js/70.3f9e5cbc.chunk.js"
  },
  {
    "revision": "f9a999a8ac218ba8cf1e",
    "url": "/static/js/71.57314980.chunk.js"
  },
  {
    "revision": "049f650f4b9dd5bbe98b",
    "url": "/static/js/72.6efdfab4.chunk.js"
  },
  {
    "revision": "9720761f6dc94deee2c0",
    "url": "/static/js/73.74f01132.chunk.js"
  },
  {
    "revision": "06a1162fd31407713e8e",
    "url": "/static/js/74.e6cd7523.chunk.js"
  },
  {
    "revision": "208354278b5840537843",
    "url": "/static/js/75.ef6c24a4.chunk.js"
  },
  {
    "revision": "cf22baa0deb4b6488f07",
    "url": "/static/js/76.851161d7.chunk.js"
  },
  {
    "revision": "c8409a072c4d64657e27",
    "url": "/static/js/77.2c1701cc.chunk.js"
  },
  {
    "revision": "9af2c3d33eba5d3e8457",
    "url": "/static/js/78.31374e51.chunk.js"
  },
  {
    "revision": "ace20315ea6caef28ad3",
    "url": "/static/js/79.cc93cd92.chunk.js"
  },
  {
    "revision": "78428292b66c8c61b4c2",
    "url": "/static/js/8.684a0bd1.chunk.js"
  },
  {
    "revision": "40420f79d0585d651cca",
    "url": "/static/js/80.ed68837d.chunk.js"
  },
  {
    "revision": "3a41573ef50a8d0aa259",
    "url": "/static/js/81.1bd2520c.chunk.js"
  },
  {
    "revision": "7dc8dd96caf89103ea8d",
    "url": "/static/js/82.d96c1bcd.chunk.js"
  },
  {
    "revision": "cfae084d74a259334b7a",
    "url": "/static/js/83.8cd7f06c.chunk.js"
  },
  {
    "revision": "0c74ac051131b546f7c5",
    "url": "/static/js/84.aeef99d4.chunk.js"
  },
  {
    "revision": "58f9d83cc8bd80dc6730",
    "url": "/static/js/85.b37bedf2.chunk.js"
  },
  {
    "revision": "930d346bdd165e0a30d4",
    "url": "/static/js/86.7f07e5d0.chunk.js"
  },
  {
    "revision": "87d955b0a300895ab3fc",
    "url": "/static/js/87.d0bb4035.chunk.js"
  },
  {
    "revision": "e6a7bc37fe5264d919cf",
    "url": "/static/js/88.973d9e0b.chunk.js"
  },
  {
    "revision": "b23e5bbdcfdc6c7d8736",
    "url": "/static/js/89.cd89f663.chunk.js"
  },
  {
    "revision": "f7f3940caa418489a1a0",
    "url": "/static/js/9.4b929def.chunk.js"
  },
  {
    "revision": "9da5ad0cc3d862369316",
    "url": "/static/js/90.00ee729a.chunk.js"
  },
  {
    "revision": "2eccb86032f76d9d678f",
    "url": "/static/js/91.31cb34e3.chunk.js"
  },
  {
    "revision": "0c3856a30592f05228d5",
    "url": "/static/js/92.78cd8214.chunk.js"
  },
  {
    "revision": "80ef6f6c84e54518fe7e",
    "url": "/static/js/93.d58faf28.chunk.js"
  },
  {
    "revision": "054e4b622f13c7dfdeaa",
    "url": "/static/js/94.3d679024.chunk.js"
  },
  {
    "revision": "25d5e087a8f6118812f8",
    "url": "/static/js/95.58ffb23b.chunk.js"
  },
  {
    "revision": "06055286748d7634be64",
    "url": "/static/js/96.77903114.chunk.js"
  },
  {
    "revision": "0d95a92c13d7d57d71de",
    "url": "/static/js/97.cfca43cd.chunk.js"
  },
  {
    "revision": "831b56e10576c89cc175",
    "url": "/static/js/98.8bbb7a72.chunk.js"
  },
  {
    "revision": "5f2b8fd2daa1d7d96bd6",
    "url": "/static/js/99.dc5bdc29.chunk.js"
  },
  {
    "revision": "a745c8b007430197bde8",
    "url": "/static/js/main.ac15ef1e.chunk.js"
  },
  {
    "revision": "38373945d69ec086728e",
    "url": "/static/js/runtime~main.78cb8059.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);