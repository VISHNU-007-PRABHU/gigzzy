self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "12fc26db655ebd1baf3a005691248c32",
    "url": "/index.html"
  },
  {
    "revision": "838697f942879d518e1f",
    "url": "/static/css/19.cdaf15d1.chunk.css"
  },
  {
    "revision": "173df9ec5d245da7b3cd",
    "url": "/static/css/28.051905ae.chunk.css"
  },
  {
    "revision": "efdf0742295587a6fae4",
    "url": "/static/css/29.3a6be942.chunk.css"
  },
  {
    "revision": "ca6bc715c68a7cf5edba",
    "url": "/static/css/30.88292131.chunk.css"
  },
  {
    "revision": "7e1dc27f4ab377848917",
    "url": "/static/css/35.c9556fed.chunk.css"
  },
  {
    "revision": "33bbc82cb1840269b2cc",
    "url": "/static/css/37.11000f17.chunk.css"
  },
  {
    "revision": "c1295e15cd2dc6543859",
    "url": "/static/css/40.11000f17.chunk.css"
  },
  {
    "revision": "80b0ee8f26aaab5defe9",
    "url": "/static/css/45.cec7b7a9.chunk.css"
  },
  {
    "revision": "fc80afacb3e9cc4494de",
    "url": "/static/css/46.8cf98a25.chunk.css"
  },
  {
    "revision": "54651f78d9710cad3132",
    "url": "/static/css/50.0724d5f1.chunk.css"
  },
  {
    "revision": "a5bf3a338cc15fddd999",
    "url": "/static/css/51.11000f17.chunk.css"
  },
  {
    "revision": "fbf3f4d0dc40eba32eef",
    "url": "/static/css/53.82b1d2bb.chunk.css"
  },
  {
    "revision": "f25ff3eb774069815ce0",
    "url": "/static/css/54.9142c0f9.chunk.css"
  },
  {
    "revision": "f769c73406c0545c42d3",
    "url": "/static/css/55.0724d5f1.chunk.css"
  },
  {
    "revision": "3fc6812b9d10c1593afe",
    "url": "/static/css/56.3a6be942.chunk.css"
  },
  {
    "revision": "354ca5344d102a5ece2a",
    "url": "/static/css/57.3a6be942.chunk.css"
  },
  {
    "revision": "3c786dc820a0497c1b14",
    "url": "/static/css/61.cdaf15d1.chunk.css"
  },
  {
    "revision": "2f0138da40819134c3b7",
    "url": "/static/css/63.5b5fb56a.chunk.css"
  },
  {
    "revision": "94937a8528202f01d6f5",
    "url": "/static/css/main.84c18709.chunk.css"
  },
  {
    "revision": "79ddefaa7686878badb6",
    "url": "/static/js/0.c9285907.chunk.js"
  },
  {
    "revision": "362222a5f3f957450040",
    "url": "/static/js/1.a7ecc6c7.chunk.js"
  },
  {
    "revision": "d8f7900a50c3ad35bcae",
    "url": "/static/js/10.5d0cc81d.chunk.js"
  },
  {
    "revision": "51321e006e85207fbbd5",
    "url": "/static/js/100.5a6fe630.chunk.js"
  },
  {
    "revision": "6d150fbc7f74dce3cc56",
    "url": "/static/js/101.e67ec2e5.chunk.js"
  },
  {
    "revision": "0015e3016878f850f39a",
    "url": "/static/js/102.854e7fec.chunk.js"
  },
  {
    "revision": "7791cf8bf4f187ba8d1f",
    "url": "/static/js/103.fd917d77.chunk.js"
  },
  {
    "revision": "a7df5f47a891f9aebcc8",
    "url": "/static/js/104.253a2c17.chunk.js"
  },
  {
    "revision": "308e01b60e56c2775df1",
    "url": "/static/js/105.1f6d68ce.chunk.js"
  },
  {
    "revision": "e5d7750b4bd685a46778",
    "url": "/static/js/106.35382f47.chunk.js"
  },
  {
    "revision": "b9637965acb6fb79bb61",
    "url": "/static/js/107.4ee1d4b5.chunk.js"
  },
  {
    "revision": "c38561c2b12d9cbf1aaa",
    "url": "/static/js/108.3cc113c9.chunk.js"
  },
  {
    "revision": "8b7a0ee62c6c9001a95a",
    "url": "/static/js/109.d4ff9486.chunk.js"
  },
  {
    "revision": "8831865e8c78d3d03af1",
    "url": "/static/js/11.57adf859.chunk.js"
  },
  {
    "revision": "1469650a9aa267a8c63a",
    "url": "/static/js/110.91d878de.chunk.js"
  },
  {
    "revision": "c828eeb3b65cd6c98aea",
    "url": "/static/js/111.11433a9a.chunk.js"
  },
  {
    "revision": "61b20d75655b83e4297e",
    "url": "/static/js/112.344feff9.chunk.js"
  },
  {
    "revision": "f8abb71798a4abe42f41",
    "url": "/static/js/113.f51641f8.chunk.js"
  },
  {
    "revision": "494e3b77096d5f7b5987",
    "url": "/static/js/114.d733c047.chunk.js"
  },
  {
    "revision": "2e9258ba929dde11a29d",
    "url": "/static/js/115.f7744cbf.chunk.js"
  },
  {
    "revision": "9d5d52a6a923ec0b05fa",
    "url": "/static/js/116.9c99d1e5.chunk.js"
  },
  {
    "revision": "c6bf3d72a4fe155ccf31",
    "url": "/static/js/117.e5ea0b58.chunk.js"
  },
  {
    "revision": "34af42d17364f237e516",
    "url": "/static/js/118.15814308.chunk.js"
  },
  {
    "revision": "cb4a0c0d7b11f7f20df1",
    "url": "/static/js/12.904e8931.chunk.js"
  },
  {
    "revision": "9555fef29276c024129a",
    "url": "/static/js/13.d6297a3a.chunk.js"
  },
  {
    "revision": "bded1f847a134c4639cf",
    "url": "/static/js/14.f52e176d.chunk.js"
  },
  {
    "revision": "7fcf7772464bb23323ca",
    "url": "/static/js/15.81a8d54c.chunk.js"
  },
  {
    "revision": "37aa235b9ef13dd15fc1",
    "url": "/static/js/16.a54298f3.chunk.js"
  },
  {
    "revision": "ed2d0e8e92acce0b8ba3",
    "url": "/static/js/17.a8c6d529.chunk.js"
  },
  {
    "revision": "b265582582f3eb51818f",
    "url": "/static/js/18.d86ce837.chunk.js"
  },
  {
    "revision": "838697f942879d518e1f",
    "url": "/static/js/19.9bbd5cdc.chunk.js"
  },
  {
    "revision": "c2cf25546ca0f6ea257f",
    "url": "/static/js/2.55905f2a.chunk.js"
  },
  {
    "revision": "a4be819742d1da3aee94",
    "url": "/static/js/20.02e1adba.chunk.js"
  },
  {
    "revision": "9d7c955a3ab9ae94e043",
    "url": "/static/js/21.9c9357d8.chunk.js"
  },
  {
    "revision": "56200dc24fb74d2e0329",
    "url": "/static/js/22.a0bf60ff.chunk.js"
  },
  {
    "revision": "002620cf4c40c747e58b",
    "url": "/static/js/23.908399b0.chunk.js"
  },
  {
    "revision": "c3a70edc4ed21bd93750",
    "url": "/static/js/24.747224de.chunk.js"
  },
  {
    "revision": "ad0f2b0215414b06384d",
    "url": "/static/js/25.3e1af474.chunk.js"
  },
  {
    "revision": "173df9ec5d245da7b3cd",
    "url": "/static/js/28.9a678e86.chunk.js"
  },
  {
    "revision": "efdf0742295587a6fae4",
    "url": "/static/js/29.cfe5cf81.chunk.js"
  },
  {
    "revision": "72a386cc70476783ff50",
    "url": "/static/js/3.8ca42c32.chunk.js"
  },
  {
    "revision": "ca6bc715c68a7cf5edba",
    "url": "/static/js/30.959439a0.chunk.js"
  },
  {
    "revision": "689254f92ede1224b827",
    "url": "/static/js/31.2685f867.chunk.js"
  },
  {
    "revision": "52e7de238e6df35e597c",
    "url": "/static/js/32.0efec98e.chunk.js"
  },
  {
    "revision": "251f287df5deb6150dc8",
    "url": "/static/js/33.60fc1152.chunk.js"
  },
  {
    "revision": "5484ea672ba86add3874",
    "url": "/static/js/34.a98344a3.chunk.js"
  },
  {
    "revision": "7e1dc27f4ab377848917",
    "url": "/static/js/35.36f96d8a.chunk.js"
  },
  {
    "revision": "89cf703acd8618b41281",
    "url": "/static/js/36.000b8541.chunk.js"
  },
  {
    "revision": "33bbc82cb1840269b2cc",
    "url": "/static/js/37.837a45c4.chunk.js"
  },
  {
    "revision": "ecaa74a296afd73ce51c",
    "url": "/static/js/38.cbc1790e.chunk.js"
  },
  {
    "revision": "fbe38b5582f5e6a79bd8",
    "url": "/static/js/39.79224d31.chunk.js"
  },
  {
    "revision": "51d004b2e6499352564b",
    "url": "/static/js/4.8b0d5c2b.chunk.js"
  },
  {
    "revision": "c1295e15cd2dc6543859",
    "url": "/static/js/40.c036d554.chunk.js"
  },
  {
    "revision": "d8eab4c7df4b225ac9c5",
    "url": "/static/js/41.2eac4b7f.chunk.js"
  },
  {
    "revision": "8584563ffd543a254370",
    "url": "/static/js/42.155d3b4e.chunk.js"
  },
  {
    "revision": "545a859f6c14b01c3c51",
    "url": "/static/js/43.4bdfcbc9.chunk.js"
  },
  {
    "revision": "d16fe233957b273b8a6c",
    "url": "/static/js/44.a014b15e.chunk.js"
  },
  {
    "revision": "80b0ee8f26aaab5defe9",
    "url": "/static/js/45.983ef0b6.chunk.js"
  },
  {
    "revision": "fc80afacb3e9cc4494de",
    "url": "/static/js/46.d3428ee7.chunk.js"
  },
  {
    "revision": "33220d8dd29b8133a49f",
    "url": "/static/js/47.77ecb859.chunk.js"
  },
  {
    "revision": "3efc9da1e525633b4cdb",
    "url": "/static/js/48.457887f8.chunk.js"
  },
  {
    "revision": "17f06038e7eb1f9a0f44",
    "url": "/static/js/49.fccc7975.chunk.js"
  },
  {
    "revision": "cb95d906007d2c3766f1",
    "url": "/static/js/5.500808ae.chunk.js"
  },
  {
    "revision": "54651f78d9710cad3132",
    "url": "/static/js/50.bf90f856.chunk.js"
  },
  {
    "revision": "a5bf3a338cc15fddd999",
    "url": "/static/js/51.1a2e7f69.chunk.js"
  },
  {
    "revision": "c088ca05e0cf911761cb",
    "url": "/static/js/52.6ed4cb05.chunk.js"
  },
  {
    "revision": "fbf3f4d0dc40eba32eef",
    "url": "/static/js/53.39efc0c6.chunk.js"
  },
  {
    "revision": "f25ff3eb774069815ce0",
    "url": "/static/js/54.c426d78d.chunk.js"
  },
  {
    "revision": "f769c73406c0545c42d3",
    "url": "/static/js/55.c10459d1.chunk.js"
  },
  {
    "revision": "3fc6812b9d10c1593afe",
    "url": "/static/js/56.008aac78.chunk.js"
  },
  {
    "revision": "354ca5344d102a5ece2a",
    "url": "/static/js/57.21428539.chunk.js"
  },
  {
    "revision": "aa25d5ea7916d39e2623",
    "url": "/static/js/58.8a076c62.chunk.js"
  },
  {
    "revision": "95ec26db5f4dc03e5ab3",
    "url": "/static/js/59.752baac0.chunk.js"
  },
  {
    "revision": "32943a1322ccd54d0c88",
    "url": "/static/js/6.38001325.chunk.js"
  },
  {
    "revision": "c71d028a1de9a1f4a812",
    "url": "/static/js/60.28e1b578.chunk.js"
  },
  {
    "revision": "3c786dc820a0497c1b14",
    "url": "/static/js/61.f019c993.chunk.js"
  },
  {
    "revision": "ff40ee9717831006bc6c",
    "url": "/static/js/62.36c5286b.chunk.js"
  },
  {
    "revision": "2f0138da40819134c3b7",
    "url": "/static/js/63.a0671b2c.chunk.js"
  },
  {
    "revision": "9cb9e30a04d4068352ab",
    "url": "/static/js/64.abcc1aca.chunk.js"
  },
  {
    "revision": "a808ef83d96f0d14635c",
    "url": "/static/js/65.c08580fd.chunk.js"
  },
  {
    "revision": "1ad39c8dff99920a24a0",
    "url": "/static/js/66.13676466.chunk.js"
  },
  {
    "revision": "375ca22a68927d2c27d1",
    "url": "/static/js/67.42e66282.chunk.js"
  },
  {
    "revision": "e70273915ef3a60c90ad",
    "url": "/static/js/68.0d330488.chunk.js"
  },
  {
    "revision": "0f836a67132fb3e03d3b",
    "url": "/static/js/69.ef2e92d1.chunk.js"
  },
  {
    "revision": "b0ac57b834d2c90b8911",
    "url": "/static/js/7.373656ec.chunk.js"
  },
  {
    "revision": "4ca99fc757cb6ae0304e",
    "url": "/static/js/70.f22dffe9.chunk.js"
  },
  {
    "revision": "0558af588e24c54d8626",
    "url": "/static/js/71.2c06bc78.chunk.js"
  },
  {
    "revision": "c1e54b44d4b228b9a3a0",
    "url": "/static/js/72.6d52e363.chunk.js"
  },
  {
    "revision": "124c74c283403ff84b03",
    "url": "/static/js/73.5cf9905d.chunk.js"
  },
  {
    "revision": "f5bd5294966bb233821a",
    "url": "/static/js/74.56d935b7.chunk.js"
  },
  {
    "revision": "9e4915ab6c6764327194",
    "url": "/static/js/75.787ed6f3.chunk.js"
  },
  {
    "revision": "86c5fe99078169040fa5",
    "url": "/static/js/76.1cfaf84b.chunk.js"
  },
  {
    "revision": "9b6b4ac197cbb0612ad7",
    "url": "/static/js/77.96fc2a7b.chunk.js"
  },
  {
    "revision": "d6552468bc1cfdd415c5",
    "url": "/static/js/78.29f6fd51.chunk.js"
  },
  {
    "revision": "8cad16758ec22c368bcc",
    "url": "/static/js/79.2330f038.chunk.js"
  },
  {
    "revision": "8cc3226523ae8f56f98d",
    "url": "/static/js/8.3e85d2bf.chunk.js"
  },
  {
    "revision": "9c7a365679f458a70487",
    "url": "/static/js/80.71ae1f75.chunk.js"
  },
  {
    "revision": "6db6bed525126afb0061",
    "url": "/static/js/81.9375a2aa.chunk.js"
  },
  {
    "revision": "cbbe341f121156a95a2e",
    "url": "/static/js/82.0f56b290.chunk.js"
  },
  {
    "revision": "6cbc9b7ee7bf7e4b0962",
    "url": "/static/js/83.a85fb548.chunk.js"
  },
  {
    "revision": "24e4605ea2330a4dc348",
    "url": "/static/js/84.ad58d398.chunk.js"
  },
  {
    "revision": "a45cac9b91bb9f880fd0",
    "url": "/static/js/85.f9d3da15.chunk.js"
  },
  {
    "revision": "0f441367f5097a6a3b52",
    "url": "/static/js/86.0bbf825a.chunk.js"
  },
  {
    "revision": "b5e450df3ef3574e0ed4",
    "url": "/static/js/87.0a70de82.chunk.js"
  },
  {
    "revision": "06e1da4e27ff4a71b5db",
    "url": "/static/js/88.80bef47d.chunk.js"
  },
  {
    "revision": "b1a291e79302afe4b9f8",
    "url": "/static/js/89.1bd52445.chunk.js"
  },
  {
    "revision": "d37e95ecdd76e89c95a9",
    "url": "/static/js/9.10284b9e.chunk.js"
  },
  {
    "revision": "6a0b6c4203e19fd322ae",
    "url": "/static/js/90.ba4b88a1.chunk.js"
  },
  {
    "revision": "8c1d3b271adac89de62d",
    "url": "/static/js/91.17f57726.chunk.js"
  },
  {
    "revision": "48b49827ffa9eb69a69b",
    "url": "/static/js/92.4ba23f76.chunk.js"
  },
  {
    "revision": "e2c17edc0a81887106e3",
    "url": "/static/js/93.26430bec.chunk.js"
  },
  {
    "revision": "edb0ad3b30246d9c6e03",
    "url": "/static/js/94.6275ec30.chunk.js"
  },
  {
    "revision": "895c196f31b13bc246e7",
    "url": "/static/js/95.58e2b51c.chunk.js"
  },
  {
    "revision": "569133d9e559f4f5afb2",
    "url": "/static/js/96.743eaf36.chunk.js"
  },
  {
    "revision": "eacfe8490c9429ccc782",
    "url": "/static/js/97.b1c069c7.chunk.js"
  },
  {
    "revision": "8da995cbe3e79b9f0897",
    "url": "/static/js/98.497c3436.chunk.js"
  },
  {
    "revision": "fd813a74660c50f9829b",
    "url": "/static/js/99.e0524253.chunk.js"
  },
  {
    "revision": "94937a8528202f01d6f5",
    "url": "/static/js/main.7407a638.chunk.js"
  },
  {
    "revision": "19bfa51c2a12826d4e18",
    "url": "/static/js/runtime~main.b9463cd4.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);