self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "12bf99a6d0c4e6230dc86df5791e4356",
    "url": "/index.html"
  },
  {
    "revision": "e1cfeecafb6674f6f91f",
    "url": "/static/css/14.75a79a19.chunk.css"
  },
  {
    "revision": "7736e79fb36eed980f33",
    "url": "/static/css/main.b30c303b.chunk.css"
  },
  {
    "revision": "9ac87544806947daacb6",
    "url": "/static/js/0.f02cf478.chunk.js"
  },
  {
    "revision": "51eb1a9b05eb660e5492",
    "url": "/static/js/1.5f389031.chunk.js"
  },
  {
    "revision": "ffad0556b5d7ed8fcc35",
    "url": "/static/js/10.00112f68.chunk.js"
  },
  {
    "revision": "cbc17dab3b39e2bb394e",
    "url": "/static/js/11.a44784f4.chunk.js"
  },
  {
    "revision": "e1cfeecafb6674f6f91f",
    "url": "/static/js/14.e9cc2c2d.chunk.js"
  },
  {
    "revision": "f28d673e73a78b26c695",
    "url": "/static/js/15.8b7a7871.chunk.js"
  },
  {
    "revision": "9a5db3b8e50e0b18e29d",
    "url": "/static/js/16.42de4fb6.chunk.js"
  },
  {
    "revision": "1e78527e70555f1a5b1f",
    "url": "/static/js/17.96c66b9f.chunk.js"
  },
  {
    "revision": "7567132a593dbd57fdc2",
    "url": "/static/js/18.3de9996b.chunk.js"
  },
  {
    "revision": "02e651fd2610bf9962c5",
    "url": "/static/js/19.91c266e2.chunk.js"
  },
  {
    "revision": "b73762c3888eca1d1ca8",
    "url": "/static/js/2.8f0f234c.chunk.js"
  },
  {
    "revision": "c9e16bf3f0782818addf",
    "url": "/static/js/20.b9433144.chunk.js"
  },
  {
    "revision": "a098a7c7e7f678087bcc",
    "url": "/static/js/21.7816812c.chunk.js"
  },
  {
    "revision": "80046fbe0ac5670cbfa4",
    "url": "/static/js/22.aefa2784.chunk.js"
  },
  {
    "revision": "4bae2c2e61b50de48e9b",
    "url": "/static/js/23.8cc1672f.chunk.js"
  },
  {
    "revision": "c4420336747e1fd6cd26",
    "url": "/static/js/24.b4d79796.chunk.js"
  },
  {
    "revision": "f73b57333fc3de182fe4",
    "url": "/static/js/25.e9464544.chunk.js"
  },
  {
    "revision": "c05d39be9a5ae2f74053",
    "url": "/static/js/26.9996c11d.chunk.js"
  },
  {
    "revision": "6e729fa89aaae1281650",
    "url": "/static/js/27.1b6ea8cc.chunk.js"
  },
  {
    "revision": "cbfa49f5728b6d9706fb",
    "url": "/static/js/28.54df2acb.chunk.js"
  },
  {
    "revision": "db480faa17adc792dcc3",
    "url": "/static/js/29.b10e2801.chunk.js"
  },
  {
    "revision": "8718417f2eedad7df23a",
    "url": "/static/js/3.ff109f9c.chunk.js"
  },
  {
    "revision": "c50410a8169a34f7f398",
    "url": "/static/js/30.c64cc630.chunk.js"
  },
  {
    "revision": "537db16d406e9404a5a3",
    "url": "/static/js/31.bad72d5b.chunk.js"
  },
  {
    "revision": "519d0d1d0618e96558aa",
    "url": "/static/js/32.d653e0d6.chunk.js"
  },
  {
    "revision": "f7073df800f05cae8275",
    "url": "/static/js/33.6774af71.chunk.js"
  },
  {
    "revision": "066cc747d55c69d09e05",
    "url": "/static/js/34.d1e3c8c3.chunk.js"
  },
  {
    "revision": "9af97943aaca10b12bb9",
    "url": "/static/js/35.2de6667e.chunk.js"
  },
  {
    "revision": "cb67f55681f9f29978cd",
    "url": "/static/js/36.ba041eae.chunk.js"
  },
  {
    "revision": "fab3ec19f7afb3414788",
    "url": "/static/js/37.ac2b32af.chunk.js"
  },
  {
    "revision": "4991963897a5835c42f8",
    "url": "/static/js/38.2b05fd79.chunk.js"
  },
  {
    "revision": "7f545e1e7ee4959a9a42",
    "url": "/static/js/39.4738778e.chunk.js"
  },
  {
    "revision": "a17fc34506fdde7346db",
    "url": "/static/js/4.834501c0.chunk.js"
  },
  {
    "revision": "f4a4860d36c45b739e30",
    "url": "/static/js/40.a710ea02.chunk.js"
  },
  {
    "revision": "454b06cf0f5d18598a03",
    "url": "/static/js/5.8fd9eba7.chunk.js"
  },
  {
    "revision": "f2f18bc2a5fb3b534e80",
    "url": "/static/js/6.18880786.chunk.js"
  },
  {
    "revision": "8e835e65ef68fe24907c",
    "url": "/static/js/7.91633376.chunk.js"
  },
  {
    "revision": "99407fa17392e9330755",
    "url": "/static/js/8.cd14ddce.chunk.js"
  },
  {
    "revision": "3a5027bf6ee414e87722",
    "url": "/static/js/9.53826c4a.chunk.js"
  },
  {
    "revision": "7736e79fb36eed980f33",
    "url": "/static/js/main.2613a6c0.chunk.js"
  },
  {
    "revision": "38a46afdf1526897766f",
    "url": "/static/js/runtime~main.7d7f07d4.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);