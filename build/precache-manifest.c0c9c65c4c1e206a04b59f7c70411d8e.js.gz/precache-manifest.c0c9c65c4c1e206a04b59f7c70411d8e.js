self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1e2fc7ae6127aae773dbc61e5aba8389",
    "url": "/index.html"
  },
  {
    "revision": "87b8addcb220f57a8dc4",
    "url": "/static/css/8.a8d8cd7e.chunk.css"
  },
  {
    "revision": "0816800559b9d3572e74",
    "url": "/static/css/main.7e6f64d7.chunk.css"
  },
  {
    "revision": "5a620e0b85de855a44f1",
    "url": "/static/js/0.22465d15.chunk.js"
  },
  {
    "revision": "1c2e2001c4f2d9dae8fb",
    "url": "/static/js/1.f816bf19.chunk.js"
  },
  {
    "revision": "62f8e054c5004639d86f",
    "url": "/static/js/10.84044ca4.chunk.js"
  },
  {
    "revision": "ae8a17d0d3f4b6c728c9",
    "url": "/static/js/11.579df0fc.chunk.js"
  },
  {
    "revision": "de621d575877bcb1e4c5",
    "url": "/static/js/2.6be8ba98.chunk.js"
  },
  {
    "revision": "d11c55a2a1eb4a89ff26",
    "url": "/static/js/3.98b35aa9.chunk.js"
  },
  {
    "revision": "629e8baaa39a0bac57ed",
    "url": "/static/js/4.7230c0bb.chunk.js"
  },
  {
    "revision": "2b72f7307fc3de958b6e",
    "url": "/static/js/5.2b768228.chunk.js"
  },
  {
    "revision": "87b8addcb220f57a8dc4",
    "url": "/static/js/8.536ed6fc.chunk.js"
  },
  {
    "revision": "6a8bcef3e6b12ffac70c",
    "url": "/static/js/9.0e9cb3bf.chunk.js"
  },
  {
    "revision": "0816800559b9d3572e74",
    "url": "/static/js/main.9c2612ec.chunk.js"
  },
  {
    "revision": "4724c3ddcc928f61675b",
    "url": "/static/js/runtime~main.7c2ed236.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);