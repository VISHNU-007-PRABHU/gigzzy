self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2386f27faa84da6a9f7e7716687213d3",
    "url": "/index.html"
  },
  {
    "revision": "c537880b54b3ee48bfba",
    "url": "/static/css/20.cdaf15d1.chunk.css"
  },
  {
    "revision": "69fff4e21b4471bc04f6",
    "url": "/static/css/30.051905ae.chunk.css"
  },
  {
    "revision": "df6474752b346db2331f",
    "url": "/static/css/31.3a6be942.chunk.css"
  },
  {
    "revision": "c4876b97c388ab9f5a10",
    "url": "/static/css/32.88292131.chunk.css"
  },
  {
    "revision": "7ea6203340f259ef7794",
    "url": "/static/css/37.c9556fed.chunk.css"
  },
  {
    "revision": "7fd2a8160d517572acde",
    "url": "/static/css/39.11000f17.chunk.css"
  },
  {
    "revision": "6894946c65c96cf450e5",
    "url": "/static/css/42.11000f17.chunk.css"
  },
  {
    "revision": "9071c8cc1c1f803cd32a",
    "url": "/static/css/47.52c43222.chunk.css"
  },
  {
    "revision": "98c7bd3276f4d2320974",
    "url": "/static/css/48.8cf98a25.chunk.css"
  },
  {
    "revision": "f050063b6254ca021c9e",
    "url": "/static/css/52.f9b90304.chunk.css"
  },
  {
    "revision": "814c50fa5c0a9011318c",
    "url": "/static/css/53.11000f17.chunk.css"
  },
  {
    "revision": "8b548039359cda7529fa",
    "url": "/static/css/55.9142c0f9.chunk.css"
  },
  {
    "revision": "28ccc3caf1a2e82e1879",
    "url": "/static/css/56.9142c0f9.chunk.css"
  },
  {
    "revision": "2ae5924db11f6dd55f44",
    "url": "/static/css/57.0724d5f1.chunk.css"
  },
  {
    "revision": "eec53468047bb8737ef9",
    "url": "/static/css/58.3a6be942.chunk.css"
  },
  {
    "revision": "53d67e6956f6199f6617",
    "url": "/static/css/59.3a6be942.chunk.css"
  },
  {
    "revision": "92bac48af10d4bc429f3",
    "url": "/static/css/63.cdaf15d1.chunk.css"
  },
  {
    "revision": "cb9595b4478f2eae17e4",
    "url": "/static/css/65.5b5fb56a.chunk.css"
  },
  {
    "revision": "ac1e679ddaa384151271",
    "url": "/static/css/main.777ddbbe.chunk.css"
  },
  {
    "revision": "79ddefaa7686878badb6",
    "url": "/static/js/0.c9285907.chunk.js"
  },
  {
    "revision": "8175226493153f139f94",
    "url": "/static/js/1.2b9d611e.chunk.js"
  },
  {
    "revision": "879236b1752f468df740",
    "url": "/static/js/10.36a0169a.chunk.js"
  },
  {
    "revision": "fc0208c30fe2718be35b",
    "url": "/static/js/100.69f2622a.chunk.js"
  },
  {
    "revision": "7d6d4729020371c9b56e",
    "url": "/static/js/101.3ffad892.chunk.js"
  },
  {
    "revision": "0c80e16039ae3342b669",
    "url": "/static/js/102.8fdb1a16.chunk.js"
  },
  {
    "revision": "2fe934d63c0fc41f50d5",
    "url": "/static/js/103.05c09f3b.chunk.js"
  },
  {
    "revision": "709ca8daa66bfe490e31",
    "url": "/static/js/104.125634bd.chunk.js"
  },
  {
    "revision": "730c3fc5b305d8ff1025",
    "url": "/static/js/105.25411a99.chunk.js"
  },
  {
    "revision": "5c4c30cfa4a6981ee518",
    "url": "/static/js/106.811fc475.chunk.js"
  },
  {
    "revision": "ed4a97391e1b89439b8a",
    "url": "/static/js/107.060c7ed7.chunk.js"
  },
  {
    "revision": "bdfc0f48710cdfd25c9b",
    "url": "/static/js/108.2e84057b.chunk.js"
  },
  {
    "revision": "549858e03f02da6b8190",
    "url": "/static/js/109.52cad79b.chunk.js"
  },
  {
    "revision": "5be61e1a2ea62f4557d2",
    "url": "/static/js/11.92656d7b.chunk.js"
  },
  {
    "revision": "7b71bf91594c89aa91b3",
    "url": "/static/js/110.8700b844.chunk.js"
  },
  {
    "revision": "dd79d3fe0000a5d3d680",
    "url": "/static/js/111.35f1fbfe.chunk.js"
  },
  {
    "revision": "cdbb640861ef871246ae",
    "url": "/static/js/112.5c452dc6.chunk.js"
  },
  {
    "revision": "4175cb81f4a003c9ba33",
    "url": "/static/js/113.5d352e16.chunk.js"
  },
  {
    "revision": "b1d28d5539e780a1ba07",
    "url": "/static/js/114.37587393.chunk.js"
  },
  {
    "revision": "06b58b9ef2895d48b154",
    "url": "/static/js/115.38662202.chunk.js"
  },
  {
    "revision": "36c441ce3f3b8781eedb",
    "url": "/static/js/116.7e36aa7a.chunk.js"
  },
  {
    "revision": "562d54b9f8c3bcb7d9e9",
    "url": "/static/js/117.84c779e4.chunk.js"
  },
  {
    "revision": "22c880a2ebf8476183d9",
    "url": "/static/js/12.858f4d72.chunk.js"
  },
  {
    "revision": "63b2e97da5950f32d0da",
    "url": "/static/js/13.ca572ebc.chunk.js"
  },
  {
    "revision": "544026da44b282cdfd13",
    "url": "/static/js/14.a351266a.chunk.js"
  },
  {
    "revision": "8d834ab9a86e9c163870",
    "url": "/static/js/15.3d2d75f1.chunk.js"
  },
  {
    "revision": "d0b373f6f94f282a5b05",
    "url": "/static/js/16.a57d96f0.chunk.js"
  },
  {
    "revision": "9c907776cc4aec26ec52",
    "url": "/static/js/17.ed3b5689.chunk.js"
  },
  {
    "revision": "1562c03ba66de0d36fdb",
    "url": "/static/js/18.9c5917b2.chunk.js"
  },
  {
    "revision": "b89f9a381a8de3308f6f",
    "url": "/static/js/19.b2d98531.chunk.js"
  },
  {
    "revision": "b0aab6fbb06a329c932a",
    "url": "/static/js/2.e3da1825.chunk.js"
  },
  {
    "revision": "c537880b54b3ee48bfba",
    "url": "/static/js/20.8b9e655f.chunk.js"
  },
  {
    "revision": "2ceb3be5f986c71a6863",
    "url": "/static/js/21.ddd49e25.chunk.js"
  },
  {
    "revision": "815cdf1a04056485ea8e",
    "url": "/static/js/22.5ce30b9b.chunk.js"
  },
  {
    "revision": "a8fa49f893db1a25e32c",
    "url": "/static/js/23.401e741a.chunk.js"
  },
  {
    "revision": "3cbf6d781df26dfff33a",
    "url": "/static/js/24.7eda9f24.chunk.js"
  },
  {
    "revision": "b6fe2638694fa0587d4c",
    "url": "/static/js/25.2fcdc190.chunk.js"
  },
  {
    "revision": "31f29f2d393ae0e019eb",
    "url": "/static/js/26.fa30fcea.chunk.js"
  },
  {
    "revision": "e28490b0f235b6448b15",
    "url": "/static/js/27.cacc9207.chunk.js"
  },
  {
    "revision": "348250c8de18422a97c9",
    "url": "/static/js/3.519d0da2.chunk.js"
  },
  {
    "revision": "69fff4e21b4471bc04f6",
    "url": "/static/js/30.faa354ef.chunk.js"
  },
  {
    "revision": "df6474752b346db2331f",
    "url": "/static/js/31.b6e4a70a.chunk.js"
  },
  {
    "revision": "c4876b97c388ab9f5a10",
    "url": "/static/js/32.6e6acc69.chunk.js"
  },
  {
    "revision": "6d89898a97f883b90c79",
    "url": "/static/js/33.0b02d846.chunk.js"
  },
  {
    "revision": "6bcdb26a8a06774d20f2",
    "url": "/static/js/34.350a7f72.chunk.js"
  },
  {
    "revision": "c39eedcf09532dcb6bee",
    "url": "/static/js/35.f6a16e07.chunk.js"
  },
  {
    "revision": "a6d184280080766d3041",
    "url": "/static/js/36.1bb1be13.chunk.js"
  },
  {
    "revision": "7ea6203340f259ef7794",
    "url": "/static/js/37.d6aaedb9.chunk.js"
  },
  {
    "revision": "34c3e2a5505f10f0bfa9",
    "url": "/static/js/38.298d7de3.chunk.js"
  },
  {
    "revision": "7fd2a8160d517572acde",
    "url": "/static/js/39.cf9c9849.chunk.js"
  },
  {
    "revision": "b21ed210aea5b43aebdc",
    "url": "/static/js/4.6e0b8448.chunk.js"
  },
  {
    "revision": "f05cc2b6065be055e1b1",
    "url": "/static/js/40.25563b54.chunk.js"
  },
  {
    "revision": "6358c78be2d7573e6533",
    "url": "/static/js/41.9a409323.chunk.js"
  },
  {
    "revision": "6894946c65c96cf450e5",
    "url": "/static/js/42.be37bf89.chunk.js"
  },
  {
    "revision": "ce56a07016111759a474",
    "url": "/static/js/43.c8dc610e.chunk.js"
  },
  {
    "revision": "433f9c8655ab8bb770f9",
    "url": "/static/js/44.74afef91.chunk.js"
  },
  {
    "revision": "09ac338680600812a4bf",
    "url": "/static/js/45.c4833dce.chunk.js"
  },
  {
    "revision": "bb7323b48161132b9760",
    "url": "/static/js/46.e1aa7235.chunk.js"
  },
  {
    "revision": "9071c8cc1c1f803cd32a",
    "url": "/static/js/47.aca03c25.chunk.js"
  },
  {
    "revision": "98c7bd3276f4d2320974",
    "url": "/static/js/48.24e03380.chunk.js"
  },
  {
    "revision": "a3fd7a879d01f9ef970c",
    "url": "/static/js/49.4809b377.chunk.js"
  },
  {
    "revision": "2ae4b7e672155caca9a5",
    "url": "/static/js/5.a7bda358.chunk.js"
  },
  {
    "revision": "06893f5dfea7eaeaeb06",
    "url": "/static/js/50.45367382.chunk.js"
  },
  {
    "revision": "fbc8720ff2acab1db6b3",
    "url": "/static/js/51.b4e260c9.chunk.js"
  },
  {
    "revision": "f050063b6254ca021c9e",
    "url": "/static/js/52.17789992.chunk.js"
  },
  {
    "revision": "814c50fa5c0a9011318c",
    "url": "/static/js/53.4d4ebd10.chunk.js"
  },
  {
    "revision": "94a3fcec7ad71e6ccafe",
    "url": "/static/js/54.8d50ad40.chunk.js"
  },
  {
    "revision": "8b548039359cda7529fa",
    "url": "/static/js/55.8c2c552f.chunk.js"
  },
  {
    "revision": "28ccc3caf1a2e82e1879",
    "url": "/static/js/56.89f4fe5d.chunk.js"
  },
  {
    "revision": "2ae5924db11f6dd55f44",
    "url": "/static/js/57.341c7b7c.chunk.js"
  },
  {
    "revision": "eec53468047bb8737ef9",
    "url": "/static/js/58.34337b49.chunk.js"
  },
  {
    "revision": "53d67e6956f6199f6617",
    "url": "/static/js/59.d9be8b2c.chunk.js"
  },
  {
    "revision": "befbea115e5cdb94ed74",
    "url": "/static/js/6.b36fdd9b.chunk.js"
  },
  {
    "revision": "4f4fd0f4f8e75eafe431",
    "url": "/static/js/60.02bb6578.chunk.js"
  },
  {
    "revision": "fd183bcef7e105690e88",
    "url": "/static/js/61.467d8a99.chunk.js"
  },
  {
    "revision": "bbd2f629858025c39ad8",
    "url": "/static/js/62.07a241e7.chunk.js"
  },
  {
    "revision": "92bac48af10d4bc429f3",
    "url": "/static/js/63.abd6157b.chunk.js"
  },
  {
    "revision": "b0e7694b4429e4777365",
    "url": "/static/js/64.ed37c5df.chunk.js"
  },
  {
    "revision": "cb9595b4478f2eae17e4",
    "url": "/static/js/65.87dcb007.chunk.js"
  },
  {
    "revision": "4a818f0a45d1f8951b8b",
    "url": "/static/js/66.948536ad.chunk.js"
  },
  {
    "revision": "072cedbcc0a3f874ef3e",
    "url": "/static/js/67.26f001c5.chunk.js"
  },
  {
    "revision": "63ce567b69a2e398838d",
    "url": "/static/js/68.f84df653.chunk.js"
  },
  {
    "revision": "066d4f23b098f0083149",
    "url": "/static/js/69.9d4380d4.chunk.js"
  },
  {
    "revision": "4b51dfeb55fb06b1bd4b",
    "url": "/static/js/7.e73e8810.chunk.js"
  },
  {
    "revision": "92588e3890a085ee4558",
    "url": "/static/js/70.c2c2e3be.chunk.js"
  },
  {
    "revision": "216a00233b7d79a7f84b",
    "url": "/static/js/71.f48beb9e.chunk.js"
  },
  {
    "revision": "8a1b019d0eb53bd49438",
    "url": "/static/js/72.524e9043.chunk.js"
  },
  {
    "revision": "48d226ed7a6f48abb147",
    "url": "/static/js/73.966b2c91.chunk.js"
  },
  {
    "revision": "cdf8969cdae10831ca47",
    "url": "/static/js/74.fccd3af6.chunk.js"
  },
  {
    "revision": "3d546e76a182f78da8e9",
    "url": "/static/js/75.870c8668.chunk.js"
  },
  {
    "revision": "2dbd658bdd16da561148",
    "url": "/static/js/76.f52f78eb.chunk.js"
  },
  {
    "revision": "ffffec351482dcfc9def",
    "url": "/static/js/77.9909037e.chunk.js"
  },
  {
    "revision": "90053d460c671eb7f1f7",
    "url": "/static/js/78.bd044c22.chunk.js"
  },
  {
    "revision": "286f1b7dbd0904ca1d96",
    "url": "/static/js/79.3ea240c5.chunk.js"
  },
  {
    "revision": "de5ed25fa0ab7a7a977b",
    "url": "/static/js/8.d9c1c03e.chunk.js"
  },
  {
    "revision": "d2c88203d7214e82e8d9",
    "url": "/static/js/80.7c4b00fe.chunk.js"
  },
  {
    "revision": "93a75acd39231fb3adad",
    "url": "/static/js/81.b57390c9.chunk.js"
  },
  {
    "revision": "514af448a56c2b014a8c",
    "url": "/static/js/82.239fd9b5.chunk.js"
  },
  {
    "revision": "aefd58fc636ca5823c30",
    "url": "/static/js/83.37eab591.chunk.js"
  },
  {
    "revision": "78c0f623d32a4f6e27c4",
    "url": "/static/js/84.848b3d2f.chunk.js"
  },
  {
    "revision": "ada15d51a482b521f062",
    "url": "/static/js/85.e8df3f3e.chunk.js"
  },
  {
    "revision": "8fd5993dfa43430cf953",
    "url": "/static/js/86.cb90090f.chunk.js"
  },
  {
    "revision": "3500950bd8621bb6d397",
    "url": "/static/js/87.e75ceeb8.chunk.js"
  },
  {
    "revision": "cd589c20c99ae717ee47",
    "url": "/static/js/88.c22075f5.chunk.js"
  },
  {
    "revision": "b61bdabed80a509903e3",
    "url": "/static/js/89.a5e2b526.chunk.js"
  },
  {
    "revision": "7197e4ec8dac95c0eb60",
    "url": "/static/js/9.5ebc064f.chunk.js"
  },
  {
    "revision": "0223e4f9641efc881ad1",
    "url": "/static/js/90.0524d5ee.chunk.js"
  },
  {
    "revision": "5248e4ddd13461282b3f",
    "url": "/static/js/91.7c9a5c5a.chunk.js"
  },
  {
    "revision": "8a68014a0a61f3fd1529",
    "url": "/static/js/92.49175b46.chunk.js"
  },
  {
    "revision": "c4892d5909d90aa2d1ae",
    "url": "/static/js/93.4d4af23b.chunk.js"
  },
  {
    "revision": "641850a11d363e99a50d",
    "url": "/static/js/94.14b9654f.chunk.js"
  },
  {
    "revision": "4d3730c810409f5df037",
    "url": "/static/js/95.d7f8863b.chunk.js"
  },
  {
    "revision": "3e4c4995ab086b6facf1",
    "url": "/static/js/96.f110e7e3.chunk.js"
  },
  {
    "revision": "140980a779d9ee073cd4",
    "url": "/static/js/97.2bfd3b7e.chunk.js"
  },
  {
    "revision": "975710d350873af180c9",
    "url": "/static/js/98.da618566.chunk.js"
  },
  {
    "revision": "96d387feb7b247945536",
    "url": "/static/js/99.878c50aa.chunk.js"
  },
  {
    "revision": "ac1e679ddaa384151271",
    "url": "/static/js/main.c7e3452d.chunk.js"
  },
  {
    "revision": "9ad2076e0dbde3d07460",
    "url": "/static/js/runtime~main.d5abb3cb.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);