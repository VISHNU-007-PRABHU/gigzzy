self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c7f2004aa2881f06bc5c1d06bbb9600b",
    "url": "/index.html"
  },
  {
    "revision": "37871d1143aeed648de1",
    "url": "/static/css/7.a8d8cd7e.chunk.css"
  },
  {
    "revision": "cebcd513a731a27c87d2",
    "url": "/static/css/main.7b113465.chunk.css"
  },
  {
    "revision": "f23ce813e9c260c065ba",
    "url": "/static/js/0.e755902b.chunk.js"
  },
  {
    "revision": "8e472724553ba46a7ddc",
    "url": "/static/js/1.06d07310.chunk.js"
  },
  {
    "revision": "d7575b6ebd37fe97b00c",
    "url": "/static/js/10.7399ef77.chunk.js"
  },
  {
    "revision": "dfab3a746a50c2e9ac22",
    "url": "/static/js/2.02366db8.chunk.js"
  },
  {
    "revision": "e516e1313ac4d003c3d5",
    "url": "/static/js/3.e6987312.chunk.js"
  },
  {
    "revision": "dc7f337ad520cb888e64",
    "url": "/static/js/4.07628253.chunk.js"
  },
  {
    "revision": "37871d1143aeed648de1",
    "url": "/static/js/7.8de9fe1a.chunk.js"
  },
  {
    "revision": "8090dd367e4264571259",
    "url": "/static/js/8.eff18594.chunk.js"
  },
  {
    "revision": "46a066d5622c344066e4",
    "url": "/static/js/9.e26fcb5e.chunk.js"
  },
  {
    "revision": "cebcd513a731a27c87d2",
    "url": "/static/js/main.0824ac12.chunk.js"
  },
  {
    "revision": "4bf1e01e1954bd9de309",
    "url": "/static/js/runtime~main.bffe2aee.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);