self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dd5a3479abcada6b2c73f7285a037321",
    "url": "/index.html"
  },
  {
    "revision": "08e4f27d30846dd9cb17",
    "url": "/static/css/8.8e9d1968.chunk.css"
  },
  {
    "revision": "09efe0c4aa4bbdb2fa00",
    "url": "/static/css/main.4de5a41d.chunk.css"
  },
  {
    "revision": "6b5321bceef24a3bcae2",
    "url": "/static/js/0.8415b8f6.chunk.js"
  },
  {
    "revision": "b4cacd425c4144a05eff",
    "url": "/static/js/1.028c4156.chunk.js"
  },
  {
    "revision": "883f5233c5fc047a3802",
    "url": "/static/js/10.f765e062.chunk.js"
  },
  {
    "revision": "09943d2121391ce9e9ac",
    "url": "/static/js/11.ac9563b7.chunk.js"
  },
  {
    "revision": "a14aa3168ec97a67d5b8",
    "url": "/static/js/12.a6af2f6f.chunk.js"
  },
  {
    "revision": "af9faad48e86344b3f04",
    "url": "/static/js/2.6aec5708.chunk.js"
  },
  {
    "revision": "d40819a0a172f68dce87",
    "url": "/static/js/3.539cb340.chunk.js"
  },
  {
    "revision": "76a5804d45e3df1a60fe",
    "url": "/static/js/4.4df1b9a9.chunk.js"
  },
  {
    "revision": "7be6037d4e9189987674",
    "url": "/static/js/5.bdfdec2d.chunk.js"
  },
  {
    "revision": "08e4f27d30846dd9cb17",
    "url": "/static/js/8.aeff0f35.chunk.js"
  },
  {
    "revision": "2d34dc24a55991b2a637",
    "url": "/static/js/9.a7380b25.chunk.js"
  },
  {
    "revision": "09efe0c4aa4bbdb2fa00",
    "url": "/static/js/main.1b954837.chunk.js"
  },
  {
    "revision": "5e7cba9678bae1a3d15d",
    "url": "/static/js/runtime~main.11594f63.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);