self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5243fe894b1903517f854e16ad9e2ce0",
    "url": "/index.html"
  },
  {
    "revision": "93f1813854ddc6417b74",
    "url": "/static/css/15.cb92d5d1.chunk.css"
  },
  {
    "revision": "d896d9076a53f855a22b",
    "url": "/static/css/main.10fe2d0a.chunk.css"
  },
  {
    "revision": "cce53af9b79db085a44f",
    "url": "/static/js/0.e37aaffd.chunk.js"
  },
  {
    "revision": "f9fb333def6600778437",
    "url": "/static/js/1.f0561356.chunk.js"
  },
  {
    "revision": "e86282e5936afde0b366",
    "url": "/static/js/10.09c49107.chunk.js"
  },
  {
    "revision": "d3cf05a7d87bcb653ae6",
    "url": "/static/js/11.8b7a7491.chunk.js"
  },
  {
    "revision": "cff600ce83cb783e44a8",
    "url": "/static/js/12.f674490a.chunk.js"
  },
  {
    "revision": "93f1813854ddc6417b74",
    "url": "/static/js/15.1896ee63.chunk.js"
  },
  {
    "revision": "676f2b97ae957aa2b475",
    "url": "/static/js/16.f2a0ca0f.chunk.js"
  },
  {
    "revision": "0f7850f6644e74ced47d",
    "url": "/static/js/17.9b7b67a4.chunk.js"
  },
  {
    "revision": "9ec5dd7256ef3e0e7f35",
    "url": "/static/js/18.6a28d902.chunk.js"
  },
  {
    "revision": "95fae1401caf623cb4eb",
    "url": "/static/js/19.b0234eae.chunk.js"
  },
  {
    "revision": "99f5f5de2ff2293bc8a8",
    "url": "/static/js/2.6542866a.chunk.js"
  },
  {
    "revision": "c4cd8a3dbe199f192721",
    "url": "/static/js/20.eb9ceca8.chunk.js"
  },
  {
    "revision": "9b694b4bc33060379c6f",
    "url": "/static/js/21.96de51ea.chunk.js"
  },
  {
    "revision": "98c10bb050747c2dac90",
    "url": "/static/js/22.81cf84ce.chunk.js"
  },
  {
    "revision": "a0a6bcd21e1102228236",
    "url": "/static/js/23.e779e8d1.chunk.js"
  },
  {
    "revision": "b2ce61b724f3cfad022c",
    "url": "/static/js/24.de4973d1.chunk.js"
  },
  {
    "revision": "a86ddad17a46c62ca2f0",
    "url": "/static/js/25.99f71ef4.chunk.js"
  },
  {
    "revision": "b92659c34972ddf56901",
    "url": "/static/js/26.65bf7a6d.chunk.js"
  },
  {
    "revision": "8af863c47ac39b73549f",
    "url": "/static/js/27.9a7e3258.chunk.js"
  },
  {
    "revision": "7226cc275c4de62b2b68",
    "url": "/static/js/28.fc9e244e.chunk.js"
  },
  {
    "revision": "0896e543abdd0963c835",
    "url": "/static/js/29.1cf55480.chunk.js"
  },
  {
    "revision": "f7dfedc6e5a8bf464976",
    "url": "/static/js/3.3866aa9d.chunk.js"
  },
  {
    "revision": "a8925065f823184a6614",
    "url": "/static/js/30.43c83aa9.chunk.js"
  },
  {
    "revision": "03805dd9df4cad3fc323",
    "url": "/static/js/31.381df8bc.chunk.js"
  },
  {
    "revision": "946467874e4dc69b385c",
    "url": "/static/js/32.b1908025.chunk.js"
  },
  {
    "revision": "e386040890b2e118acc5",
    "url": "/static/js/33.8af2bf8a.chunk.js"
  },
  {
    "revision": "8306c1a0237f13aa63fc",
    "url": "/static/js/34.6d48666c.chunk.js"
  },
  {
    "revision": "d8989a415418a863ac1f",
    "url": "/static/js/35.8ee4e902.chunk.js"
  },
  {
    "revision": "36fef262fd4d4b1b8a2b",
    "url": "/static/js/36.c00bff3d.chunk.js"
  },
  {
    "revision": "49a2989e46d5a6acbef2",
    "url": "/static/js/37.be108233.chunk.js"
  },
  {
    "revision": "867a2ea937141f9bac59",
    "url": "/static/js/38.7ce4ba48.chunk.js"
  },
  {
    "revision": "1d686aef116c1ed0408d",
    "url": "/static/js/39.bc2e7a3a.chunk.js"
  },
  {
    "revision": "96c42c49b9475459c739",
    "url": "/static/js/4.6e45ebff.chunk.js"
  },
  {
    "revision": "f650a7088cbe99ad3e6a",
    "url": "/static/js/40.b0f72f0d.chunk.js"
  },
  {
    "revision": "f8babc37412c57037877",
    "url": "/static/js/41.9b65fdd6.chunk.js"
  },
  {
    "revision": "83cace4cb9908cc0c83d",
    "url": "/static/js/42.b90a8426.chunk.js"
  },
  {
    "revision": "34978d79910c8737b0f8",
    "url": "/static/js/43.29ccc85a.chunk.js"
  },
  {
    "revision": "5d2cfcb4381274475aa4",
    "url": "/static/js/44.73a3f516.chunk.js"
  },
  {
    "revision": "f921c92c8221599921f6",
    "url": "/static/js/45.de32e4c3.chunk.js"
  },
  {
    "revision": "2825cf1209ec17813c7a",
    "url": "/static/js/46.1641d3f9.chunk.js"
  },
  {
    "revision": "83aa1b1316089f50af9a",
    "url": "/static/js/47.eab66e4c.chunk.js"
  },
  {
    "revision": "5fa25216e736960d51d2",
    "url": "/static/js/48.4f5ce851.chunk.js"
  },
  {
    "revision": "d9dfe1e3b35e5ee1af79",
    "url": "/static/js/49.96842b2d.chunk.js"
  },
  {
    "revision": "5f69b89eb5ec06e2b183",
    "url": "/static/js/5.9c8930e1.chunk.js"
  },
  {
    "revision": "8a8c648fea8dfeb249c8",
    "url": "/static/js/50.0bae6bd5.chunk.js"
  },
  {
    "revision": "22094472c332dfe41057",
    "url": "/static/js/51.5b95f684.chunk.js"
  },
  {
    "revision": "b3fbef63be78a2161c37",
    "url": "/static/js/52.452e1a09.chunk.js"
  },
  {
    "revision": "2f93089931769023e57e",
    "url": "/static/js/53.946669ca.chunk.js"
  },
  {
    "revision": "dc48f2b1c6712436f781",
    "url": "/static/js/54.904ed2cd.chunk.js"
  },
  {
    "revision": "ffba1e092c2576673190",
    "url": "/static/js/55.359aeb6a.chunk.js"
  },
  {
    "revision": "286d36efb187062faf8e",
    "url": "/static/js/56.0ed7aaa2.chunk.js"
  },
  {
    "revision": "63d977265e679a386e4d",
    "url": "/static/js/57.19fd3150.chunk.js"
  },
  {
    "revision": "6791b667c68f65620fe5",
    "url": "/static/js/58.df302c47.chunk.js"
  },
  {
    "revision": "8ad5e8538ed1c26e0260",
    "url": "/static/js/59.26f627bf.chunk.js"
  },
  {
    "revision": "f18310abbc3ec3b628bc",
    "url": "/static/js/6.d88bcfd6.chunk.js"
  },
  {
    "revision": "b70c1d6b79ede86d7dc6",
    "url": "/static/js/60.d8a026b4.chunk.js"
  },
  {
    "revision": "d235ee7d91572aa1bcf3",
    "url": "/static/js/61.e7f60eab.chunk.js"
  },
  {
    "revision": "230b38d41a304dce81e5",
    "url": "/static/js/62.8d531931.chunk.js"
  },
  {
    "revision": "5b30d37ef1e235a575ca",
    "url": "/static/js/63.fd1169da.chunk.js"
  },
  {
    "revision": "73ea51bb059c7996669e",
    "url": "/static/js/7.685591d4.chunk.js"
  },
  {
    "revision": "f84456c5207ba4ccefa4",
    "url": "/static/js/8.1a766534.chunk.js"
  },
  {
    "revision": "e4022eb7690f0a7414ac",
    "url": "/static/js/9.2fa13a60.chunk.js"
  },
  {
    "revision": "d896d9076a53f855a22b",
    "url": "/static/js/main.7bc3f421.chunk.js"
  },
  {
    "revision": "5cb1d1216f04ccebfc54",
    "url": "/static/js/runtime~main.ef3cb81e.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);