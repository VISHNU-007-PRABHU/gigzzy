self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "03f0ea048c03f2ec290ac7c34f4afea2",
    "url": "/index.html"
  },
  {
    "revision": "6272310ad4b691dd1363",
    "url": "/static/css/15.cb92d5d1.chunk.css"
  },
  {
    "revision": "110e2fa9970037af44ba",
    "url": "/static/css/main.10fe2d0a.chunk.css"
  },
  {
    "revision": "6c70186bab8362a558d4",
    "url": "/static/js/0.02dbb692.chunk.js"
  },
  {
    "revision": "f9fb333def6600778437",
    "url": "/static/js/1.f0561356.chunk.js"
  },
  {
    "revision": "63609c03d4a50d7a8c59",
    "url": "/static/js/10.e42ccef3.chunk.js"
  },
  {
    "revision": "d3cf05a7d87bcb653ae6",
    "url": "/static/js/11.8b7a7491.chunk.js"
  },
  {
    "revision": "cff600ce83cb783e44a8",
    "url": "/static/js/12.f674490a.chunk.js"
  },
  {
    "revision": "6272310ad4b691dd1363",
    "url": "/static/js/15.dd0d0ad3.chunk.js"
  },
  {
    "revision": "676f2b97ae957aa2b475",
    "url": "/static/js/16.f2a0ca0f.chunk.js"
  },
  {
    "revision": "afff0664846c7eea4165",
    "url": "/static/js/17.21dcacc9.chunk.js"
  },
  {
    "revision": "3c0f710594a2a89aee7a",
    "url": "/static/js/18.8e5c224a.chunk.js"
  },
  {
    "revision": "95fae1401caf623cb4eb",
    "url": "/static/js/19.b0234eae.chunk.js"
  },
  {
    "revision": "99f5f5de2ff2293bc8a8",
    "url": "/static/js/2.6542866a.chunk.js"
  },
  {
    "revision": "ed4649c526d31e55fe46",
    "url": "/static/js/20.e762b2f3.chunk.js"
  },
  {
    "revision": "6e2631ea1a790422d89b",
    "url": "/static/js/21.b88781c0.chunk.js"
  },
  {
    "revision": "a1afd6e2627bbbd67121",
    "url": "/static/js/22.4478f52c.chunk.js"
  },
  {
    "revision": "a0a6bcd21e1102228236",
    "url": "/static/js/23.e779e8d1.chunk.js"
  },
  {
    "revision": "8448bf7b4574795b9100",
    "url": "/static/js/24.eaca06c7.chunk.js"
  },
  {
    "revision": "11fd294f982ff635033c",
    "url": "/static/js/25.75dd770d.chunk.js"
  },
  {
    "revision": "b92659c34972ddf56901",
    "url": "/static/js/26.65bf7a6d.chunk.js"
  },
  {
    "revision": "d6f83c88a882938f70c3",
    "url": "/static/js/27.f1d7bf27.chunk.js"
  },
  {
    "revision": "6feb133e34d6dff5d5cf",
    "url": "/static/js/28.3546aa29.chunk.js"
  },
  {
    "revision": "1c95fd8c824687e6c73d",
    "url": "/static/js/29.99bd20f4.chunk.js"
  },
  {
    "revision": "f7dfedc6e5a8bf464976",
    "url": "/static/js/3.3866aa9d.chunk.js"
  },
  {
    "revision": "136ed3e8bfcfb5f7c06a",
    "url": "/static/js/30.cf94bf50.chunk.js"
  },
  {
    "revision": "f780560536672a232990",
    "url": "/static/js/31.b258c01d.chunk.js"
  },
  {
    "revision": "60fe05547a5fd8078dbb",
    "url": "/static/js/32.5ab35e9b.chunk.js"
  },
  {
    "revision": "400af5205e9ccb89a969",
    "url": "/static/js/33.c1d0b99a.chunk.js"
  },
  {
    "revision": "96ccda85cfe67d691441",
    "url": "/static/js/34.49bf2bf2.chunk.js"
  },
  {
    "revision": "e665a6f4c4af00ef2723",
    "url": "/static/js/35.5104a509.chunk.js"
  },
  {
    "revision": "5a415c26e15860c33eac",
    "url": "/static/js/36.be795244.chunk.js"
  },
  {
    "revision": "49a2989e46d5a6acbef2",
    "url": "/static/js/37.be108233.chunk.js"
  },
  {
    "revision": "6c75836ae9afd4e3be86",
    "url": "/static/js/38.2539f9dd.chunk.js"
  },
  {
    "revision": "1d686aef116c1ed0408d",
    "url": "/static/js/39.bc2e7a3a.chunk.js"
  },
  {
    "revision": "96c42c49b9475459c739",
    "url": "/static/js/4.6e45ebff.chunk.js"
  },
  {
    "revision": "8b727decbbc7c7456fe4",
    "url": "/static/js/40.819b8d92.chunk.js"
  },
  {
    "revision": "f8babc37412c57037877",
    "url": "/static/js/41.9b65fdd6.chunk.js"
  },
  {
    "revision": "06842615a21d876ef97c",
    "url": "/static/js/42.c738ffc4.chunk.js"
  },
  {
    "revision": "df8f2cea2072dcb2c268",
    "url": "/static/js/43.5ef1c1e3.chunk.js"
  },
  {
    "revision": "ab7e6be71ebd8d09d2d8",
    "url": "/static/js/44.bd79c5d8.chunk.js"
  },
  {
    "revision": "f921c92c8221599921f6",
    "url": "/static/js/45.de32e4c3.chunk.js"
  },
  {
    "revision": "2825cf1209ec17813c7a",
    "url": "/static/js/46.1641d3f9.chunk.js"
  },
  {
    "revision": "83aa1b1316089f50af9a",
    "url": "/static/js/47.eab66e4c.chunk.js"
  },
  {
    "revision": "8e289a44e5bba583f49a",
    "url": "/static/js/48.57545cbb.chunk.js"
  },
  {
    "revision": "d9dfe1e3b35e5ee1af79",
    "url": "/static/js/49.96842b2d.chunk.js"
  },
  {
    "revision": "5f69b89eb5ec06e2b183",
    "url": "/static/js/5.9c8930e1.chunk.js"
  },
  {
    "revision": "8a8c648fea8dfeb249c8",
    "url": "/static/js/50.0bae6bd5.chunk.js"
  },
  {
    "revision": "ec19f154e03824561a36",
    "url": "/static/js/51.28bca7ac.chunk.js"
  },
  {
    "revision": "47c52d13937621021d62",
    "url": "/static/js/52.356f733e.chunk.js"
  },
  {
    "revision": "5804b25082604a0ed59d",
    "url": "/static/js/53.5fc5c563.chunk.js"
  },
  {
    "revision": "9d05dc30b0fdebe17619",
    "url": "/static/js/54.302f86b4.chunk.js"
  },
  {
    "revision": "ffba1e092c2576673190",
    "url": "/static/js/55.359aeb6a.chunk.js"
  },
  {
    "revision": "79f9dad66fdd2f13c5c6",
    "url": "/static/js/56.cef7e6c1.chunk.js"
  },
  {
    "revision": "c2a8ad2297335e218ec4",
    "url": "/static/js/57.fd9d727d.chunk.js"
  },
  {
    "revision": "f203fbf67b715686b076",
    "url": "/static/js/58.0e51a26b.chunk.js"
  },
  {
    "revision": "736b93f8528f19ad1455",
    "url": "/static/js/59.2f7910e4.chunk.js"
  },
  {
    "revision": "f18310abbc3ec3b628bc",
    "url": "/static/js/6.d88bcfd6.chunk.js"
  },
  {
    "revision": "7fa73f623ae91aa88713",
    "url": "/static/js/60.b41e4d6f.chunk.js"
  },
  {
    "revision": "629774ad56ed68471e35",
    "url": "/static/js/61.d7e8159b.chunk.js"
  },
  {
    "revision": "6a20b9209f1948fdf250",
    "url": "/static/js/62.a595dcc6.chunk.js"
  },
  {
    "revision": "ce74128048b6c6c4643d",
    "url": "/static/js/63.1c0f6658.chunk.js"
  },
  {
    "revision": "73ea51bb059c7996669e",
    "url": "/static/js/7.685591d4.chunk.js"
  },
  {
    "revision": "f84456c5207ba4ccefa4",
    "url": "/static/js/8.1a766534.chunk.js"
  },
  {
    "revision": "3ad1090f2db2fc3429f6",
    "url": "/static/js/9.7c74a51b.chunk.js"
  },
  {
    "revision": "110e2fa9970037af44ba",
    "url": "/static/js/main.db776f59.chunk.js"
  },
  {
    "revision": "f38ac0e22dd4018ce5de",
    "url": "/static/js/runtime~main.f16af9f6.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);