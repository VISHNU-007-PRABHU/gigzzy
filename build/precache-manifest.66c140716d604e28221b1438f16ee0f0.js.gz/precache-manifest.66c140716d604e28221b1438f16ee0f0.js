self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "80ce6bef490722b96db2052f927567dc",
    "url": "/index.html"
  },
  {
    "revision": "e7d2916294b4a8cba227",
    "url": "/static/css/19.cdaf15d1.chunk.css"
  },
  {
    "revision": "173df9ec5d245da7b3cd",
    "url": "/static/css/28.051905ae.chunk.css"
  },
  {
    "revision": "9b611735a91652805ef8",
    "url": "/static/css/29.3a6be942.chunk.css"
  },
  {
    "revision": "fffed94404b2b02b416d",
    "url": "/static/css/30.88292131.chunk.css"
  },
  {
    "revision": "749404510bc4dfd01f9b",
    "url": "/static/css/35.c9556fed.chunk.css"
  },
  {
    "revision": "915c38e08db95f9cca4c",
    "url": "/static/css/37.11000f17.chunk.css"
  },
  {
    "revision": "63f00cd0bc2ef92f420f",
    "url": "/static/css/40.11000f17.chunk.css"
  },
  {
    "revision": "a4a980a490e4326bc096",
    "url": "/static/css/45.52c43222.chunk.css"
  },
  {
    "revision": "3ccb004f44f93b354388",
    "url": "/static/css/46.8ec2e1e7.chunk.css"
  },
  {
    "revision": "b34caa736b19084ca7e1",
    "url": "/static/css/50.f9b90304.chunk.css"
  },
  {
    "revision": "1890a3a5b5e01047360b",
    "url": "/static/css/51.11000f17.chunk.css"
  },
  {
    "revision": "7a07e2e6820bc8cd6412",
    "url": "/static/css/53.9142c0f9.chunk.css"
  },
  {
    "revision": "de73d5555ab298ade52b",
    "url": "/static/css/54.9142c0f9.chunk.css"
  },
  {
    "revision": "ba3171a50c3ac4bc85f6",
    "url": "/static/css/55.0724d5f1.chunk.css"
  },
  {
    "revision": "f1a153397050c4332749",
    "url": "/static/css/56.3a6be942.chunk.css"
  },
  {
    "revision": "04ba03d61e4c909a3728",
    "url": "/static/css/57.3a6be942.chunk.css"
  },
  {
    "revision": "e9f81b3a4121c7eedc19",
    "url": "/static/css/61.cdaf15d1.chunk.css"
  },
  {
    "revision": "53a395ca6dd41cb9e1ff",
    "url": "/static/css/63.5b5fb56a.chunk.css"
  },
  {
    "revision": "5b15c20dd5b8ce99369e",
    "url": "/static/css/main.84c18709.chunk.css"
  },
  {
    "revision": "79ddefaa7686878badb6",
    "url": "/static/js/0.c9285907.chunk.js"
  },
  {
    "revision": "c8f001d170507efef604",
    "url": "/static/js/1.b0acd817.chunk.js"
  },
  {
    "revision": "d8f7900a50c3ad35bcae",
    "url": "/static/js/10.5d0cc81d.chunk.js"
  },
  {
    "revision": "ae9cd0406ce4344245ff",
    "url": "/static/js/100.36eab5a8.chunk.js"
  },
  {
    "revision": "3f3a4707a6fe07c2aa6f",
    "url": "/static/js/101.fba4413d.chunk.js"
  },
  {
    "revision": "c2b21132712cbbba99ce",
    "url": "/static/js/102.5da715a4.chunk.js"
  },
  {
    "revision": "c02cd4eb3c0e306d2cb2",
    "url": "/static/js/103.024eabaa.chunk.js"
  },
  {
    "revision": "c2ebcaf541784b68b56f",
    "url": "/static/js/104.25d23a50.chunk.js"
  },
  {
    "revision": "fadac733648e2a956fab",
    "url": "/static/js/105.5a313a38.chunk.js"
  },
  {
    "revision": "0380729be1c9f15b2211",
    "url": "/static/js/106.d6539cc0.chunk.js"
  },
  {
    "revision": "84adbc973e89c41a1060",
    "url": "/static/js/107.3a6d0e35.chunk.js"
  },
  {
    "revision": "cf1344c37960d46bdf96",
    "url": "/static/js/108.e0dc8db2.chunk.js"
  },
  {
    "revision": "95fbbea1202a11717a48",
    "url": "/static/js/109.d1a538af.chunk.js"
  },
  {
    "revision": "123e74f27490b7b6f55f",
    "url": "/static/js/11.b0993c46.chunk.js"
  },
  {
    "revision": "b0bbf5cbce68a321690f",
    "url": "/static/js/110.777efe3a.chunk.js"
  },
  {
    "revision": "eb34a9fc0da08e1a68aa",
    "url": "/static/js/111.7e95dc59.chunk.js"
  },
  {
    "revision": "9db4d93c078a520fc593",
    "url": "/static/js/112.bdde8f1c.chunk.js"
  },
  {
    "revision": "4175cb81f4a003c9ba33",
    "url": "/static/js/113.5d352e16.chunk.js"
  },
  {
    "revision": "f6eb495c0b14c6aa4ca2",
    "url": "/static/js/114.9766e353.chunk.js"
  },
  {
    "revision": "9c26a83f64b401523823",
    "url": "/static/js/115.4312afbb.chunk.js"
  },
  {
    "revision": "901e23fcd953922e4448",
    "url": "/static/js/116.8c683d75.chunk.js"
  },
  {
    "revision": "fd2812069d60ff9ec15a",
    "url": "/static/js/117.df96d8a9.chunk.js"
  },
  {
    "revision": "d1de20b483aa56bf31bb",
    "url": "/static/js/12.297ed07d.chunk.js"
  },
  {
    "revision": "ae00abf3542c854e65c0",
    "url": "/static/js/13.466eda38.chunk.js"
  },
  {
    "revision": "3943a9e74190cc1a3d3e",
    "url": "/static/js/14.3648cc7d.chunk.js"
  },
  {
    "revision": "89a1c683d82cb754a35d",
    "url": "/static/js/15.1e6e47be.chunk.js"
  },
  {
    "revision": "839100b2df97e922aabd",
    "url": "/static/js/16.34a3b16a.chunk.js"
  },
  {
    "revision": "ed2d0e8e92acce0b8ba3",
    "url": "/static/js/17.a8c6d529.chunk.js"
  },
  {
    "revision": "ec4cf60318486ba1594b",
    "url": "/static/js/18.2422693e.chunk.js"
  },
  {
    "revision": "e7d2916294b4a8cba227",
    "url": "/static/js/19.02cccea2.chunk.js"
  },
  {
    "revision": "19d7ed41148ab6917b49",
    "url": "/static/js/2.cae4627b.chunk.js"
  },
  {
    "revision": "edf4011e7a9a5c712d06",
    "url": "/static/js/20.62a164dc.chunk.js"
  },
  {
    "revision": "fd66171372cfdfeb58f1",
    "url": "/static/js/21.242f0273.chunk.js"
  },
  {
    "revision": "2a1cccb4920cc6b0b7e2",
    "url": "/static/js/22.66f82233.chunk.js"
  },
  {
    "revision": "ab320a095b45112b26f8",
    "url": "/static/js/23.32ad748b.chunk.js"
  },
  {
    "revision": "8d36c4c544c234e49aa9",
    "url": "/static/js/24.056027a7.chunk.js"
  },
  {
    "revision": "71d53d4f43676be7e287",
    "url": "/static/js/25.d1f3a915.chunk.js"
  },
  {
    "revision": "173df9ec5d245da7b3cd",
    "url": "/static/js/28.9a678e86.chunk.js"
  },
  {
    "revision": "9b611735a91652805ef8",
    "url": "/static/js/29.41611f76.chunk.js"
  },
  {
    "revision": "348250c8de18422a97c9",
    "url": "/static/js/3.519d0da2.chunk.js"
  },
  {
    "revision": "fffed94404b2b02b416d",
    "url": "/static/js/30.e604ad13.chunk.js"
  },
  {
    "revision": "ba126445c9f22f150e2e",
    "url": "/static/js/31.5dd624d2.chunk.js"
  },
  {
    "revision": "83d4005afa53db376061",
    "url": "/static/js/32.44709b2d.chunk.js"
  },
  {
    "revision": "1cd3fb9d144e907c2dec",
    "url": "/static/js/33.cf9dae87.chunk.js"
  },
  {
    "revision": "e776d68bc3a9a928fda0",
    "url": "/static/js/34.f342a8e8.chunk.js"
  },
  {
    "revision": "749404510bc4dfd01f9b",
    "url": "/static/js/35.a975f603.chunk.js"
  },
  {
    "revision": "e1f2220e3881612b7392",
    "url": "/static/js/36.87b73ed7.chunk.js"
  },
  {
    "revision": "915c38e08db95f9cca4c",
    "url": "/static/js/37.aaeb625f.chunk.js"
  },
  {
    "revision": "b7926cf6cc4f471360f6",
    "url": "/static/js/38.18f20d9c.chunk.js"
  },
  {
    "revision": "5499157182a30596ce0f",
    "url": "/static/js/39.1f9c21fe.chunk.js"
  },
  {
    "revision": "ff7cf943d87e639d6b28",
    "url": "/static/js/4.2675ee8f.chunk.js"
  },
  {
    "revision": "63f00cd0bc2ef92f420f",
    "url": "/static/js/40.4f7c736a.chunk.js"
  },
  {
    "revision": "bd4c5577db8890249972",
    "url": "/static/js/41.bcc8b408.chunk.js"
  },
  {
    "revision": "f52fbba7915002e0bd2a",
    "url": "/static/js/42.93930b5c.chunk.js"
  },
  {
    "revision": "18e0461a4bce52382d69",
    "url": "/static/js/43.1afb500c.chunk.js"
  },
  {
    "revision": "64071c36ac764cc7bb19",
    "url": "/static/js/44.6fde21c6.chunk.js"
  },
  {
    "revision": "a4a980a490e4326bc096",
    "url": "/static/js/45.8837d3e6.chunk.js"
  },
  {
    "revision": "3ccb004f44f93b354388",
    "url": "/static/js/46.63ec85d9.chunk.js"
  },
  {
    "revision": "297e5b87101735357ff9",
    "url": "/static/js/47.6e4a70b7.chunk.js"
  },
  {
    "revision": "e41c492e8f9a4a08e643",
    "url": "/static/js/48.bd1456c6.chunk.js"
  },
  {
    "revision": "782211d31039219cfc2a",
    "url": "/static/js/49.17295bfa.chunk.js"
  },
  {
    "revision": "26830e60136867da9a90",
    "url": "/static/js/5.0e67a507.chunk.js"
  },
  {
    "revision": "b34caa736b19084ca7e1",
    "url": "/static/js/50.666c5a7f.chunk.js"
  },
  {
    "revision": "1890a3a5b5e01047360b",
    "url": "/static/js/51.4dd39296.chunk.js"
  },
  {
    "revision": "f56a88b0c891d7b50984",
    "url": "/static/js/52.5b3fb678.chunk.js"
  },
  {
    "revision": "7a07e2e6820bc8cd6412",
    "url": "/static/js/53.d8edf1b9.chunk.js"
  },
  {
    "revision": "de73d5555ab298ade52b",
    "url": "/static/js/54.fb76f630.chunk.js"
  },
  {
    "revision": "ba3171a50c3ac4bc85f6",
    "url": "/static/js/55.7fdc4c47.chunk.js"
  },
  {
    "revision": "f1a153397050c4332749",
    "url": "/static/js/56.ad64fe2a.chunk.js"
  },
  {
    "revision": "04ba03d61e4c909a3728",
    "url": "/static/js/57.09d0cf60.chunk.js"
  },
  {
    "revision": "34b1c861a677ee5f1301",
    "url": "/static/js/58.588f5045.chunk.js"
  },
  {
    "revision": "0479d431ba38fcf7a90b",
    "url": "/static/js/59.9af8c0b5.chunk.js"
  },
  {
    "revision": "ef1727af88cf02dacff1",
    "url": "/static/js/6.e4b0f85c.chunk.js"
  },
  {
    "revision": "6cb4dfbc838b3a2b9385",
    "url": "/static/js/60.11a379f0.chunk.js"
  },
  {
    "revision": "e9f81b3a4121c7eedc19",
    "url": "/static/js/61.7304032b.chunk.js"
  },
  {
    "revision": "7ed5ae904e5152fb75d6",
    "url": "/static/js/62.7f537d01.chunk.js"
  },
  {
    "revision": "53a395ca6dd41cb9e1ff",
    "url": "/static/js/63.e70898ef.chunk.js"
  },
  {
    "revision": "4a113360e9d7211159f1",
    "url": "/static/js/64.db9f9039.chunk.js"
  },
  {
    "revision": "a0d3f9c9476ff96b6b1a",
    "url": "/static/js/65.bb33362c.chunk.js"
  },
  {
    "revision": "41597cc2fd26483c738b",
    "url": "/static/js/66.d30c329e.chunk.js"
  },
  {
    "revision": "728b0c90d055a222bc43",
    "url": "/static/js/67.acf7fddb.chunk.js"
  },
  {
    "revision": "fbf27591af7dcf9a9a16",
    "url": "/static/js/68.7652b569.chunk.js"
  },
  {
    "revision": "046a8b04785ef25afeca",
    "url": "/static/js/69.4ce6dfe8.chunk.js"
  },
  {
    "revision": "d3accd205b848acaf113",
    "url": "/static/js/7.d0eaea8d.chunk.js"
  },
  {
    "revision": "957b4948b07f69760762",
    "url": "/static/js/70.15611f43.chunk.js"
  },
  {
    "revision": "0558af588e24c54d8626",
    "url": "/static/js/71.2c06bc78.chunk.js"
  },
  {
    "revision": "f3db199f7c1e1cf56b84",
    "url": "/static/js/72.b390c9bc.chunk.js"
  },
  {
    "revision": "db27b71ce534c69ec6a0",
    "url": "/static/js/73.efb83b72.chunk.js"
  },
  {
    "revision": "baeff478b24acbc4eb90",
    "url": "/static/js/74.f168f2a0.chunk.js"
  },
  {
    "revision": "adf7d9f6fa2297a090ae",
    "url": "/static/js/75.4055403e.chunk.js"
  },
  {
    "revision": "bb18c924aabe768eecce",
    "url": "/static/js/76.17ee7c2a.chunk.js"
  },
  {
    "revision": "f4744e50e937a911f60f",
    "url": "/static/js/77.e1d913cc.chunk.js"
  },
  {
    "revision": "84917d5f414e42727ca5",
    "url": "/static/js/78.f699bef2.chunk.js"
  },
  {
    "revision": "0a5df412ce06b2fc1e97",
    "url": "/static/js/79.addd1317.chunk.js"
  },
  {
    "revision": "fc1f8d267f5c9b334c34",
    "url": "/static/js/8.ee155d5c.chunk.js"
  },
  {
    "revision": "db573bef6c9c9e167550",
    "url": "/static/js/80.df50d79d.chunk.js"
  },
  {
    "revision": "0442740bc1150bd26cf1",
    "url": "/static/js/81.bc48e1e7.chunk.js"
  },
  {
    "revision": "2dc698f5be753d5eb801",
    "url": "/static/js/82.98dd671d.chunk.js"
  },
  {
    "revision": "688f77c34973907500bf",
    "url": "/static/js/83.73830859.chunk.js"
  },
  {
    "revision": "3c8079a91617a15e9d25",
    "url": "/static/js/84.27be41c4.chunk.js"
  },
  {
    "revision": "22ca84ced3143fa98f4b",
    "url": "/static/js/85.6c64b0ee.chunk.js"
  },
  {
    "revision": "b55cc73cf88c6983184b",
    "url": "/static/js/86.3115afa3.chunk.js"
  },
  {
    "revision": "0750ff6cbac4d41a4e9c",
    "url": "/static/js/87.99d5ecb5.chunk.js"
  },
  {
    "revision": "07d595875fbc3bebdd24",
    "url": "/static/js/88.9b0e8483.chunk.js"
  },
  {
    "revision": "7fea132c9bfa6d17f1ca",
    "url": "/static/js/89.2e398531.chunk.js"
  },
  {
    "revision": "25b13353648601778c7c",
    "url": "/static/js/9.d0be3fba.chunk.js"
  },
  {
    "revision": "ebc261d98b1300a6c69c",
    "url": "/static/js/90.52407255.chunk.js"
  },
  {
    "revision": "314152152f4c3f5350f9",
    "url": "/static/js/91.7f9a1c22.chunk.js"
  },
  {
    "revision": "e4c3fc274732075d8e1f",
    "url": "/static/js/92.289ff874.chunk.js"
  },
  {
    "revision": "ef74a792c737de5d3a40",
    "url": "/static/js/93.98950085.chunk.js"
  },
  {
    "revision": "1c3f6e4ef6dfcd6e8c18",
    "url": "/static/js/94.da4f980b.chunk.js"
  },
  {
    "revision": "0531d57268c2c53cc768",
    "url": "/static/js/95.a43d2665.chunk.js"
  },
  {
    "revision": "1e5c47daddf7769ed4a5",
    "url": "/static/js/96.9d97a8c3.chunk.js"
  },
  {
    "revision": "f75c6294a0128813fb56",
    "url": "/static/js/97.e7fdf90f.chunk.js"
  },
  {
    "revision": "6c90a4fdbd83e0a1a89d",
    "url": "/static/js/98.1f75717e.chunk.js"
  },
  {
    "revision": "bfe36b9df9493faa9bd3",
    "url": "/static/js/99.59084728.chunk.js"
  },
  {
    "revision": "5b15c20dd5b8ce99369e",
    "url": "/static/js/main.b49f6c37.chunk.js"
  },
  {
    "revision": "36809e72b9c2d5b480f2",
    "url": "/static/js/runtime~main.94987240.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);