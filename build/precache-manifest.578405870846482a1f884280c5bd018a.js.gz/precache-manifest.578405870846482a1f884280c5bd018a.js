self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7c05cc7b7eb579d8171f19f226d4680a",
    "url": "/index.html"
  },
  {
    "revision": "8e1f3ce31d76299d9056",
    "url": "/static/css/12.c5dfc968.chunk.css"
  },
  {
    "revision": "c4a1c42028dbd383df88",
    "url": "/static/css/main.cd7a669d.chunk.css"
  },
  {
    "revision": "dda6341c28ff03364077",
    "url": "/static/js/0.11143aca.chunk.js"
  },
  {
    "revision": "2bb1991248611cbed3bc",
    "url": "/static/js/1.3997a550.chunk.js"
  },
  {
    "revision": "8e1f3ce31d76299d9056",
    "url": "/static/js/12.960f8154.chunk.js"
  },
  {
    "revision": "7181fafa54835e642e6d",
    "url": "/static/js/13.393f9d66.chunk.js"
  },
  {
    "revision": "320456fa847be83f19b5",
    "url": "/static/js/14.01a84d93.chunk.js"
  },
  {
    "revision": "1f9c1ffa07df63a1eba3",
    "url": "/static/js/15.3068a9ee.chunk.js"
  },
  {
    "revision": "3c415891d659d7010cb5",
    "url": "/static/js/16.0ee3451b.chunk.js"
  },
  {
    "revision": "30c30d734b8ddafa54f1",
    "url": "/static/js/17.7ea47821.chunk.js"
  },
  {
    "revision": "81634a0f425efb216e59",
    "url": "/static/js/18.dfe10963.chunk.js"
  },
  {
    "revision": "0434b7b6dee11550ebf0",
    "url": "/static/js/19.eed7d920.chunk.js"
  },
  {
    "revision": "b7e835edb62f361af007",
    "url": "/static/js/2.8ce09c83.chunk.js"
  },
  {
    "revision": "427f15bca71b08c2354d",
    "url": "/static/js/20.abd62455.chunk.js"
  },
  {
    "revision": "70c22e58ea234c7edeb9",
    "url": "/static/js/21.50fe5597.chunk.js"
  },
  {
    "revision": "dbd797099428ed4da260",
    "url": "/static/js/22.1cc94344.chunk.js"
  },
  {
    "revision": "858f1f75f6648edbc1f9",
    "url": "/static/js/23.cc0a4db7.chunk.js"
  },
  {
    "revision": "656fa45c7dc51c5aa72a",
    "url": "/static/js/24.80279924.chunk.js"
  },
  {
    "revision": "9ab90946e4baaba20ba0",
    "url": "/static/js/25.9530ec7a.chunk.js"
  },
  {
    "revision": "300d6836c485f5b43e6c",
    "url": "/static/js/26.920e3d6e.chunk.js"
  },
  {
    "revision": "3b5c5a0e6ab41f3b0404",
    "url": "/static/js/27.6c0329e8.chunk.js"
  },
  {
    "revision": "70b0438e80a188c259be",
    "url": "/static/js/28.04d4bcf4.chunk.js"
  },
  {
    "revision": "583a6de3c1166943d51b",
    "url": "/static/js/29.ac7f0088.chunk.js"
  },
  {
    "revision": "0f6509b8e3810d2c6f78",
    "url": "/static/js/3.fd0bba78.chunk.js"
  },
  {
    "revision": "11aeb28057d717bc312d",
    "url": "/static/js/30.69c62248.chunk.js"
  },
  {
    "revision": "ba6cf8061b6d1b96d947",
    "url": "/static/js/31.578e45ee.chunk.js"
  },
  {
    "revision": "7ff69a6e51cc53576224",
    "url": "/static/js/32.a6f2b4a3.chunk.js"
  },
  {
    "revision": "faeaff4160f59660801b",
    "url": "/static/js/33.ca48aad2.chunk.js"
  },
  {
    "revision": "c5a726f403a17451d3ae",
    "url": "/static/js/34.c9058837.chunk.js"
  },
  {
    "revision": "103e0263ec98872f1b05",
    "url": "/static/js/4.6c5cb419.chunk.js"
  },
  {
    "revision": "83de583085207e589367",
    "url": "/static/js/5.9a1f4975.chunk.js"
  },
  {
    "revision": "6074559a2ca7d2cdc837",
    "url": "/static/js/6.488c7226.chunk.js"
  },
  {
    "revision": "c7bb61e23ee82917c7a2",
    "url": "/static/js/7.b15c01f3.chunk.js"
  },
  {
    "revision": "616a311880f72eb78db7",
    "url": "/static/js/8.6ef00b7d.chunk.js"
  },
  {
    "revision": "50228ff09a3055860266",
    "url": "/static/js/9.7757eb5b.chunk.js"
  },
  {
    "revision": "c4a1c42028dbd383df88",
    "url": "/static/js/main.6545ec10.chunk.js"
  },
  {
    "revision": "04a25f6183e2112936b8",
    "url": "/static/js/runtime~main.08578208.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);