self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "01dae9470f79a577f9870143978c05ae",
    "url": "/index.html"
  },
  {
    "revision": "c47b41172aaa609e70b0",
    "url": "/static/css/10.0bd17c9b.chunk.css"
  },
  {
    "revision": "fd02ff641ed82c87343f",
    "url": "/static/css/main.d2e951f7.chunk.css"
  },
  {
    "revision": "f1b96a0e6d570b77029d",
    "url": "/static/js/0.583f9b4d.chunk.js"
  },
  {
    "revision": "7128ec74ada8896bfd3c",
    "url": "/static/js/1.b3f064f4.chunk.js"
  },
  {
    "revision": "c47b41172aaa609e70b0",
    "url": "/static/js/10.4b267a33.chunk.js"
  },
  {
    "revision": "bb27371330e5c77a7171",
    "url": "/static/js/11.cd100ede.chunk.js"
  },
  {
    "revision": "43ddfc5908ba2f938f4f",
    "url": "/static/js/12.e28f4ce8.chunk.js"
  },
  {
    "revision": "c8fe9da9b6e49e95036a",
    "url": "/static/js/13.60bb61cc.chunk.js"
  },
  {
    "revision": "a0f7fd48cb86dbfbde6b",
    "url": "/static/js/14.9ac5d9a4.chunk.js"
  },
  {
    "revision": "125c88734d3e2f6ab1c2",
    "url": "/static/js/15.40330243.chunk.js"
  },
  {
    "revision": "96cf0db533a7bb430862",
    "url": "/static/js/16.945b61b1.chunk.js"
  },
  {
    "revision": "eafcc0d17966728e5989",
    "url": "/static/js/17.e02be134.chunk.js"
  },
  {
    "revision": "6dcda33d6d6b30a51fee",
    "url": "/static/js/18.477aefe7.chunk.js"
  },
  {
    "revision": "9c3200d42eb5956f87c6",
    "url": "/static/js/19.087c8027.chunk.js"
  },
  {
    "revision": "16caf44e226a186a5f0d",
    "url": "/static/js/2.f34a47ea.chunk.js"
  },
  {
    "revision": "ac7d69e8f2614f1b54b3",
    "url": "/static/js/20.1a31febf.chunk.js"
  },
  {
    "revision": "ed9f8a60332d43fdd85d",
    "url": "/static/js/21.a656dd59.chunk.js"
  },
  {
    "revision": "7b551b436751755aa1c8",
    "url": "/static/js/22.2a5f88ce.chunk.js"
  },
  {
    "revision": "f66849a5945a18638601",
    "url": "/static/js/23.2b350472.chunk.js"
  },
  {
    "revision": "a8ac010e7f3666d77818",
    "url": "/static/js/24.2b38fbd8.chunk.js"
  },
  {
    "revision": "09200cb29b7787166a41",
    "url": "/static/js/25.5474fda1.chunk.js"
  },
  {
    "revision": "3da04f8486bc3d952b5f",
    "url": "/static/js/26.8389c9e5.chunk.js"
  },
  {
    "revision": "52abaae4a0ce800f5c81",
    "url": "/static/js/27.4116fc71.chunk.js"
  },
  {
    "revision": "123ea3af32858c342538",
    "url": "/static/js/28.a2e4a46b.chunk.js"
  },
  {
    "revision": "f4ad9c5642416bde4859",
    "url": "/static/js/29.8ca7c175.chunk.js"
  },
  {
    "revision": "ba8781f4b87586f9ec3a",
    "url": "/static/js/3.9518390e.chunk.js"
  },
  {
    "revision": "1802a02831a2b423259c",
    "url": "/static/js/30.98e6f2d0.chunk.js"
  },
  {
    "revision": "ab918d0228e69fa28646",
    "url": "/static/js/31.5770382f.chunk.js"
  },
  {
    "revision": "aa29151b3b6368daf862",
    "url": "/static/js/4.309e2324.chunk.js"
  },
  {
    "revision": "3b36b5aca04cc122b3db",
    "url": "/static/js/5.be9bafb2.chunk.js"
  },
  {
    "revision": "617f4fe5bcc0551790e4",
    "url": "/static/js/6.178d7816.chunk.js"
  },
  {
    "revision": "38397561d557ff1c4a4a",
    "url": "/static/js/7.61b54cfd.chunk.js"
  },
  {
    "revision": "fd02ff641ed82c87343f",
    "url": "/static/js/main.6143c1f3.chunk.js"
  },
  {
    "revision": "5b49537b96ef94577303",
    "url": "/static/js/runtime~main.c6c385f7.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);