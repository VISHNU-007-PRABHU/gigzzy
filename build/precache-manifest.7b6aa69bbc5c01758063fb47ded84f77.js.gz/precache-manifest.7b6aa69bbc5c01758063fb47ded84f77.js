self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "144d0f910b3ff465f01d4ffd57acc45b",
    "url": "/index.html"
  },
  {
    "revision": "3b46df47437cce62a4a2",
    "url": "/static/css/14.75a79a19.chunk.css"
  },
  {
    "revision": "6a2a278101ef841fe449",
    "url": "/static/css/main.b30c303b.chunk.css"
  },
  {
    "revision": "b3fb945b1897812defa0",
    "url": "/static/js/0.5c169dc8.chunk.js"
  },
  {
    "revision": "fce9b73e4331970e8dae",
    "url": "/static/js/1.fa95ba7b.chunk.js"
  },
  {
    "revision": "f25ba531de2be25b48b0",
    "url": "/static/js/10.40bb3840.chunk.js"
  },
  {
    "revision": "cbc17dab3b39e2bb394e",
    "url": "/static/js/11.a44784f4.chunk.js"
  },
  {
    "revision": "3b46df47437cce62a4a2",
    "url": "/static/js/14.33cad219.chunk.js"
  },
  {
    "revision": "5693e12de9671dcfbc0e",
    "url": "/static/js/15.c5cc0f57.chunk.js"
  },
  {
    "revision": "1a9162f3656a1f29ffd0",
    "url": "/static/js/16.4e7233ab.chunk.js"
  },
  {
    "revision": "4a7ddcab076e6ad3d231",
    "url": "/static/js/17.636e1df8.chunk.js"
  },
  {
    "revision": "b0836ef93f0f98d9a6bc",
    "url": "/static/js/18.fc4dff27.chunk.js"
  },
  {
    "revision": "baac9645ae0fd0cde4fa",
    "url": "/static/js/19.3fd2a28c.chunk.js"
  },
  {
    "revision": "7dfe80e8191c25c4f33f",
    "url": "/static/js/2.7ab73408.chunk.js"
  },
  {
    "revision": "67979c41c7a876c9031b",
    "url": "/static/js/20.bb050c58.chunk.js"
  },
  {
    "revision": "fbe266eb5263e6474fa1",
    "url": "/static/js/21.075b9f2c.chunk.js"
  },
  {
    "revision": "6f8c0e021d1e13a5dca2",
    "url": "/static/js/22.08893baa.chunk.js"
  },
  {
    "revision": "c18e868b3a15fa03331f",
    "url": "/static/js/23.e4f3e457.chunk.js"
  },
  {
    "revision": "2322172db0e67e14e190",
    "url": "/static/js/24.83949308.chunk.js"
  },
  {
    "revision": "bf7b539ca7b34dc0e559",
    "url": "/static/js/25.dc534e17.chunk.js"
  },
  {
    "revision": "cc96695b2ea1a9617d43",
    "url": "/static/js/26.9654d4cf.chunk.js"
  },
  {
    "revision": "b3bd38ce1a2e64e23919",
    "url": "/static/js/27.d19285c7.chunk.js"
  },
  {
    "revision": "c9f4a2b215011a2fdb3c",
    "url": "/static/js/28.c2729105.chunk.js"
  },
  {
    "revision": "fef470ab7039ba9e6acd",
    "url": "/static/js/29.510e63bb.chunk.js"
  },
  {
    "revision": "0f6509b8e3810d2c6f78",
    "url": "/static/js/3.fd0bba78.chunk.js"
  },
  {
    "revision": "c50410a8169a34f7f398",
    "url": "/static/js/30.c64cc630.chunk.js"
  },
  {
    "revision": "537db16d406e9404a5a3",
    "url": "/static/js/31.bad72d5b.chunk.js"
  },
  {
    "revision": "966d454a1ee5659562be",
    "url": "/static/js/32.85673bf3.chunk.js"
  },
  {
    "revision": "f7073df800f05cae8275",
    "url": "/static/js/33.6774af71.chunk.js"
  },
  {
    "revision": "0abc20e8dd188d3caab3",
    "url": "/static/js/34.b82285bc.chunk.js"
  },
  {
    "revision": "82166ebb65833939bd55",
    "url": "/static/js/35.7f7f0466.chunk.js"
  },
  {
    "revision": "d4be58538662f3b22782",
    "url": "/static/js/36.b0c88f31.chunk.js"
  },
  {
    "revision": "5caf09f4ff98bb0ff000",
    "url": "/static/js/37.482ae445.chunk.js"
  },
  {
    "revision": "5c22bdd527c1bb2c1a04",
    "url": "/static/js/38.14835b07.chunk.js"
  },
  {
    "revision": "24c1823d6082f15f6170",
    "url": "/static/js/39.5180849f.chunk.js"
  },
  {
    "revision": "0ae790edb67c34f9f7ff",
    "url": "/static/js/4.f8d20659.chunk.js"
  },
  {
    "revision": "0a09b331de76f726a4fc",
    "url": "/static/js/5.b6fd781b.chunk.js"
  },
  {
    "revision": "f2681769ecbca96e5343",
    "url": "/static/js/6.9c4b6d25.chunk.js"
  },
  {
    "revision": "a1b17fff2256a3f75ada",
    "url": "/static/js/7.b5a54ada.chunk.js"
  },
  {
    "revision": "b617765a9bd830d07b7c",
    "url": "/static/js/8.94b672c5.chunk.js"
  },
  {
    "revision": "3a5027bf6ee414e87722",
    "url": "/static/js/9.53826c4a.chunk.js"
  },
  {
    "revision": "6a2a278101ef841fe449",
    "url": "/static/js/main.694d8667.chunk.js"
  },
  {
    "revision": "c72609aef44c9ceb1aa3",
    "url": "/static/js/runtime~main.83a5831c.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);