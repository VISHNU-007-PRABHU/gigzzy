self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bc0fd20919f4f9b5848c211275e54530",
    "url": "/index.html"
  },
  {
    "revision": "30df7fbc460926f4446a",
    "url": "/static/css/8.cf96be87.chunk.css"
  },
  {
    "revision": "c8c8a8d12575e63e5115",
    "url": "/static/css/main.3a6cc580.chunk.css"
  },
  {
    "revision": "5275a5d4e8ddfc7b3d01",
    "url": "/static/js/0.839df665.chunk.js"
  },
  {
    "revision": "c422ebf767bbdd31ecae",
    "url": "/static/js/1.608936a9.chunk.js"
  },
  {
    "revision": "2cb3cdd8bb8cac193299",
    "url": "/static/js/10.f41a6df8.chunk.js"
  },
  {
    "revision": "3799590743fad862ae62",
    "url": "/static/js/11.02400530.chunk.js"
  },
  {
    "revision": "33bffa1318cddca5b7e8",
    "url": "/static/js/12.58949122.chunk.js"
  },
  {
    "revision": "fa28f585dd4fd9eb7fd4",
    "url": "/static/js/13.1bb5ddb5.chunk.js"
  },
  {
    "revision": "2e808ae2f7ff591fe820",
    "url": "/static/js/14.90a3c438.chunk.js"
  },
  {
    "revision": "1b35354726f0fe6fbee9",
    "url": "/static/js/15.00f970c4.chunk.js"
  },
  {
    "revision": "e35d6bb6d647fdfdab95",
    "url": "/static/js/2.54384e20.chunk.js"
  },
  {
    "revision": "055579cc8fd5eec5c32a",
    "url": "/static/js/3.bab17279.chunk.js"
  },
  {
    "revision": "fdb58f5f5b2ffe326919",
    "url": "/static/js/4.27f82b35.chunk.js"
  },
  {
    "revision": "a1c384c0b11b74ac9364",
    "url": "/static/js/5.62d32532.chunk.js"
  },
  {
    "revision": "30df7fbc460926f4446a",
    "url": "/static/js/8.1a6cb43f.chunk.js"
  },
  {
    "revision": "470ba8d74250d79d023a",
    "url": "/static/js/9.d3f0b847.chunk.js"
  },
  {
    "revision": "c8c8a8d12575e63e5115",
    "url": "/static/js/main.471ae3e2.chunk.js"
  },
  {
    "revision": "67fa2aae6eec99542e7d",
    "url": "/static/js/runtime~main.f657fd75.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);