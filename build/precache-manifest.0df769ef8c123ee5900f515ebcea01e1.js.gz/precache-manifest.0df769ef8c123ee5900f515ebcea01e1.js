self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a0c49e4235cc390b29735d33c28db321",
    "url": "/index.html"
  },
  {
    "revision": "c63b28a68c7de29341a9",
    "url": "/static/css/16.da38a2f8.chunk.css"
  },
  {
    "revision": "b0f78c47229a90cdfe8b",
    "url": "/static/css/main.531b0b24.chunk.css"
  },
  {
    "revision": "56b13e2b3070bac572be",
    "url": "/static/js/0.fc05d22d.chunk.js"
  },
  {
    "revision": "143bd5bb468a1a49c244",
    "url": "/static/js/1.b8e3e1a8.chunk.js"
  },
  {
    "revision": "c64654b134cc9a93d9bf",
    "url": "/static/js/10.a9ca2013.chunk.js"
  },
  {
    "revision": "6d34666740822f6120e0",
    "url": "/static/js/11.9d0e3407.chunk.js"
  },
  {
    "revision": "a3c9bb5b6f5a11b1b6a8",
    "url": "/static/js/12.617cbcf8.chunk.js"
  },
  {
    "revision": "79a86b530e5f75cda089",
    "url": "/static/js/13.aece0b26.chunk.js"
  },
  {
    "revision": "c63b28a68c7de29341a9",
    "url": "/static/js/16.49634a1e.chunk.js"
  },
  {
    "revision": "003ff2c39632cb769ba7",
    "url": "/static/js/17.e88727ae.chunk.js"
  },
  {
    "revision": "7edbeddd7b9a3b7b8840",
    "url": "/static/js/18.9ea3a551.chunk.js"
  },
  {
    "revision": "3361b26bc33732a1096e",
    "url": "/static/js/19.457bec45.chunk.js"
  },
  {
    "revision": "8b494aba5ce5c6ce4d88",
    "url": "/static/js/2.ec835813.chunk.js"
  },
  {
    "revision": "82fa139f52a6bb1e6eed",
    "url": "/static/js/20.a88c1339.chunk.js"
  },
  {
    "revision": "301e1fc36caa77a355c0",
    "url": "/static/js/21.f0381d8f.chunk.js"
  },
  {
    "revision": "4b2325edcc3ded35f567",
    "url": "/static/js/22.6e20ba66.chunk.js"
  },
  {
    "revision": "989fe0b9669056fc7ea1",
    "url": "/static/js/23.5012dff5.chunk.js"
  },
  {
    "revision": "a97ad08d34d5def3015c",
    "url": "/static/js/24.6485f265.chunk.js"
  },
  {
    "revision": "3d883fe582aa06854b45",
    "url": "/static/js/25.61116dd3.chunk.js"
  },
  {
    "revision": "815cb53d0960c795d99e",
    "url": "/static/js/26.f85fbf34.chunk.js"
  },
  {
    "revision": "048aa9b56b815905166a",
    "url": "/static/js/27.0ebd4b53.chunk.js"
  },
  {
    "revision": "65529a28f6f453009d35",
    "url": "/static/js/28.53525631.chunk.js"
  },
  {
    "revision": "50673917a7d150cf3b17",
    "url": "/static/js/29.4a9de53d.chunk.js"
  },
  {
    "revision": "f8b3b8d0cbd0b0a1c0b8",
    "url": "/static/js/3.7fd6e15e.chunk.js"
  },
  {
    "revision": "5d3116875b92d65a59fb",
    "url": "/static/js/30.e01b6811.chunk.js"
  },
  {
    "revision": "ef0111cb81e392dc68a5",
    "url": "/static/js/31.3c5ec8fc.chunk.js"
  },
  {
    "revision": "0326ebf907046b445549",
    "url": "/static/js/32.098adeb1.chunk.js"
  },
  {
    "revision": "95298dd423b8b30e2502",
    "url": "/static/js/33.ef23cd8b.chunk.js"
  },
  {
    "revision": "ec9e9e05d8bd7d366e0c",
    "url": "/static/js/34.48deb0fc.chunk.js"
  },
  {
    "revision": "6857aa624ec08ab53ee0",
    "url": "/static/js/35.fa735132.chunk.js"
  },
  {
    "revision": "aa249c9bd4ba49ac3481",
    "url": "/static/js/36.208b2d2c.chunk.js"
  },
  {
    "revision": "f957a635e9c109cc74bf",
    "url": "/static/js/37.03b35ef7.chunk.js"
  },
  {
    "revision": "a4542c740199759e60c6",
    "url": "/static/js/38.3a3d4c81.chunk.js"
  },
  {
    "revision": "e765c7b943cece16d39e",
    "url": "/static/js/39.f4bda111.chunk.js"
  },
  {
    "revision": "532e11f26c5af0677c73",
    "url": "/static/js/4.4a8d6df6.chunk.js"
  },
  {
    "revision": "0b81ed7302caa04dfe30",
    "url": "/static/js/40.32972678.chunk.js"
  },
  {
    "revision": "7c9864b8669035d13057",
    "url": "/static/js/41.5ed8fc0c.chunk.js"
  },
  {
    "revision": "7506943b1325e4995fba",
    "url": "/static/js/42.4b0448b3.chunk.js"
  },
  {
    "revision": "b8112074bf2a6ce5d430",
    "url": "/static/js/43.7532e2b0.chunk.js"
  },
  {
    "revision": "09aefe963a73478fd128",
    "url": "/static/js/44.00081011.chunk.js"
  },
  {
    "revision": "90d9ef3d79fa1c3de3e0",
    "url": "/static/js/45.de05744d.chunk.js"
  },
  {
    "revision": "785f1d3dfe2b23330ee3",
    "url": "/static/js/46.861a6106.chunk.js"
  },
  {
    "revision": "e691b0c3865348e70132",
    "url": "/static/js/47.48e56096.chunk.js"
  },
  {
    "revision": "b509a9bee19a00db71d5",
    "url": "/static/js/48.c1323483.chunk.js"
  },
  {
    "revision": "e32e5e18828d82ddb025",
    "url": "/static/js/49.7b588396.chunk.js"
  },
  {
    "revision": "9f58d954ea4f1ffe9d39",
    "url": "/static/js/5.56ffb96e.chunk.js"
  },
  {
    "revision": "60f5cbdb16c756c095a4",
    "url": "/static/js/50.917ae2bd.chunk.js"
  },
  {
    "revision": "5058e2cda00c140d75eb",
    "url": "/static/js/51.ac6ed442.chunk.js"
  },
  {
    "revision": "89ee3af11956adbf15de",
    "url": "/static/js/52.51412efc.chunk.js"
  },
  {
    "revision": "1d18b9832eb110483d60",
    "url": "/static/js/53.ae40beee.chunk.js"
  },
  {
    "revision": "217f5aaecc08e849d7ff",
    "url": "/static/js/54.657d187f.chunk.js"
  },
  {
    "revision": "45fa49dae9788df38646",
    "url": "/static/js/55.499befb0.chunk.js"
  },
  {
    "revision": "6c210b01de03d6aa0dc0",
    "url": "/static/js/56.2ae38ff6.chunk.js"
  },
  {
    "revision": "a280a58959863a57cc2b",
    "url": "/static/js/57.308eebaa.chunk.js"
  },
  {
    "revision": "96a3a4eab5646d2ae004",
    "url": "/static/js/58.9d4ddc16.chunk.js"
  },
  {
    "revision": "89f647c1d3391245d60d",
    "url": "/static/js/59.7a5234e9.chunk.js"
  },
  {
    "revision": "d4d467b367c5797d3817",
    "url": "/static/js/6.741025a0.chunk.js"
  },
  {
    "revision": "f25cdc52539f7ae1aba5",
    "url": "/static/js/60.e93acfb6.chunk.js"
  },
  {
    "revision": "ea86a576d9f6e8f28f5e",
    "url": "/static/js/61.0d58e85a.chunk.js"
  },
  {
    "revision": "d9f037fc8f5cd81ef27e",
    "url": "/static/js/62.feebd866.chunk.js"
  },
  {
    "revision": "6661e3cf8f25e07ff37c",
    "url": "/static/js/7.b63c9124.chunk.js"
  },
  {
    "revision": "fa848af80a15e7060153",
    "url": "/static/js/8.54e266a4.chunk.js"
  },
  {
    "revision": "67198815a8df3d472f3a",
    "url": "/static/js/9.89b6d468.chunk.js"
  },
  {
    "revision": "b0f78c47229a90cdfe8b",
    "url": "/static/js/main.0a405c20.chunk.js"
  },
  {
    "revision": "814a4f31585894d2ab19",
    "url": "/static/js/runtime~main.7bca9fa3.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);