self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "65f2a6133e398ec7136bdd4a71bee295",
    "url": "/index.html"
  },
  {
    "revision": "c18b101c60349cae2533",
    "url": "/static/css/9.8d62e1ed.chunk.css"
  },
  {
    "revision": "991dbacca305b09ca735",
    "url": "/static/css/main.36c7831f.chunk.css"
  },
  {
    "revision": "635ced93cd843f137b1e",
    "url": "/static/js/0.8674e0fb.chunk.js"
  },
  {
    "revision": "eec7f9a80f1c1f010eb6",
    "url": "/static/js/1.09877890.chunk.js"
  },
  {
    "revision": "47366e93697f34669807",
    "url": "/static/js/10.eb7de3d9.chunk.js"
  },
  {
    "revision": "eb9d2b2b8f22b2e8dd0f",
    "url": "/static/js/11.efa60999.chunk.js"
  },
  {
    "revision": "b693adb12d2fd316085a",
    "url": "/static/js/12.a991e3c4.chunk.js"
  },
  {
    "revision": "3c46430336aa4e5af0c2",
    "url": "/static/js/13.164d7ea4.chunk.js"
  },
  {
    "revision": "e6b7ad737e7102f89090",
    "url": "/static/js/14.85f69c8d.chunk.js"
  },
  {
    "revision": "5774f3278c4fa68d127b",
    "url": "/static/js/15.55a58fbb.chunk.js"
  },
  {
    "revision": "36caee0242d43d1a5d7f",
    "url": "/static/js/16.a4bae852.chunk.js"
  },
  {
    "revision": "b656562222148264c79d",
    "url": "/static/js/17.9e76d415.chunk.js"
  },
  {
    "revision": "02ebd91ae4274970c07f",
    "url": "/static/js/2.54fec797.chunk.js"
  },
  {
    "revision": "eecddd7b9f71d57f890b",
    "url": "/static/js/3.99383738.chunk.js"
  },
  {
    "revision": "f7d642dde48addc6d948",
    "url": "/static/js/4.09ad55d1.chunk.js"
  },
  {
    "revision": "911af0c00c1175e22d57",
    "url": "/static/js/5.9e27275e.chunk.js"
  },
  {
    "revision": "1a7782709d88060e6613",
    "url": "/static/js/6.0079832d.chunk.js"
  },
  {
    "revision": "c18b101c60349cae2533",
    "url": "/static/js/9.1589f11a.chunk.js"
  },
  {
    "revision": "991dbacca305b09ca735",
    "url": "/static/js/main.ea0f7ea2.chunk.js"
  },
  {
    "revision": "8ce3c2b2a692480cd32a",
    "url": "/static/js/runtime~main.d2a576e4.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);