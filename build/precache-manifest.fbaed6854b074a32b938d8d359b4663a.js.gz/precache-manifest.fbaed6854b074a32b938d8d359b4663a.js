self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7c7760bade459370cad914fa7723a98e",
    "url": "/index.html"
  },
  {
    "revision": "e910a412762e0a8fc311",
    "url": "/static/css/8.a4fd6fd0.chunk.css"
  },
  {
    "revision": "ea6daec258eaf2711646",
    "url": "/static/css/main.04e82f4f.chunk.css"
  },
  {
    "revision": "3a19bdd593bfa9b08f2f",
    "url": "/static/js/0.50899736.chunk.js"
  },
  {
    "revision": "dc667f0efa38b0d355c6",
    "url": "/static/js/1.2ac499fd.chunk.js"
  },
  {
    "revision": "ae31533fc66d28c86f8c",
    "url": "/static/js/10.513473d0.chunk.js"
  },
  {
    "revision": "03e60ce6253a2d4d6010",
    "url": "/static/js/11.33b54e13.chunk.js"
  },
  {
    "revision": "166058212823743d79ad",
    "url": "/static/js/12.d7316171.chunk.js"
  },
  {
    "revision": "9eade569ea7d8f1aafeb",
    "url": "/static/js/2.afc0fac3.chunk.js"
  },
  {
    "revision": "a3066369f0a5a158b464",
    "url": "/static/js/3.809506f3.chunk.js"
  },
  {
    "revision": "b10aabf6012b52fec206",
    "url": "/static/js/4.0c8dafce.chunk.js"
  },
  {
    "revision": "4962a7e033d1467293ab",
    "url": "/static/js/5.79ac96ce.chunk.js"
  },
  {
    "revision": "e910a412762e0a8fc311",
    "url": "/static/js/8.a170bb72.chunk.js"
  },
  {
    "revision": "dbf5ed2e7562aa850566",
    "url": "/static/js/9.4cbd1963.chunk.js"
  },
  {
    "revision": "ea6daec258eaf2711646",
    "url": "/static/js/main.574f41de.chunk.js"
  },
  {
    "revision": "3cb7dece75ba8bac7272",
    "url": "/static/js/runtime~main.c5144bb4.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);