self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1fd721e82f0e71d3e59d09f6aa495231",
    "url": "/index.html"
  },
  {
    "revision": "838697f942879d518e1f",
    "url": "/static/css/19.cdaf15d1.chunk.css"
  },
  {
    "revision": "69fff4e21b4471bc04f6",
    "url": "/static/css/30.051905ae.chunk.css"
  },
  {
    "revision": "e781d87226999920d268",
    "url": "/static/css/31.3a6be942.chunk.css"
  },
  {
    "revision": "1b316171152d4638f001",
    "url": "/static/css/32.88292131.chunk.css"
  },
  {
    "revision": "ce64cd87ca1e3c4109f7",
    "url": "/static/css/37.c9556fed.chunk.css"
  },
  {
    "revision": "111a164521fddf7844e6",
    "url": "/static/css/39.11000f17.chunk.css"
  },
  {
    "revision": "4046e70a86cd346ee71b",
    "url": "/static/css/42.11000f17.chunk.css"
  },
  {
    "revision": "8d620c0b91715c201eed",
    "url": "/static/css/47.52c43222.chunk.css"
  },
  {
    "revision": "0964f08fdcc589f1ab77",
    "url": "/static/css/48.8cf98a25.chunk.css"
  },
  {
    "revision": "cd0163d3fdea06c41c30",
    "url": "/static/css/52.f9b90304.chunk.css"
  },
  {
    "revision": "04d45f90e522870a06fd",
    "url": "/static/css/53.11000f17.chunk.css"
  },
  {
    "revision": "e75c18de0c1be5023dda",
    "url": "/static/css/55.9142c0f9.chunk.css"
  },
  {
    "revision": "889d82c334683c30bb66",
    "url": "/static/css/56.9142c0f9.chunk.css"
  },
  {
    "revision": "64136ba3c3820538c8df",
    "url": "/static/css/57.0724d5f1.chunk.css"
  },
  {
    "revision": "8e2804bb9fd9ab95bc42",
    "url": "/static/css/58.3a6be942.chunk.css"
  },
  {
    "revision": "c3a7713763d4515a0578",
    "url": "/static/css/59.3a6be942.chunk.css"
  },
  {
    "revision": "f3c635eea49f3d80ed86",
    "url": "/static/css/63.cdaf15d1.chunk.css"
  },
  {
    "revision": "f0685a58a7fe391273d9",
    "url": "/static/css/65.5b5fb56a.chunk.css"
  },
  {
    "revision": "da1fb5649e7aab66d2d4",
    "url": "/static/css/main.84c18709.chunk.css"
  },
  {
    "revision": "79ddefaa7686878badb6",
    "url": "/static/js/0.c9285907.chunk.js"
  },
  {
    "revision": "dbdfb237a6087a47ce7b",
    "url": "/static/js/1.f91b5516.chunk.js"
  },
  {
    "revision": "11fa22b45487e1dec475",
    "url": "/static/js/10.b876321b.chunk.js"
  },
  {
    "revision": "5aa2f7ed855d5b1539ed",
    "url": "/static/js/100.bc0980a1.chunk.js"
  },
  {
    "revision": "f7fee034181fec46f9f9",
    "url": "/static/js/101.c5a21963.chunk.js"
  },
  {
    "revision": "6cf4a5b753a2678fdcaf",
    "url": "/static/js/102.a3e3b08e.chunk.js"
  },
  {
    "revision": "e2482fabc6455a143684",
    "url": "/static/js/103.9851328e.chunk.js"
  },
  {
    "revision": "9ccd645377870d613635",
    "url": "/static/js/104.027f0e21.chunk.js"
  },
  {
    "revision": "a32dcbd95865b6f6661c",
    "url": "/static/js/105.626878c0.chunk.js"
  },
  {
    "revision": "46e2712dcdff11d09f8d",
    "url": "/static/js/106.6a67406a.chunk.js"
  },
  {
    "revision": "77b49a61126b34c0b12f",
    "url": "/static/js/107.d7ecb1a6.chunk.js"
  },
  {
    "revision": "3618b9c6220aec7a32ce",
    "url": "/static/js/108.da363c81.chunk.js"
  },
  {
    "revision": "794db6ac4211f570b15e",
    "url": "/static/js/109.b40da562.chunk.js"
  },
  {
    "revision": "2b6d52eb829c36063e70",
    "url": "/static/js/11.c947a1e3.chunk.js"
  },
  {
    "revision": "04480066f1e73ae7e5f0",
    "url": "/static/js/110.3c0570f7.chunk.js"
  },
  {
    "revision": "eefc2d604613d8a3fcfe",
    "url": "/static/js/111.b351c24e.chunk.js"
  },
  {
    "revision": "e0ebb025dcba96bc81a9",
    "url": "/static/js/112.de50dddf.chunk.js"
  },
  {
    "revision": "a0453e2fb92fd97088a9",
    "url": "/static/js/113.827c14be.chunk.js"
  },
  {
    "revision": "a37c2e97232edf555805",
    "url": "/static/js/114.410e4946.chunk.js"
  },
  {
    "revision": "6251b0ddc99a9eed6d3a",
    "url": "/static/js/115.5efb4641.chunk.js"
  },
  {
    "revision": "510042d8767db71fe632",
    "url": "/static/js/116.d8e8eb77.chunk.js"
  },
  {
    "revision": "31e4cd02431b2fcdcc2a",
    "url": "/static/js/117.946aae79.chunk.js"
  },
  {
    "revision": "d4f9196a5f9293c71334",
    "url": "/static/js/118.a85c5898.chunk.js"
  },
  {
    "revision": "15bf2861b553e20d7964",
    "url": "/static/js/12.e88ccb70.chunk.js"
  },
  {
    "revision": "56612eb34cbef74581ec",
    "url": "/static/js/13.1222ea61.chunk.js"
  },
  {
    "revision": "d252a5eba46d24476564",
    "url": "/static/js/14.68e9b0cb.chunk.js"
  },
  {
    "revision": "0bd9229d76a3b6c4fb90",
    "url": "/static/js/15.14645c76.chunk.js"
  },
  {
    "revision": "ec0140c19a008c939230",
    "url": "/static/js/16.fcf5f15d.chunk.js"
  },
  {
    "revision": "ed2d0e8e92acce0b8ba3",
    "url": "/static/js/17.a8c6d529.chunk.js"
  },
  {
    "revision": "0baae1383efcd3dd68fc",
    "url": "/static/js/18.1346afc9.chunk.js"
  },
  {
    "revision": "838697f942879d518e1f",
    "url": "/static/js/19.9bbd5cdc.chunk.js"
  },
  {
    "revision": "135a0d87c99646b4e0b6",
    "url": "/static/js/2.34ee16aa.chunk.js"
  },
  {
    "revision": "edf4011e7a9a5c712d06",
    "url": "/static/js/20.62a164dc.chunk.js"
  },
  {
    "revision": "234bfef61f32cf3450a6",
    "url": "/static/js/21.eb993512.chunk.js"
  },
  {
    "revision": "a575ffe2f84531bc8707",
    "url": "/static/js/22.3ac73247.chunk.js"
  },
  {
    "revision": "4707e188419607f5c898",
    "url": "/static/js/23.b7998985.chunk.js"
  },
  {
    "revision": "36714c84fb738a440ce0",
    "url": "/static/js/24.3f303c4f.chunk.js"
  },
  {
    "revision": "9a59e3bbb171d194d6e6",
    "url": "/static/js/25.cfc49c4b.chunk.js"
  },
  {
    "revision": "f4bcdc383b820f8ab735",
    "url": "/static/js/26.4e937842.chunk.js"
  },
  {
    "revision": "e28490b0f235b6448b15",
    "url": "/static/js/27.cacc9207.chunk.js"
  },
  {
    "revision": "348250c8de18422a97c9",
    "url": "/static/js/3.519d0da2.chunk.js"
  },
  {
    "revision": "69fff4e21b4471bc04f6",
    "url": "/static/js/30.faa354ef.chunk.js"
  },
  {
    "revision": "e781d87226999920d268",
    "url": "/static/js/31.5bf26308.chunk.js"
  },
  {
    "revision": "1b316171152d4638f001",
    "url": "/static/js/32.3c8e23e5.chunk.js"
  },
  {
    "revision": "2bd31aec9cdee9273f9e",
    "url": "/static/js/33.8ddf32c0.chunk.js"
  },
  {
    "revision": "1d287ae01c4e9e6f5f9f",
    "url": "/static/js/34.46755f09.chunk.js"
  },
  {
    "revision": "3610afbafe9e60a092c3",
    "url": "/static/js/35.e70ddcb0.chunk.js"
  },
  {
    "revision": "f7b6cb8b9f0f88d0e025",
    "url": "/static/js/36.07aaa032.chunk.js"
  },
  {
    "revision": "ce64cd87ca1e3c4109f7",
    "url": "/static/js/37.eae6e857.chunk.js"
  },
  {
    "revision": "c5b68751a1a14413b71a",
    "url": "/static/js/38.32fd7f35.chunk.js"
  },
  {
    "revision": "111a164521fddf7844e6",
    "url": "/static/js/39.1fa52d03.chunk.js"
  },
  {
    "revision": "b21ed210aea5b43aebdc",
    "url": "/static/js/4.6e0b8448.chunk.js"
  },
  {
    "revision": "2353cfdce041e2a004f2",
    "url": "/static/js/40.3b6ce64a.chunk.js"
  },
  {
    "revision": "2d622b741e5ad0182fca",
    "url": "/static/js/41.fa2d05cd.chunk.js"
  },
  {
    "revision": "4046e70a86cd346ee71b",
    "url": "/static/js/42.30e293de.chunk.js"
  },
  {
    "revision": "988cad1d173f7f30d6c1",
    "url": "/static/js/43.a5698b79.chunk.js"
  },
  {
    "revision": "c96c3ebe5e54010c812f",
    "url": "/static/js/44.c9dc4d85.chunk.js"
  },
  {
    "revision": "a5a0dc01f2c9c95f9319",
    "url": "/static/js/45.4fb87f6a.chunk.js"
  },
  {
    "revision": "68dbad43c243611d09e5",
    "url": "/static/js/46.040e1e45.chunk.js"
  },
  {
    "revision": "8d620c0b91715c201eed",
    "url": "/static/js/47.e5428d44.chunk.js"
  },
  {
    "revision": "0964f08fdcc589f1ab77",
    "url": "/static/js/48.8cc9a5f9.chunk.js"
  },
  {
    "revision": "60f8c379eebaeb2dfb18",
    "url": "/static/js/49.607ac679.chunk.js"
  },
  {
    "revision": "2ae4b7e672155caca9a5",
    "url": "/static/js/5.a7bda358.chunk.js"
  },
  {
    "revision": "318b58d2d9fee72d4b81",
    "url": "/static/js/50.8dd3b2be.chunk.js"
  },
  {
    "revision": "955ce58ff7fe4381233a",
    "url": "/static/js/51.2668405a.chunk.js"
  },
  {
    "revision": "cd0163d3fdea06c41c30",
    "url": "/static/js/52.3a2a6c67.chunk.js"
  },
  {
    "revision": "04d45f90e522870a06fd",
    "url": "/static/js/53.0bf5bc20.chunk.js"
  },
  {
    "revision": "06e9d78c8fbde972cecd",
    "url": "/static/js/54.783a4651.chunk.js"
  },
  {
    "revision": "e75c18de0c1be5023dda",
    "url": "/static/js/55.d280a933.chunk.js"
  },
  {
    "revision": "889d82c334683c30bb66",
    "url": "/static/js/56.cd706362.chunk.js"
  },
  {
    "revision": "64136ba3c3820538c8df",
    "url": "/static/js/57.19927c04.chunk.js"
  },
  {
    "revision": "8e2804bb9fd9ab95bc42",
    "url": "/static/js/58.c1f04bbe.chunk.js"
  },
  {
    "revision": "c3a7713763d4515a0578",
    "url": "/static/js/59.231821e5.chunk.js"
  },
  {
    "revision": "befbea115e5cdb94ed74",
    "url": "/static/js/6.b36fdd9b.chunk.js"
  },
  {
    "revision": "47a8f23cf87c32f643e8",
    "url": "/static/js/60.9e4791cc.chunk.js"
  },
  {
    "revision": "44370e55f6b944f04362",
    "url": "/static/js/61.4972c792.chunk.js"
  },
  {
    "revision": "0a6d5acf225056b08e94",
    "url": "/static/js/62.b1313906.chunk.js"
  },
  {
    "revision": "f3c635eea49f3d80ed86",
    "url": "/static/js/63.2bff138c.chunk.js"
  },
  {
    "revision": "b0e7694b4429e4777365",
    "url": "/static/js/64.ed37c5df.chunk.js"
  },
  {
    "revision": "f0685a58a7fe391273d9",
    "url": "/static/js/65.d10055ff.chunk.js"
  },
  {
    "revision": "4a818f0a45d1f8951b8b",
    "url": "/static/js/66.948536ad.chunk.js"
  },
  {
    "revision": "3f473867769e36815f58",
    "url": "/static/js/67.df027f62.chunk.js"
  },
  {
    "revision": "636b2f3e54c0ee620934",
    "url": "/static/js/68.00033a9f.chunk.js"
  },
  {
    "revision": "486358695024e7698bb2",
    "url": "/static/js/69.89960347.chunk.js"
  },
  {
    "revision": "4b51dfeb55fb06b1bd4b",
    "url": "/static/js/7.e73e8810.chunk.js"
  },
  {
    "revision": "a46b1ac4a7fc29b8a732",
    "url": "/static/js/70.c82b8221.chunk.js"
  },
  {
    "revision": "420a45938e99777af00d",
    "url": "/static/js/71.af5d3c20.chunk.js"
  },
  {
    "revision": "231522b6400429465355",
    "url": "/static/js/72.95674819.chunk.js"
  },
  {
    "revision": "2d57acf9143e7fa174d5",
    "url": "/static/js/73.85abd15d.chunk.js"
  },
  {
    "revision": "64380637defd6e602094",
    "url": "/static/js/74.f3727e8d.chunk.js"
  },
  {
    "revision": "b61a684a6fdd856eb0f5",
    "url": "/static/js/75.65b8113e.chunk.js"
  },
  {
    "revision": "95e0d8ef663629187a46",
    "url": "/static/js/76.ecbf823c.chunk.js"
  },
  {
    "revision": "c717340e9692ee2dc4f8",
    "url": "/static/js/77.eef3c5e3.chunk.js"
  },
  {
    "revision": "1dea470b2ffa5720fb30",
    "url": "/static/js/78.9ea62c0e.chunk.js"
  },
  {
    "revision": "a659ad586355861702ea",
    "url": "/static/js/79.c69bc7c1.chunk.js"
  },
  {
    "revision": "de5ed25fa0ab7a7a977b",
    "url": "/static/js/8.d9c1c03e.chunk.js"
  },
  {
    "revision": "2fc2416a53a17ca03b1d",
    "url": "/static/js/80.eb225199.chunk.js"
  },
  {
    "revision": "8b8e773ef2bc92aafa47",
    "url": "/static/js/81.16bd39e9.chunk.js"
  },
  {
    "revision": "bbe20087a7474a0ae542",
    "url": "/static/js/82.7299cf7a.chunk.js"
  },
  {
    "revision": "aefd58fc636ca5823c30",
    "url": "/static/js/83.37eab591.chunk.js"
  },
  {
    "revision": "78c0f623d32a4f6e27c4",
    "url": "/static/js/84.848b3d2f.chunk.js"
  },
  {
    "revision": "c028dba599567a8ee8c9",
    "url": "/static/js/85.fea516b6.chunk.js"
  },
  {
    "revision": "3fcd17949d351c661884",
    "url": "/static/js/86.84eb9826.chunk.js"
  },
  {
    "revision": "dbf609ab3a134354727b",
    "url": "/static/js/87.a82a4d3a.chunk.js"
  },
  {
    "revision": "5f8b1d6c08e82aa255d4",
    "url": "/static/js/88.77c23c48.chunk.js"
  },
  {
    "revision": "03a38beb1c31ec3af449",
    "url": "/static/js/89.4a14a075.chunk.js"
  },
  {
    "revision": "87b27e76fb68b8f5d3c9",
    "url": "/static/js/9.d9ec7494.chunk.js"
  },
  {
    "revision": "0223e4f9641efc881ad1",
    "url": "/static/js/90.0524d5ee.chunk.js"
  },
  {
    "revision": "4451110a3b3489a824b4",
    "url": "/static/js/91.675c7e75.chunk.js"
  },
  {
    "revision": "8a68014a0a61f3fd1529",
    "url": "/static/js/92.49175b46.chunk.js"
  },
  {
    "revision": "c4892d5909d90aa2d1ae",
    "url": "/static/js/93.4d4af23b.chunk.js"
  },
  {
    "revision": "641850a11d363e99a50d",
    "url": "/static/js/94.14b9654f.chunk.js"
  },
  {
    "revision": "4d3730c810409f5df037",
    "url": "/static/js/95.d7f8863b.chunk.js"
  },
  {
    "revision": "3e4c4995ab086b6facf1",
    "url": "/static/js/96.f110e7e3.chunk.js"
  },
  {
    "revision": "140980a779d9ee073cd4",
    "url": "/static/js/97.2bfd3b7e.chunk.js"
  },
  {
    "revision": "975710d350873af180c9",
    "url": "/static/js/98.da618566.chunk.js"
  },
  {
    "revision": "211b6364ae72150fa769",
    "url": "/static/js/99.25b82812.chunk.js"
  },
  {
    "revision": "da1fb5649e7aab66d2d4",
    "url": "/static/js/main.76d5ad29.chunk.js"
  },
  {
    "revision": "39db0a3838c4be69258e",
    "url": "/static/js/runtime~main.3b9815bd.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);