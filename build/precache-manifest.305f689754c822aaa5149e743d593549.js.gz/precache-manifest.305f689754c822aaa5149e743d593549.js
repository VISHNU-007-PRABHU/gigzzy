self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fbe751e78ba536d611a6f38fce38e3e2",
    "url": "/index.html"
  },
  {
    "revision": "34e00cf4fc98aac7101b",
    "url": "/static/css/10.2496119f.chunk.css"
  },
  {
    "revision": "a1c02f9e3ae64c859b27",
    "url": "/static/css/main.2e3e720a.chunk.css"
  },
  {
    "revision": "7d22f9d18491461f1ce8",
    "url": "/static/js/0.96b5caee.chunk.js"
  },
  {
    "revision": "7ae868127faff35016b3",
    "url": "/static/js/1.7443360c.chunk.js"
  },
  {
    "revision": "34e00cf4fc98aac7101b",
    "url": "/static/js/10.3af670fd.chunk.js"
  },
  {
    "revision": "212bb5b07247a5f35dd1",
    "url": "/static/js/11.6c74c8bb.chunk.js"
  },
  {
    "revision": "107ec00e312ce578b976",
    "url": "/static/js/12.982d9d08.chunk.js"
  },
  {
    "revision": "a20a4769a090532574dd",
    "url": "/static/js/13.3d022707.chunk.js"
  },
  {
    "revision": "aaee6c61aab6c21224bc",
    "url": "/static/js/14.1982dfa3.chunk.js"
  },
  {
    "revision": "e711dfd404b4759c7ce3",
    "url": "/static/js/15.2c034973.chunk.js"
  },
  {
    "revision": "eb103901c42015e839d3",
    "url": "/static/js/16.8ebd9ebc.chunk.js"
  },
  {
    "revision": "12969e334862be8a27cf",
    "url": "/static/js/17.85d27cdc.chunk.js"
  },
  {
    "revision": "2919c3d3a997ffce48c8",
    "url": "/static/js/18.a26aab36.chunk.js"
  },
  {
    "revision": "ad63246e295ea8aaf44a",
    "url": "/static/js/19.01020347.chunk.js"
  },
  {
    "revision": "c53b6a7ed7ba32f353b2",
    "url": "/static/js/2.cb2fb8b0.chunk.js"
  },
  {
    "revision": "a72ed8e10ac03baa51a4",
    "url": "/static/js/20.ff2f4af3.chunk.js"
  },
  {
    "revision": "0133345d689241cb68e9",
    "url": "/static/js/21.47571874.chunk.js"
  },
  {
    "revision": "a50818a732527016567f",
    "url": "/static/js/22.061e4a4a.chunk.js"
  },
  {
    "revision": "1c761450386927231f3d",
    "url": "/static/js/23.83d239ab.chunk.js"
  },
  {
    "revision": "7d4a07bb75928ce60d60",
    "url": "/static/js/24.bc87c567.chunk.js"
  },
  {
    "revision": "0e7a2760535be1170be6",
    "url": "/static/js/25.8cb34068.chunk.js"
  },
  {
    "revision": "db883ad8a77dab2d1a4c",
    "url": "/static/js/26.5f7b60b5.chunk.js"
  },
  {
    "revision": "f3187441c156d1d02a3a",
    "url": "/static/js/27.5b046a74.chunk.js"
  },
  {
    "revision": "1b2bcf0287372b180d92",
    "url": "/static/js/28.4e89a9b9.chunk.js"
  },
  {
    "revision": "b51e145d5290b9f41160",
    "url": "/static/js/29.6d0d311f.chunk.js"
  },
  {
    "revision": "0f3de97d33e7d4d8f2a8",
    "url": "/static/js/3.50aaffc3.chunk.js"
  },
  {
    "revision": "a6d982ce4c9c0bd16c97",
    "url": "/static/js/4.31db254b.chunk.js"
  },
  {
    "revision": "a501f5c9294a4cc5c39d",
    "url": "/static/js/5.f091e65b.chunk.js"
  },
  {
    "revision": "9dcb90187a3ea0c0ec9e",
    "url": "/static/js/6.20c160ef.chunk.js"
  },
  {
    "revision": "718244bfa815f830bf0d",
    "url": "/static/js/7.2143eeb9.chunk.js"
  },
  {
    "revision": "a1c02f9e3ae64c859b27",
    "url": "/static/js/main.edf925eb.chunk.js"
  },
  {
    "revision": "3e86a57f6605b247bf3b",
    "url": "/static/js/runtime~main.c6946a15.js"
  },
  {
    "revision": "ec10c675411b4ad7e25db55b6bd01577",
    "url": "/static/media/Gigzzy.ec10c675.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "2503bfccaf0f52c9a8f73ea079b10d56",
    "url": "/static/media/gigzzypro.2503bfcc.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);