self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ef09468ecb6ca031dc0b48bb6132677c",
    "url": "/index.html"
  },
  {
    "revision": "753d58f583d71f66e44f",
    "url": "/static/css/10.75a79a19.chunk.css"
  },
  {
    "revision": "eb3451d9d2023038b8ab",
    "url": "/static/css/main.2e3e720a.chunk.css"
  },
  {
    "revision": "8235919a78b3eac6a9d8",
    "url": "/static/js/0.885c4755.chunk.js"
  },
  {
    "revision": "91e49b20f3bf35205eaa",
    "url": "/static/js/1.dae13e1c.chunk.js"
  },
  {
    "revision": "753d58f583d71f66e44f",
    "url": "/static/js/10.40a604d6.chunk.js"
  },
  {
    "revision": "a4eed6710d13c5fd2076",
    "url": "/static/js/11.238a0563.chunk.js"
  },
  {
    "revision": "46bd2b0ad753ce044040",
    "url": "/static/js/12.30d26513.chunk.js"
  },
  {
    "revision": "9109bb9273d6d90bc9c2",
    "url": "/static/js/13.9d2b287d.chunk.js"
  },
  {
    "revision": "a56e9821c5e583b75cbe",
    "url": "/static/js/14.baf99514.chunk.js"
  },
  {
    "revision": "ca012a857356ffeceba6",
    "url": "/static/js/15.8be0df48.chunk.js"
  },
  {
    "revision": "ad7689948e7689261043",
    "url": "/static/js/16.5a54f4a8.chunk.js"
  },
  {
    "revision": "194b4b4db325863a326b",
    "url": "/static/js/17.6aaa6de7.chunk.js"
  },
  {
    "revision": "71dd96dd49ebd0e89ffb",
    "url": "/static/js/18.510f4097.chunk.js"
  },
  {
    "revision": "e31ef1c37e06e68b060f",
    "url": "/static/js/19.b969310e.chunk.js"
  },
  {
    "revision": "d7fb74c195f29dafcc4d",
    "url": "/static/js/2.78c76f27.chunk.js"
  },
  {
    "revision": "f4fbc65a0a2dd40c0e49",
    "url": "/static/js/20.65fb1b98.chunk.js"
  },
  {
    "revision": "850296b9708ae1b57151",
    "url": "/static/js/21.5cccd6b8.chunk.js"
  },
  {
    "revision": "2f50227087c8ed862931",
    "url": "/static/js/22.6402b3e3.chunk.js"
  },
  {
    "revision": "c4ac218999ad2ced99bf",
    "url": "/static/js/23.4daaa41a.chunk.js"
  },
  {
    "revision": "6f4cc6b9a7e4a2e44c9d",
    "url": "/static/js/24.db6361ae.chunk.js"
  },
  {
    "revision": "db38ac9243685eaabacb",
    "url": "/static/js/25.5b9fb2e4.chunk.js"
  },
  {
    "revision": "9ed43a2a04c97846b9b7",
    "url": "/static/js/26.1afe237c.chunk.js"
  },
  {
    "revision": "b672f9b0740c7ee253c3",
    "url": "/static/js/27.341cbff7.chunk.js"
  },
  {
    "revision": "a3fe6b23bbc78a5b79c2",
    "url": "/static/js/28.71641894.chunk.js"
  },
  {
    "revision": "233132f2d0f4611630cc",
    "url": "/static/js/29.0aff28da.chunk.js"
  },
  {
    "revision": "79511f438327fda9517a",
    "url": "/static/js/3.8f1b4ef7.chunk.js"
  },
  {
    "revision": "74f3f1e56adfb0e917b3",
    "url": "/static/js/30.6eaeff38.chunk.js"
  },
  {
    "revision": "d981311368ba543fadf2",
    "url": "/static/js/4.cd0e46b7.chunk.js"
  },
  {
    "revision": "b2f00763f2ebe34de15e",
    "url": "/static/js/5.0cf259e5.chunk.js"
  },
  {
    "revision": "f4cd386d7a756bbe767c",
    "url": "/static/js/6.9a86a554.chunk.js"
  },
  {
    "revision": "406a9d5cd8b1fa135e46",
    "url": "/static/js/7.56bfbb9a.chunk.js"
  },
  {
    "revision": "eb3451d9d2023038b8ab",
    "url": "/static/js/main.d7bf54b9.chunk.js"
  },
  {
    "revision": "ba8607316b6fbdb4436c",
    "url": "/static/js/runtime~main.ccfefa62.js"
  },
  {
    "revision": "ec10c675411b4ad7e25db55b6bd01577",
    "url": "/static/media/Gigzzy.ec10c675.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "2503bfccaf0f52c9a8f73ea079b10d56",
    "url": "/static/media/gigzzypro.2503bfcc.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);