self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cab49f0022ea10246fa31cebed8512ae",
    "url": "/index.html"
  },
  {
    "revision": "49f24493f0846d781ebc",
    "url": "/static/css/19.cdaf15d1.chunk.css"
  },
  {
    "revision": "10924d78207903164183",
    "url": "/static/css/28.9991e3dd.chunk.css"
  },
  {
    "revision": "57f48a40ec4bbebc925c",
    "url": "/static/css/29.90a5e751.chunk.css"
  },
  {
    "revision": "615da03e2b9a0f208594",
    "url": "/static/css/30.88292131.chunk.css"
  },
  {
    "revision": "00f7ce424aeb9155e5e1",
    "url": "/static/css/35.cb85cd3b.chunk.css"
  },
  {
    "revision": "84c23a8cf6dd4f5dcc78",
    "url": "/static/css/37.11000f17.chunk.css"
  },
  {
    "revision": "1d4c6592ee85af86b320",
    "url": "/static/css/40.11000f17.chunk.css"
  },
  {
    "revision": "5e52b3d28ffa2e838fb6",
    "url": "/static/css/45.3f1b51c5.chunk.css"
  },
  {
    "revision": "9de1cee09418614b6bb5",
    "url": "/static/css/46.d3aa4a18.chunk.css"
  },
  {
    "revision": "0b6f80d958496de7e4ab",
    "url": "/static/css/50.0724d5f1.chunk.css"
  },
  {
    "revision": "4c04c84c37fa593daba1",
    "url": "/static/css/51.11000f17.chunk.css"
  },
  {
    "revision": "47631cd3f7dd6373de89",
    "url": "/static/css/53.3dd4b2ef.chunk.css"
  },
  {
    "revision": "ec7bce7ed1bfa15c35c0",
    "url": "/static/css/54.83e70231.chunk.css"
  },
  {
    "revision": "acc26a2b936fc119d7e0",
    "url": "/static/css/55.0724d5f1.chunk.css"
  },
  {
    "revision": "ac86c67c8243c3472cf6",
    "url": "/static/css/56.90a5e751.chunk.css"
  },
  {
    "revision": "79b386db4c472e8047db",
    "url": "/static/css/57.90a5e751.chunk.css"
  },
  {
    "revision": "e625a22060f59d3ac445",
    "url": "/static/css/61.cdaf15d1.chunk.css"
  },
  {
    "revision": "4e2048057bdc98746c75",
    "url": "/static/css/63.5b5fb56a.chunk.css"
  },
  {
    "revision": "a35b9a1186c1fc83c88f",
    "url": "/static/css/main.c0c921cc.chunk.css"
  },
  {
    "revision": "9f3ffb6a748c95573d2c",
    "url": "/static/js/0.b8e7d997.chunk.js"
  },
  {
    "revision": "b1724dd3071494fbd8b2",
    "url": "/static/js/1.8c40c676.chunk.js"
  },
  {
    "revision": "e61dfbfc01ebb08d3d84",
    "url": "/static/js/10.10ec930f.chunk.js"
  },
  {
    "revision": "91e61e26d6e54406df80",
    "url": "/static/js/100.90a6dc66.chunk.js"
  },
  {
    "revision": "6a283d0c9d558869a7af",
    "url": "/static/js/101.ced02b73.chunk.js"
  },
  {
    "revision": "0015e3016878f850f39a",
    "url": "/static/js/102.854e7fec.chunk.js"
  },
  {
    "revision": "7791cf8bf4f187ba8d1f",
    "url": "/static/js/103.fd917d77.chunk.js"
  },
  {
    "revision": "a7df5f47a891f9aebcc8",
    "url": "/static/js/104.253a2c17.chunk.js"
  },
  {
    "revision": "308e01b60e56c2775df1",
    "url": "/static/js/105.1f6d68ce.chunk.js"
  },
  {
    "revision": "e5d7750b4bd685a46778",
    "url": "/static/js/106.35382f47.chunk.js"
  },
  {
    "revision": "b5e2777b89b7cbf51942",
    "url": "/static/js/107.4a3a0cd5.chunk.js"
  },
  {
    "revision": "23c25f75d527547d5a0c",
    "url": "/static/js/108.f5b65564.chunk.js"
  },
  {
    "revision": "e630b86542756c1f6b71",
    "url": "/static/js/109.833f1c04.chunk.js"
  },
  {
    "revision": "2b6eab4a1eefd6d234a4",
    "url": "/static/js/11.4bdf5640.chunk.js"
  },
  {
    "revision": "b708d9bd1034edf18b21",
    "url": "/static/js/110.f639b508.chunk.js"
  },
  {
    "revision": "5851974a0b63d11e8e02",
    "url": "/static/js/111.da50f66c.chunk.js"
  },
  {
    "revision": "870fb8988171448a9e55",
    "url": "/static/js/112.cf2f2339.chunk.js"
  },
  {
    "revision": "7f70dc2f2f5e92fa618f",
    "url": "/static/js/113.54be6e0a.chunk.js"
  },
  {
    "revision": "e2fc3e3648d19667ff29",
    "url": "/static/js/114.68b6ecb2.chunk.js"
  },
  {
    "revision": "fce625f038198fe2f8cf",
    "url": "/static/js/115.9db4f354.chunk.js"
  },
  {
    "revision": "3ef1510609ff83125cbf",
    "url": "/static/js/116.21c606ee.chunk.js"
  },
  {
    "revision": "c6bf3d72a4fe155ccf31",
    "url": "/static/js/117.e5ea0b58.chunk.js"
  },
  {
    "revision": "34af42d17364f237e516",
    "url": "/static/js/118.15814308.chunk.js"
  },
  {
    "revision": "0248b20dfd5889fd3493",
    "url": "/static/js/12.319b5667.chunk.js"
  },
  {
    "revision": "13acb7b27b759d3a9363",
    "url": "/static/js/13.eb9bdd58.chunk.js"
  },
  {
    "revision": "79bb833badb096787a85",
    "url": "/static/js/14.fe4a62da.chunk.js"
  },
  {
    "revision": "bc8ff83521c25476ff3d",
    "url": "/static/js/15.b2c2fa73.chunk.js"
  },
  {
    "revision": "fc370edd25427c2289c1",
    "url": "/static/js/16.f7098c35.chunk.js"
  },
  {
    "revision": "4dbd54c216f212f43943",
    "url": "/static/js/17.0cb08e7b.chunk.js"
  },
  {
    "revision": "9427b63b7f6d30174dd5",
    "url": "/static/js/18.9429317c.chunk.js"
  },
  {
    "revision": "49f24493f0846d781ebc",
    "url": "/static/js/19.82e00102.chunk.js"
  },
  {
    "revision": "a3a951318fd030af7a0d",
    "url": "/static/js/2.2ccf50f5.chunk.js"
  },
  {
    "revision": "26a71025ef03335577a8",
    "url": "/static/js/20.4a5a65d0.chunk.js"
  },
  {
    "revision": "b76280cc45d00caba913",
    "url": "/static/js/21.f16d9a0f.chunk.js"
  },
  {
    "revision": "ac13caf9dc0b5f9aa950",
    "url": "/static/js/22.5afdedfb.chunk.js"
  },
  {
    "revision": "d960af8c2d020943b229",
    "url": "/static/js/23.2392e0e3.chunk.js"
  },
  {
    "revision": "c3a70edc4ed21bd93750",
    "url": "/static/js/24.747224de.chunk.js"
  },
  {
    "revision": "ad0f2b0215414b06384d",
    "url": "/static/js/25.3e1af474.chunk.js"
  },
  {
    "revision": "10924d78207903164183",
    "url": "/static/js/28.ff7e3bbe.chunk.js"
  },
  {
    "revision": "57f48a40ec4bbebc925c",
    "url": "/static/js/29.ffc0a1de.chunk.js"
  },
  {
    "revision": "9afeb768243abba39bc9",
    "url": "/static/js/3.21b668d6.chunk.js"
  },
  {
    "revision": "615da03e2b9a0f208594",
    "url": "/static/js/30.e37b4a5f.chunk.js"
  },
  {
    "revision": "fc9d5be97ee9412ff756",
    "url": "/static/js/31.5f6a98fa.chunk.js"
  },
  {
    "revision": "ecf943a0887d150fb12d",
    "url": "/static/js/32.12cf3ca9.chunk.js"
  },
  {
    "revision": "22907f59ff31d9fffd95",
    "url": "/static/js/33.efb0e77c.chunk.js"
  },
  {
    "revision": "206f05ffc56c4c288c4f",
    "url": "/static/js/34.2a785e2c.chunk.js"
  },
  {
    "revision": "00f7ce424aeb9155e5e1",
    "url": "/static/js/35.e989603b.chunk.js"
  },
  {
    "revision": "541a3d14d5784677c5e0",
    "url": "/static/js/36.9bc7cec4.chunk.js"
  },
  {
    "revision": "84c23a8cf6dd4f5dcc78",
    "url": "/static/js/37.ba072548.chunk.js"
  },
  {
    "revision": "2df75578219f235985c0",
    "url": "/static/js/38.2301f97b.chunk.js"
  },
  {
    "revision": "e32658a32738c8e00aa4",
    "url": "/static/js/39.037cd880.chunk.js"
  },
  {
    "revision": "d72efd14f1ed641d68c8",
    "url": "/static/js/4.1f2f69e8.chunk.js"
  },
  {
    "revision": "1d4c6592ee85af86b320",
    "url": "/static/js/40.87d705c1.chunk.js"
  },
  {
    "revision": "32782346d4301e759346",
    "url": "/static/js/41.202f2ee4.chunk.js"
  },
  {
    "revision": "9aec027c2119066b4eae",
    "url": "/static/js/42.9145de20.chunk.js"
  },
  {
    "revision": "323870a95e644fa6c2f2",
    "url": "/static/js/43.8027aff5.chunk.js"
  },
  {
    "revision": "f4704e9fd00ef1833ed4",
    "url": "/static/js/44.1a6c5eca.chunk.js"
  },
  {
    "revision": "5e52b3d28ffa2e838fb6",
    "url": "/static/js/45.e970d4d9.chunk.js"
  },
  {
    "revision": "9de1cee09418614b6bb5",
    "url": "/static/js/46.cbc1cec8.chunk.js"
  },
  {
    "revision": "e165bacb3f770d45ce2a",
    "url": "/static/js/47.2d8e32fb.chunk.js"
  },
  {
    "revision": "48aa90d14dcebdd8e8f5",
    "url": "/static/js/48.70c77286.chunk.js"
  },
  {
    "revision": "19eb3d6a2086528aa347",
    "url": "/static/js/49.33feb99f.chunk.js"
  },
  {
    "revision": "146311f642bc7011732f",
    "url": "/static/js/5.a8416247.chunk.js"
  },
  {
    "revision": "0b6f80d958496de7e4ab",
    "url": "/static/js/50.684c8354.chunk.js"
  },
  {
    "revision": "4c04c84c37fa593daba1",
    "url": "/static/js/51.3fe314a8.chunk.js"
  },
  {
    "revision": "888bf19a77ac9513bece",
    "url": "/static/js/52.450413c3.chunk.js"
  },
  {
    "revision": "47631cd3f7dd6373de89",
    "url": "/static/js/53.6f379f3a.chunk.js"
  },
  {
    "revision": "ec7bce7ed1bfa15c35c0",
    "url": "/static/js/54.6d7b3db0.chunk.js"
  },
  {
    "revision": "acc26a2b936fc119d7e0",
    "url": "/static/js/55.d50351c5.chunk.js"
  },
  {
    "revision": "ac86c67c8243c3472cf6",
    "url": "/static/js/56.2b936643.chunk.js"
  },
  {
    "revision": "79b386db4c472e8047db",
    "url": "/static/js/57.f973875a.chunk.js"
  },
  {
    "revision": "c88f172cbb996ce841a8",
    "url": "/static/js/58.6a42333a.chunk.js"
  },
  {
    "revision": "4d70bc94eba7b25aeb0f",
    "url": "/static/js/59.d987ac9d.chunk.js"
  },
  {
    "revision": "135af65f08385f76226c",
    "url": "/static/js/6.749c7a0b.chunk.js"
  },
  {
    "revision": "14ce2532340dadbbc9eb",
    "url": "/static/js/60.f00fdea3.chunk.js"
  },
  {
    "revision": "e625a22060f59d3ac445",
    "url": "/static/js/61.a44a346e.chunk.js"
  },
  {
    "revision": "afe23bd7914ded3c77b7",
    "url": "/static/js/62.bcf40205.chunk.js"
  },
  {
    "revision": "4e2048057bdc98746c75",
    "url": "/static/js/63.d53dcbf9.chunk.js"
  },
  {
    "revision": "716dfb0da0b27f0fa2ba",
    "url": "/static/js/64.91b29ae7.chunk.js"
  },
  {
    "revision": "d830cb5c67b003b4fdc4",
    "url": "/static/js/65.5c06667f.chunk.js"
  },
  {
    "revision": "8a13a2f55d6a96d33e30",
    "url": "/static/js/66.bc89a9eb.chunk.js"
  },
  {
    "revision": "4c48ab638e6698e9328c",
    "url": "/static/js/67.f94439b3.chunk.js"
  },
  {
    "revision": "b44ad64ee7f3fbb63304",
    "url": "/static/js/68.0c1920b1.chunk.js"
  },
  {
    "revision": "add9e7daf37e866c197a",
    "url": "/static/js/69.07631dba.chunk.js"
  },
  {
    "revision": "be6ee629fb95178b9a52",
    "url": "/static/js/7.06512553.chunk.js"
  },
  {
    "revision": "a707f7c6ca374b49d41a",
    "url": "/static/js/70.d4356bb2.chunk.js"
  },
  {
    "revision": "d4564b490b92b7d67ad4",
    "url": "/static/js/71.d86761f0.chunk.js"
  },
  {
    "revision": "34ee5262c8c6a1322880",
    "url": "/static/js/72.898f747e.chunk.js"
  },
  {
    "revision": "93895c3ebc81cabc010c",
    "url": "/static/js/73.7f4d25f3.chunk.js"
  },
  {
    "revision": "c5e380c6bbd84edbd383",
    "url": "/static/js/74.4b481cbd.chunk.js"
  },
  {
    "revision": "b3f30c807d9b2e2d495e",
    "url": "/static/js/75.4d68a05c.chunk.js"
  },
  {
    "revision": "60dff89f191a6fe8d2ba",
    "url": "/static/js/76.a5b80597.chunk.js"
  },
  {
    "revision": "731f82fd5576f32f1ebf",
    "url": "/static/js/77.bd1962e4.chunk.js"
  },
  {
    "revision": "98941f814ed536e49b66",
    "url": "/static/js/78.8acc2a2d.chunk.js"
  },
  {
    "revision": "23f8936a24b1daa70066",
    "url": "/static/js/79.8a408a6f.chunk.js"
  },
  {
    "revision": "7b413f380c978ca8b116",
    "url": "/static/js/8.db7c2ccc.chunk.js"
  },
  {
    "revision": "c67b22de385e98c3b7ba",
    "url": "/static/js/80.4671c175.chunk.js"
  },
  {
    "revision": "404d25a178e31d497252",
    "url": "/static/js/81.f4698b9f.chunk.js"
  },
  {
    "revision": "7e41b25e31218c815fff",
    "url": "/static/js/82.35a34b22.chunk.js"
  },
  {
    "revision": "411d10a989e23e03a63e",
    "url": "/static/js/83.4819cb11.chunk.js"
  },
  {
    "revision": "29e9e8ac2ac904d566b5",
    "url": "/static/js/84.f7c0e255.chunk.js"
  },
  {
    "revision": "68fc9a688a44f2b5a82d",
    "url": "/static/js/85.ba69ef0d.chunk.js"
  },
  {
    "revision": "2da97cb90726e66009c1",
    "url": "/static/js/86.468115c3.chunk.js"
  },
  {
    "revision": "1767c53cc2e833d66657",
    "url": "/static/js/87.ed10b05d.chunk.js"
  },
  {
    "revision": "6d9b73f85cf90d7a38ca",
    "url": "/static/js/88.59de1650.chunk.js"
  },
  {
    "revision": "b1a291e79302afe4b9f8",
    "url": "/static/js/89.1bd52445.chunk.js"
  },
  {
    "revision": "d37e95ecdd76e89c95a9",
    "url": "/static/js/9.10284b9e.chunk.js"
  },
  {
    "revision": "6a0b6c4203e19fd322ae",
    "url": "/static/js/90.ba4b88a1.chunk.js"
  },
  {
    "revision": "4bdbee94599df4dfce1f",
    "url": "/static/js/91.6e89b125.chunk.js"
  },
  {
    "revision": "41379d71ff8be8045cbe",
    "url": "/static/js/92.3c5d2181.chunk.js"
  },
  {
    "revision": "e2c17edc0a81887106e3",
    "url": "/static/js/93.26430bec.chunk.js"
  },
  {
    "revision": "7503b036d11a5c63644a",
    "url": "/static/js/94.8bab584f.chunk.js"
  },
  {
    "revision": "a02cdbc2e2d96007af9b",
    "url": "/static/js/95.b80a82ea.chunk.js"
  },
  {
    "revision": "deea330cd935df154988",
    "url": "/static/js/96.314e300a.chunk.js"
  },
  {
    "revision": "eacfe8490c9429ccc782",
    "url": "/static/js/97.b1c069c7.chunk.js"
  },
  {
    "revision": "8da995cbe3e79b9f0897",
    "url": "/static/js/98.497c3436.chunk.js"
  },
  {
    "revision": "fd813a74660c50f9829b",
    "url": "/static/js/99.e0524253.chunk.js"
  },
  {
    "revision": "a35b9a1186c1fc83c88f",
    "url": "/static/js/main.eed819c1.chunk.js"
  },
  {
    "revision": "f1c633bff3f887ef210c",
    "url": "/static/js/runtime~main.ec3b83c4.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);