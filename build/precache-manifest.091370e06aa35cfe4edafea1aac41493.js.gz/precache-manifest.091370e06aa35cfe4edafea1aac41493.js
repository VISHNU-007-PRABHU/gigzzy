self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9a6ddfd210de8c10fb8e174a8518766a",
    "url": "/index.html"
  },
  {
    "revision": "83784f7c8ae4aac29040",
    "url": "/static/css/14.93107784.chunk.css"
  },
  {
    "revision": "1cc1eb60a7f72845f032",
    "url": "/static/css/main.e03045ae.chunk.css"
  },
  {
    "revision": "117c7bf5485ed5a3626d",
    "url": "/static/js/0.1aa38773.chunk.js"
  },
  {
    "revision": "2ae01f680b2dfde3e340",
    "url": "/static/js/1.e0f42ac7.chunk.js"
  },
  {
    "revision": "f601eadc0a2107f396e9",
    "url": "/static/js/10.76678d8b.chunk.js"
  },
  {
    "revision": "d96dd5b9747a4e341372",
    "url": "/static/js/11.04394eb4.chunk.js"
  },
  {
    "revision": "83784f7c8ae4aac29040",
    "url": "/static/js/14.003eeba0.chunk.js"
  },
  {
    "revision": "21e46368b3ee54e3539c",
    "url": "/static/js/15.8d03b3f7.chunk.js"
  },
  {
    "revision": "6b0fcc00c2614645c3d0",
    "url": "/static/js/16.b1b281a7.chunk.js"
  },
  {
    "revision": "04a2ddc7adbe0c0ada1c",
    "url": "/static/js/17.710cb202.chunk.js"
  },
  {
    "revision": "d5b6f57c86259e2dae08",
    "url": "/static/js/18.4faa74db.chunk.js"
  },
  {
    "revision": "9af8dfa3856abd098293",
    "url": "/static/js/19.83ed107c.chunk.js"
  },
  {
    "revision": "ea53ca608aab7b8d8923",
    "url": "/static/js/2.ac8d79ad.chunk.js"
  },
  {
    "revision": "7576ae56b5688628935d",
    "url": "/static/js/20.bdd2293f.chunk.js"
  },
  {
    "revision": "1bcd27a77cbc8a5d2cfc",
    "url": "/static/js/21.844b6c39.chunk.js"
  },
  {
    "revision": "3d2292f477bdcb681dee",
    "url": "/static/js/22.f32d051a.chunk.js"
  },
  {
    "revision": "f0d8013a41a1b0de02d4",
    "url": "/static/js/23.8d47e187.chunk.js"
  },
  {
    "revision": "0ba781c4b3865001d588",
    "url": "/static/js/24.b0036ae9.chunk.js"
  },
  {
    "revision": "091264cdf2dc2de31877",
    "url": "/static/js/25.be42f61e.chunk.js"
  },
  {
    "revision": "be1bdcf6481662f41c7a",
    "url": "/static/js/26.7309d7e2.chunk.js"
  },
  {
    "revision": "5dc41778975a29489210",
    "url": "/static/js/27.e240dc78.chunk.js"
  },
  {
    "revision": "8ffd71b1eab82ba7ebdc",
    "url": "/static/js/28.a3388c90.chunk.js"
  },
  {
    "revision": "a886f549c3e320896a72",
    "url": "/static/js/29.b5c460c9.chunk.js"
  },
  {
    "revision": "76b377cc0ed05c3cc629",
    "url": "/static/js/3.e9d18b6c.chunk.js"
  },
  {
    "revision": "566174e9d33da09ab1d0",
    "url": "/static/js/30.cd36a5a6.chunk.js"
  },
  {
    "revision": "d216922ec53d72a0099b",
    "url": "/static/js/31.566a6feb.chunk.js"
  },
  {
    "revision": "1bbc4f0dc7adcb4b6284",
    "url": "/static/js/32.61a358a6.chunk.js"
  },
  {
    "revision": "b28a8d464adf70601bd4",
    "url": "/static/js/33.2b9b3c33.chunk.js"
  },
  {
    "revision": "d5eeb1fd6b2dad6dcb24",
    "url": "/static/js/34.584bad82.chunk.js"
  },
  {
    "revision": "cc2bb9793470e6078ceb",
    "url": "/static/js/35.2aa8f75e.chunk.js"
  },
  {
    "revision": "8a6779b451f6c7031a7a",
    "url": "/static/js/36.38c1f779.chunk.js"
  },
  {
    "revision": "4b198f872b3285bda993",
    "url": "/static/js/37.5bed156e.chunk.js"
  },
  {
    "revision": "da04258bcc2d912ba835",
    "url": "/static/js/38.deed1e5f.chunk.js"
  },
  {
    "revision": "232a54a2113efde772fb",
    "url": "/static/js/39.49138be3.chunk.js"
  },
  {
    "revision": "305be55bd074e3a67d78",
    "url": "/static/js/4.34344696.chunk.js"
  },
  {
    "revision": "87958a1d898fd5c978c3",
    "url": "/static/js/40.cc10ca04.chunk.js"
  },
  {
    "revision": "5e39530a1803b8cf89fa",
    "url": "/static/js/41.b565c009.chunk.js"
  },
  {
    "revision": "ce1b8f9f748acafb5adc",
    "url": "/static/js/42.707fc263.chunk.js"
  },
  {
    "revision": "a54f2cbe4b79bf804b80",
    "url": "/static/js/43.6db93b7b.chunk.js"
  },
  {
    "revision": "62bd5c9cebff211c6372",
    "url": "/static/js/44.83e2f4d6.chunk.js"
  },
  {
    "revision": "fa888ea392bfc71c710a",
    "url": "/static/js/45.2a5621bf.chunk.js"
  },
  {
    "revision": "269bba0e8d5cd8720b9b",
    "url": "/static/js/46.bf803b41.chunk.js"
  },
  {
    "revision": "53026d8ac9f2aa1cc121",
    "url": "/static/js/47.23aaa856.chunk.js"
  },
  {
    "revision": "fefd39489e37290be8c2",
    "url": "/static/js/48.00ca9dbb.chunk.js"
  },
  {
    "revision": "1c7884a528fecab9a915",
    "url": "/static/js/49.2f3024b4.chunk.js"
  },
  {
    "revision": "bc1dcb41c921e3672aba",
    "url": "/static/js/5.07d75ceb.chunk.js"
  },
  {
    "revision": "84a654fc386239729ae9",
    "url": "/static/js/50.bafa6eda.chunk.js"
  },
  {
    "revision": "9882086d012a738c0f02",
    "url": "/static/js/51.f6d00991.chunk.js"
  },
  {
    "revision": "59d0afb4e821615942b7",
    "url": "/static/js/52.33cf2773.chunk.js"
  },
  {
    "revision": "2f26da854378b04dcfd0",
    "url": "/static/js/53.be8b6c93.chunk.js"
  },
  {
    "revision": "e6d65885dee7ce261eff",
    "url": "/static/js/54.1d5505d5.chunk.js"
  },
  {
    "revision": "475b1e6ab82e5718672b",
    "url": "/static/js/55.9667a521.chunk.js"
  },
  {
    "revision": "07b8ad4094248bdf53ce",
    "url": "/static/js/56.1d3e45f9.chunk.js"
  },
  {
    "revision": "78bc88eca5e6d7abb093",
    "url": "/static/js/57.a2dda2e6.chunk.js"
  },
  {
    "revision": "69cd0603a8f56af48a9b",
    "url": "/static/js/58.a6c4c3fb.chunk.js"
  },
  {
    "revision": "5d38a11b299c9b42073e",
    "url": "/static/js/59.ae39d7c6.chunk.js"
  },
  {
    "revision": "7187efad84f7220b3af1",
    "url": "/static/js/6.a8512253.chunk.js"
  },
  {
    "revision": "0e1195107af81c6c65f9",
    "url": "/static/js/60.e89c99de.chunk.js"
  },
  {
    "revision": "7b59c4df18480c0cb72d",
    "url": "/static/js/61.f2f77dc9.chunk.js"
  },
  {
    "revision": "0c9b4902b70fd2341158",
    "url": "/static/js/62.f2b70bc6.chunk.js"
  },
  {
    "revision": "c93424d38ea2e1a07a08",
    "url": "/static/js/63.ac02a629.chunk.js"
  },
  {
    "revision": "2d050ec0655c0556bd41",
    "url": "/static/js/7.70cd6b23.chunk.js"
  },
  {
    "revision": "005943e003bf53b9c528",
    "url": "/static/js/8.f360fdb2.chunk.js"
  },
  {
    "revision": "9790c07aea8cd5a5b11b",
    "url": "/static/js/9.eec0df98.chunk.js"
  },
  {
    "revision": "1cc1eb60a7f72845f032",
    "url": "/static/js/main.49595c09.chunk.js"
  },
  {
    "revision": "092a83127d8353b259ee",
    "url": "/static/js/runtime~main.edd8cc6c.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);