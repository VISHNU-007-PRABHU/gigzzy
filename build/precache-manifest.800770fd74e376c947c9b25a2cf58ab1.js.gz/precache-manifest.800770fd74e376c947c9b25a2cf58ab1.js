self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1056ebbb3a6036044c2610b6bde9d4a1",
    "url": "/index.html"
  },
  {
    "revision": "c537880b54b3ee48bfba",
    "url": "/static/css/20.cdaf15d1.chunk.css"
  },
  {
    "revision": "69fff4e21b4471bc04f6",
    "url": "/static/css/30.051905ae.chunk.css"
  },
  {
    "revision": "66ab2095a6f418c76383",
    "url": "/static/css/31.3a6be942.chunk.css"
  },
  {
    "revision": "d851be835e2847f57d82",
    "url": "/static/css/32.88292131.chunk.css"
  },
  {
    "revision": "f4ab6f9190da55bf6731",
    "url": "/static/css/37.c9556fed.chunk.css"
  },
  {
    "revision": "b523d025e8cbeb0477c5",
    "url": "/static/css/39.11000f17.chunk.css"
  },
  {
    "revision": "8ae72b36a6d7c6414661",
    "url": "/static/css/42.11000f17.chunk.css"
  },
  {
    "revision": "c5f38f8c3c60f225d742",
    "url": "/static/css/47.52c43222.chunk.css"
  },
  {
    "revision": "45948f6e1852ed1a34d7",
    "url": "/static/css/48.8cf98a25.chunk.css"
  },
  {
    "revision": "f49f2e1bf7d88b7d10e1",
    "url": "/static/css/52.f9b90304.chunk.css"
  },
  {
    "revision": "140e13cab5940c9438a1",
    "url": "/static/css/53.11000f17.chunk.css"
  },
  {
    "revision": "7a090d57f90117a9827f",
    "url": "/static/css/55.9142c0f9.chunk.css"
  },
  {
    "revision": "d2e28609de4fc931484e",
    "url": "/static/css/56.9142c0f9.chunk.css"
  },
  {
    "revision": "cbdcd1f4e2f503300305",
    "url": "/static/css/57.0724d5f1.chunk.css"
  },
  {
    "revision": "707ae95f1688278e696c",
    "url": "/static/css/58.3a6be942.chunk.css"
  },
  {
    "revision": "9f9b5fb1da471028ff0e",
    "url": "/static/css/59.3a6be942.chunk.css"
  },
  {
    "revision": "c92a01e4e238f80b341e",
    "url": "/static/css/63.cdaf15d1.chunk.css"
  },
  {
    "revision": "e81e3bd728b06f7145a3",
    "url": "/static/css/65.5b5fb56a.chunk.css"
  },
  {
    "revision": "0c165bcf199c4f07219d",
    "url": "/static/css/main.777ddbbe.chunk.css"
  },
  {
    "revision": "79ddefaa7686878badb6",
    "url": "/static/js/0.c9285907.chunk.js"
  },
  {
    "revision": "dbdfb237a6087a47ce7b",
    "url": "/static/js/1.f91b5516.chunk.js"
  },
  {
    "revision": "879236b1752f468df740",
    "url": "/static/js/10.36a0169a.chunk.js"
  },
  {
    "revision": "5aa2f7ed855d5b1539ed",
    "url": "/static/js/100.bc0980a1.chunk.js"
  },
  {
    "revision": "f7fee034181fec46f9f9",
    "url": "/static/js/101.c5a21963.chunk.js"
  },
  {
    "revision": "d7b41a0bae96d1b64d91",
    "url": "/static/js/102.998c3ff8.chunk.js"
  },
  {
    "revision": "eef9e45501c90c4a6af0",
    "url": "/static/js/103.910f45f9.chunk.js"
  },
  {
    "revision": "ec12e06f8213b3765147",
    "url": "/static/js/104.76a73ee7.chunk.js"
  },
  {
    "revision": "2b5d07b13f9617908cdc",
    "url": "/static/js/105.baae3093.chunk.js"
  },
  {
    "revision": "46e2712dcdff11d09f8d",
    "url": "/static/js/106.6a67406a.chunk.js"
  },
  {
    "revision": "77b49a61126b34c0b12f",
    "url": "/static/js/107.d7ecb1a6.chunk.js"
  },
  {
    "revision": "891d167b5d01a310cbf9",
    "url": "/static/js/108.640b2cd6.chunk.js"
  },
  {
    "revision": "794db6ac4211f570b15e",
    "url": "/static/js/109.b40da562.chunk.js"
  },
  {
    "revision": "60f4c604bb6f770d8655",
    "url": "/static/js/11.d53005f1.chunk.js"
  },
  {
    "revision": "04480066f1e73ae7e5f0",
    "url": "/static/js/110.3c0570f7.chunk.js"
  },
  {
    "revision": "eefc2d604613d8a3fcfe",
    "url": "/static/js/111.b351c24e.chunk.js"
  },
  {
    "revision": "e0ebb025dcba96bc81a9",
    "url": "/static/js/112.de50dddf.chunk.js"
  },
  {
    "revision": "a96f7b50343574bd6a77",
    "url": "/static/js/113.615f5d8b.chunk.js"
  },
  {
    "revision": "a37c2e97232edf555805",
    "url": "/static/js/114.410e4946.chunk.js"
  },
  {
    "revision": "6251b0ddc99a9eed6d3a",
    "url": "/static/js/115.5efb4641.chunk.js"
  },
  {
    "revision": "510042d8767db71fe632",
    "url": "/static/js/116.d8e8eb77.chunk.js"
  },
  {
    "revision": "31e4cd02431b2fcdcc2a",
    "url": "/static/js/117.946aae79.chunk.js"
  },
  {
    "revision": "d4f9196a5f9293c71334",
    "url": "/static/js/118.a85c5898.chunk.js"
  },
  {
    "revision": "22c880a2ebf8476183d9",
    "url": "/static/js/12.858f4d72.chunk.js"
  },
  {
    "revision": "63b2e97da5950f32d0da",
    "url": "/static/js/13.ca572ebc.chunk.js"
  },
  {
    "revision": "544026da44b282cdfd13",
    "url": "/static/js/14.a351266a.chunk.js"
  },
  {
    "revision": "282cdf685b6630ad4925",
    "url": "/static/js/15.b1c6e9c5.chunk.js"
  },
  {
    "revision": "9ccafe02eaef1af1392a",
    "url": "/static/js/16.b1f74a0d.chunk.js"
  },
  {
    "revision": "23eb49143fb81f79e1a4",
    "url": "/static/js/17.b2ee80f6.chunk.js"
  },
  {
    "revision": "1562c03ba66de0d36fdb",
    "url": "/static/js/18.9c5917b2.chunk.js"
  },
  {
    "revision": "b89f9a381a8de3308f6f",
    "url": "/static/js/19.b2d98531.chunk.js"
  },
  {
    "revision": "135a0d87c99646b4e0b6",
    "url": "/static/js/2.34ee16aa.chunk.js"
  },
  {
    "revision": "c537880b54b3ee48bfba",
    "url": "/static/js/20.8b9e655f.chunk.js"
  },
  {
    "revision": "2ceb3be5f986c71a6863",
    "url": "/static/js/21.ddd49e25.chunk.js"
  },
  {
    "revision": "815cdf1a04056485ea8e",
    "url": "/static/js/22.5ce30b9b.chunk.js"
  },
  {
    "revision": "a8fa49f893db1a25e32c",
    "url": "/static/js/23.401e741a.chunk.js"
  },
  {
    "revision": "3cbf6d781df26dfff33a",
    "url": "/static/js/24.7eda9f24.chunk.js"
  },
  {
    "revision": "1af894b7d59b0529a33a",
    "url": "/static/js/25.9070e73a.chunk.js"
  },
  {
    "revision": "31f29f2d393ae0e019eb",
    "url": "/static/js/26.fa30fcea.chunk.js"
  },
  {
    "revision": "e28490b0f235b6448b15",
    "url": "/static/js/27.cacc9207.chunk.js"
  },
  {
    "revision": "348250c8de18422a97c9",
    "url": "/static/js/3.519d0da2.chunk.js"
  },
  {
    "revision": "69fff4e21b4471bc04f6",
    "url": "/static/js/30.faa354ef.chunk.js"
  },
  {
    "revision": "66ab2095a6f418c76383",
    "url": "/static/js/31.a04d9b00.chunk.js"
  },
  {
    "revision": "d851be835e2847f57d82",
    "url": "/static/js/32.f1aeb011.chunk.js"
  },
  {
    "revision": "2a7e60bcb21aed876a2b",
    "url": "/static/js/33.856a3215.chunk.js"
  },
  {
    "revision": "1e93b4511c98f2b88532",
    "url": "/static/js/34.6cded381.chunk.js"
  },
  {
    "revision": "4907eaa0a6003bf0b4ec",
    "url": "/static/js/35.95b5a533.chunk.js"
  },
  {
    "revision": "2eda28b26c9025ef4ee2",
    "url": "/static/js/36.35a851ba.chunk.js"
  },
  {
    "revision": "f4ab6f9190da55bf6731",
    "url": "/static/js/37.4d75abc6.chunk.js"
  },
  {
    "revision": "5f598cb9a31a746315f9",
    "url": "/static/js/38.6f81f79b.chunk.js"
  },
  {
    "revision": "b523d025e8cbeb0477c5",
    "url": "/static/js/39.dd777e8d.chunk.js"
  },
  {
    "revision": "b21ed210aea5b43aebdc",
    "url": "/static/js/4.6e0b8448.chunk.js"
  },
  {
    "revision": "7cb29f0a7d43a823f151",
    "url": "/static/js/40.88582f47.chunk.js"
  },
  {
    "revision": "6cb6d3b5830069804452",
    "url": "/static/js/41.1aa9461e.chunk.js"
  },
  {
    "revision": "8ae72b36a6d7c6414661",
    "url": "/static/js/42.b31c9503.chunk.js"
  },
  {
    "revision": "e65eaca9d356e43f0476",
    "url": "/static/js/43.c691558d.chunk.js"
  },
  {
    "revision": "b3fb2381544c9ec09178",
    "url": "/static/js/44.76bca387.chunk.js"
  },
  {
    "revision": "554eddb385018b807c81",
    "url": "/static/js/45.6f6cca42.chunk.js"
  },
  {
    "revision": "348b8a229a5f92bca682",
    "url": "/static/js/46.9421afdc.chunk.js"
  },
  {
    "revision": "c5f38f8c3c60f225d742",
    "url": "/static/js/47.90c9f12c.chunk.js"
  },
  {
    "revision": "45948f6e1852ed1a34d7",
    "url": "/static/js/48.3cd293c0.chunk.js"
  },
  {
    "revision": "9af4b1e6d20fcbde10b2",
    "url": "/static/js/49.29ea604c.chunk.js"
  },
  {
    "revision": "2ae4b7e672155caca9a5",
    "url": "/static/js/5.a7bda358.chunk.js"
  },
  {
    "revision": "39f09e1db1fb67b5d888",
    "url": "/static/js/50.c2203376.chunk.js"
  },
  {
    "revision": "23e418ef2485e8240dd2",
    "url": "/static/js/51.92eb9307.chunk.js"
  },
  {
    "revision": "f49f2e1bf7d88b7d10e1",
    "url": "/static/js/52.a1639813.chunk.js"
  },
  {
    "revision": "140e13cab5940c9438a1",
    "url": "/static/js/53.71e4c2ea.chunk.js"
  },
  {
    "revision": "dbf7731d20484f3d96d7",
    "url": "/static/js/54.dad898ad.chunk.js"
  },
  {
    "revision": "7a090d57f90117a9827f",
    "url": "/static/js/55.ece53ddb.chunk.js"
  },
  {
    "revision": "d2e28609de4fc931484e",
    "url": "/static/js/56.b7dbf12b.chunk.js"
  },
  {
    "revision": "cbdcd1f4e2f503300305",
    "url": "/static/js/57.80f81c29.chunk.js"
  },
  {
    "revision": "707ae95f1688278e696c",
    "url": "/static/js/58.ec82d1ec.chunk.js"
  },
  {
    "revision": "9f9b5fb1da471028ff0e",
    "url": "/static/js/59.435e1fd5.chunk.js"
  },
  {
    "revision": "befbea115e5cdb94ed74",
    "url": "/static/js/6.b36fdd9b.chunk.js"
  },
  {
    "revision": "71fb0f095290c6c1a157",
    "url": "/static/js/60.37227035.chunk.js"
  },
  {
    "revision": "148a4bb801f90325c096",
    "url": "/static/js/61.4e78601a.chunk.js"
  },
  {
    "revision": "70e7096fef1c4314d1eb",
    "url": "/static/js/62.c5ec70e0.chunk.js"
  },
  {
    "revision": "c92a01e4e238f80b341e",
    "url": "/static/js/63.45e2df0e.chunk.js"
  },
  {
    "revision": "b0e7694b4429e4777365",
    "url": "/static/js/64.ed37c5df.chunk.js"
  },
  {
    "revision": "e81e3bd728b06f7145a3",
    "url": "/static/js/65.f139477f.chunk.js"
  },
  {
    "revision": "4a818f0a45d1f8951b8b",
    "url": "/static/js/66.948536ad.chunk.js"
  },
  {
    "revision": "072cedbcc0a3f874ef3e",
    "url": "/static/js/67.26f001c5.chunk.js"
  },
  {
    "revision": "63ce567b69a2e398838d",
    "url": "/static/js/68.f84df653.chunk.js"
  },
  {
    "revision": "066d4f23b098f0083149",
    "url": "/static/js/69.9d4380d4.chunk.js"
  },
  {
    "revision": "4b51dfeb55fb06b1bd4b",
    "url": "/static/js/7.e73e8810.chunk.js"
  },
  {
    "revision": "92588e3890a085ee4558",
    "url": "/static/js/70.c2c2e3be.chunk.js"
  },
  {
    "revision": "752b2c275f9256934532",
    "url": "/static/js/71.9e7812a9.chunk.js"
  },
  {
    "revision": "6edfc838025af9ca95ce",
    "url": "/static/js/72.acf68e70.chunk.js"
  },
  {
    "revision": "8c6eb30721468bc53be7",
    "url": "/static/js/73.879b8026.chunk.js"
  },
  {
    "revision": "cdf8969cdae10831ca47",
    "url": "/static/js/74.fccd3af6.chunk.js"
  },
  {
    "revision": "3d546e76a182f78da8e9",
    "url": "/static/js/75.870c8668.chunk.js"
  },
  {
    "revision": "95e0d8ef663629187a46",
    "url": "/static/js/76.ecbf823c.chunk.js"
  },
  {
    "revision": "ffffec351482dcfc9def",
    "url": "/static/js/77.9909037e.chunk.js"
  },
  {
    "revision": "1dea470b2ffa5720fb30",
    "url": "/static/js/78.9ea62c0e.chunk.js"
  },
  {
    "revision": "a659ad586355861702ea",
    "url": "/static/js/79.c69bc7c1.chunk.js"
  },
  {
    "revision": "de5ed25fa0ab7a7a977b",
    "url": "/static/js/8.d9c1c03e.chunk.js"
  },
  {
    "revision": "b95d5b12a2550a1de756",
    "url": "/static/js/80.9c2e54a2.chunk.js"
  },
  {
    "revision": "c9e2a79aac793e8eb72f",
    "url": "/static/js/81.85074e65.chunk.js"
  },
  {
    "revision": "c91d547dc7c3d207720d",
    "url": "/static/js/82.240fb13d.chunk.js"
  },
  {
    "revision": "aefd58fc636ca5823c30",
    "url": "/static/js/83.37eab591.chunk.js"
  },
  {
    "revision": "78c0f623d32a4f6e27c4",
    "url": "/static/js/84.848b3d2f.chunk.js"
  },
  {
    "revision": "c028dba599567a8ee8c9",
    "url": "/static/js/85.fea516b6.chunk.js"
  },
  {
    "revision": "8fd5993dfa43430cf953",
    "url": "/static/js/86.cb90090f.chunk.js"
  },
  {
    "revision": "3500950bd8621bb6d397",
    "url": "/static/js/87.e75ceeb8.chunk.js"
  },
  {
    "revision": "cd589c20c99ae717ee47",
    "url": "/static/js/88.c22075f5.chunk.js"
  },
  {
    "revision": "03a38beb1c31ec3af449",
    "url": "/static/js/89.4a14a075.chunk.js"
  },
  {
    "revision": "f970de56111719c725b6",
    "url": "/static/js/9.47524887.chunk.js"
  },
  {
    "revision": "0223e4f9641efc881ad1",
    "url": "/static/js/90.0524d5ee.chunk.js"
  },
  {
    "revision": "36d4d4c86a4366651363",
    "url": "/static/js/91.7427dd73.chunk.js"
  },
  {
    "revision": "8a68014a0a61f3fd1529",
    "url": "/static/js/92.49175b46.chunk.js"
  },
  {
    "revision": "c4892d5909d90aa2d1ae",
    "url": "/static/js/93.4d4af23b.chunk.js"
  },
  {
    "revision": "641850a11d363e99a50d",
    "url": "/static/js/94.14b9654f.chunk.js"
  },
  {
    "revision": "4d3730c810409f5df037",
    "url": "/static/js/95.d7f8863b.chunk.js"
  },
  {
    "revision": "3e4c4995ab086b6facf1",
    "url": "/static/js/96.f110e7e3.chunk.js"
  },
  {
    "revision": "140980a779d9ee073cd4",
    "url": "/static/js/97.2bfd3b7e.chunk.js"
  },
  {
    "revision": "975710d350873af180c9",
    "url": "/static/js/98.da618566.chunk.js"
  },
  {
    "revision": "211b6364ae72150fa769",
    "url": "/static/js/99.25b82812.chunk.js"
  },
  {
    "revision": "0c165bcf199c4f07219d",
    "url": "/static/js/main.018e7e06.chunk.js"
  },
  {
    "revision": "986a1d62ac1c71360db1",
    "url": "/static/js/runtime~main.77b7a8e2.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);