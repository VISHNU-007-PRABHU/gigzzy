self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9fe79764690669ba6d7d9738264c7cf9",
    "url": "/index.html"
  },
  {
    "revision": "30efbb8da1af84bb809f",
    "url": "/static/css/7.35721b09.chunk.css"
  },
  {
    "revision": "7ba9217498d13614894b",
    "url": "/static/css/main.b79fdc3c.chunk.css"
  },
  {
    "revision": "f23ce813e9c260c065ba",
    "url": "/static/js/0.e755902b.chunk.js"
  },
  {
    "revision": "2007a75bc75ee8a2929c",
    "url": "/static/js/1.6a1c7696.chunk.js"
  },
  {
    "revision": "d7575b6ebd37fe97b00c",
    "url": "/static/js/10.7399ef77.chunk.js"
  },
  {
    "revision": "2d7f304d2778fc0ba21f",
    "url": "/static/js/2.db6ce9a0.chunk.js"
  },
  {
    "revision": "2f09ba558b15c8506ea3",
    "url": "/static/js/3.62cbcf17.chunk.js"
  },
  {
    "revision": "ed40a8849da7cbbbed26",
    "url": "/static/js/4.216960e6.chunk.js"
  },
  {
    "revision": "30efbb8da1af84bb809f",
    "url": "/static/js/7.abd03acd.chunk.js"
  },
  {
    "revision": "c4e1fbcbf29fa6a3ad2b",
    "url": "/static/js/8.a86afeba.chunk.js"
  },
  {
    "revision": "46a066d5622c344066e4",
    "url": "/static/js/9.e26fcb5e.chunk.js"
  },
  {
    "revision": "7ba9217498d13614894b",
    "url": "/static/js/main.140b1033.chunk.js"
  },
  {
    "revision": "ad2be3d583fcdbce7ba8",
    "url": "/static/js/runtime~main.f333941b.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  }
]);