self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "026baf6a116e1d507652a5688109971d",
    "url": "/index.html"
  },
  {
    "revision": "686bd251a8d81757bc68",
    "url": "/static/css/8.a5918c4c.chunk.css"
  },
  {
    "revision": "e9272025710306af6cd4",
    "url": "/static/css/main.7b743d50.chunk.css"
  },
  {
    "revision": "d7654199855e645eaba9",
    "url": "/static/js/0.90120346.chunk.js"
  },
  {
    "revision": "1d7fada68efb45e982cf",
    "url": "/static/js/1.f2555003.chunk.js"
  },
  {
    "revision": "2cb3cdd8bb8cac193299",
    "url": "/static/js/10.f41a6df8.chunk.js"
  },
  {
    "revision": "4917a13d140b0b0aae7c",
    "url": "/static/js/11.ca849ac0.chunk.js"
  },
  {
    "revision": "2244fc234672ce9c4c5a",
    "url": "/static/js/12.f723dc71.chunk.js"
  },
  {
    "revision": "599ff2ebd05326ce7a8f",
    "url": "/static/js/13.77a482ad.chunk.js"
  },
  {
    "revision": "5668625e25b8f191f0c1",
    "url": "/static/js/14.9e8b8a08.chunk.js"
  },
  {
    "revision": "04485bf2af9ad13a632f",
    "url": "/static/js/15.9e203fff.chunk.js"
  },
  {
    "revision": "330eb4acc01f06bd31a7",
    "url": "/static/js/2.b340e353.chunk.js"
  },
  {
    "revision": "0fdd342d5db1bbee74eb",
    "url": "/static/js/3.d2d79ee5.chunk.js"
  },
  {
    "revision": "16b30cd1d2eb6a86cd5c",
    "url": "/static/js/4.10060625.chunk.js"
  },
  {
    "revision": "98b38c5d5e7c24451cd4",
    "url": "/static/js/5.ddcdc521.chunk.js"
  },
  {
    "revision": "686bd251a8d81757bc68",
    "url": "/static/js/8.80ef4e14.chunk.js"
  },
  {
    "revision": "ee70a71a6f5b37611f34",
    "url": "/static/js/9.0d231fb4.chunk.js"
  },
  {
    "revision": "e9272025710306af6cd4",
    "url": "/static/js/main.bf78deea.chunk.js"
  },
  {
    "revision": "352b035e2698465ce899",
    "url": "/static/js/runtime~main.2e05b04c.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);