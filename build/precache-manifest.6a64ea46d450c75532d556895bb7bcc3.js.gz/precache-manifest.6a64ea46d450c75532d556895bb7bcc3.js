self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cae6f5f345103926c44e4bd16dfe5815",
    "url": "/index.html"
  },
  {
    "revision": "829259392c97406f038e",
    "url": "/static/css/7.adf2b809.chunk.css"
  },
  {
    "revision": "eed1ed19b859d99d8f51",
    "url": "/static/css/main.d839f206.chunk.css"
  },
  {
    "revision": "ce77efe3d119e5e767c9",
    "url": "/static/js/0.774c32c5.chunk.js"
  },
  {
    "revision": "5c02f130bb076b3901e7",
    "url": "/static/js/1.7e09646e.chunk.js"
  },
  {
    "revision": "9dfddb00401f8f4ab931",
    "url": "/static/js/10.1d1f8f95.chunk.js"
  },
  {
    "revision": "dfd0da992ecf4340df92",
    "url": "/static/js/2.18cc3b27.chunk.js"
  },
  {
    "revision": "e9d3678538ad71be46fe",
    "url": "/static/js/3.84c419ae.chunk.js"
  },
  {
    "revision": "c043a4de914c01f23b4b",
    "url": "/static/js/4.b704fe1b.chunk.js"
  },
  {
    "revision": "829259392c97406f038e",
    "url": "/static/js/7.58a87b94.chunk.js"
  },
  {
    "revision": "ef8dd5c156081c8d366d",
    "url": "/static/js/8.759daae0.chunk.js"
  },
  {
    "revision": "a3fde4d75e83505d3aac",
    "url": "/static/js/9.71876ae1.chunk.js"
  },
  {
    "revision": "eed1ed19b859d99d8f51",
    "url": "/static/js/main.fcf91869.chunk.js"
  },
  {
    "revision": "0f12a643225df5eebbd6",
    "url": "/static/js/runtime~main.00465f4c.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);