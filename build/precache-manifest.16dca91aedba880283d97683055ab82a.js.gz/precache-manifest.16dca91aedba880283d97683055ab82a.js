self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a1ac09a30c5ea52c20df336bf901f171",
    "url": "/index.html"
  },
  {
    "revision": "d8bb2c49d30d0b747beb",
    "url": "/static/css/9.9ba107ea.chunk.css"
  },
  {
    "revision": "2984443ef0612725e51c",
    "url": "/static/css/main.12a95e80.chunk.css"
  },
  {
    "revision": "12970299f1167cf90e63",
    "url": "/static/js/0.6d7ec622.chunk.js"
  },
  {
    "revision": "beb10cc7a18012f665ad",
    "url": "/static/js/1.4436d9e4.chunk.js"
  },
  {
    "revision": "a1c6a89d973ceec00408",
    "url": "/static/js/10.947bdb88.chunk.js"
  },
  {
    "revision": "1130ff040017e5f1d632",
    "url": "/static/js/11.9e722f9e.chunk.js"
  },
  {
    "revision": "45132a34431dbb011faa",
    "url": "/static/js/12.4848a021.chunk.js"
  },
  {
    "revision": "e26ca919deaa74828fb9",
    "url": "/static/js/13.92bec96c.chunk.js"
  },
  {
    "revision": "8f562247cf0507b257ee",
    "url": "/static/js/14.54dab791.chunk.js"
  },
  {
    "revision": "e7d77c8dde71b6f40008",
    "url": "/static/js/15.f46f5057.chunk.js"
  },
  {
    "revision": "3974426004deb14a2234",
    "url": "/static/js/16.36453dd1.chunk.js"
  },
  {
    "revision": "f8171db6bf65fb60bf57",
    "url": "/static/js/17.fa7995c9.chunk.js"
  },
  {
    "revision": "092e3f93378fdf472dc5",
    "url": "/static/js/18.a3bfbe00.chunk.js"
  },
  {
    "revision": "37784e2afda3bccffcbf",
    "url": "/static/js/19.760324f4.chunk.js"
  },
  {
    "revision": "61ef075de19b8bf12baf",
    "url": "/static/js/2.d490c07e.chunk.js"
  },
  {
    "revision": "f3d9ab5fc2cd439ce1f9",
    "url": "/static/js/20.a610b8f1.chunk.js"
  },
  {
    "revision": "4ee7aef6b9e15b2af559",
    "url": "/static/js/21.10f83dd7.chunk.js"
  },
  {
    "revision": "2ea561c625f3bf97ef4a",
    "url": "/static/js/22.03056126.chunk.js"
  },
  {
    "revision": "fa17a34a712282425539",
    "url": "/static/js/23.3e6010ed.chunk.js"
  },
  {
    "revision": "3c81d63ec3a3dd06a769",
    "url": "/static/js/24.6da0d909.chunk.js"
  },
  {
    "revision": "06c13b641f42a347544f",
    "url": "/static/js/25.7997d29b.chunk.js"
  },
  {
    "revision": "ce1c505db494a2b8eaa2",
    "url": "/static/js/3.b47ad5d6.chunk.js"
  },
  {
    "revision": "cf7b9fa1e73cf218c216",
    "url": "/static/js/4.b94275f1.chunk.js"
  },
  {
    "revision": "1acfa6a35aea73ec8711",
    "url": "/static/js/5.d4f31368.chunk.js"
  },
  {
    "revision": "07d3527cd3cbae283b94",
    "url": "/static/js/6.b2cfa32f.chunk.js"
  },
  {
    "revision": "d8bb2c49d30d0b747beb",
    "url": "/static/js/9.18fa6468.chunk.js"
  },
  {
    "revision": "2984443ef0612725e51c",
    "url": "/static/js/main.698cbc73.chunk.js"
  },
  {
    "revision": "f2908fa4f4da0610c0c2",
    "url": "/static/js/runtime~main.d8e2888c.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);