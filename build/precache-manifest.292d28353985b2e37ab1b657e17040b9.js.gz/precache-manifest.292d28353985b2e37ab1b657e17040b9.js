self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8dccb7c5177fb13b5ccc1eb96f9c7633",
    "url": "/index.html"
  },
  {
    "revision": "8d5941931699536ce1e2",
    "url": "/static/css/15.b7b9ac92.chunk.css"
  },
  {
    "revision": "d78d020412b9c11e36f5",
    "url": "/static/css/main.61cec1cb.chunk.css"
  },
  {
    "revision": "9f03c305bdb96b8658ed",
    "url": "/static/js/0.7dd5fbcb.chunk.js"
  },
  {
    "revision": "fd9e5963e983444dbf6a",
    "url": "/static/js/1.4c78680a.chunk.js"
  },
  {
    "revision": "6d33116b4659dce009d5",
    "url": "/static/js/10.4007cbda.chunk.js"
  },
  {
    "revision": "d4ee45f0d2c01603a459",
    "url": "/static/js/11.f94b1637.chunk.js"
  },
  {
    "revision": "2af00600bcafe3503880",
    "url": "/static/js/12.4d9b6d17.chunk.js"
  },
  {
    "revision": "8d5941931699536ce1e2",
    "url": "/static/js/15.74cb99ef.chunk.js"
  },
  {
    "revision": "183ea94292a17ddc6113",
    "url": "/static/js/16.29965e1d.chunk.js"
  },
  {
    "revision": "f3af70c2f9f879d35980",
    "url": "/static/js/17.9b1f63d8.chunk.js"
  },
  {
    "revision": "81ef68b9ee1eab93d7ea",
    "url": "/static/js/18.66e4ed70.chunk.js"
  },
  {
    "revision": "cd4157c46cc263de930b",
    "url": "/static/js/19.1ff0b3ac.chunk.js"
  },
  {
    "revision": "dbd17728c51c10d13fdc",
    "url": "/static/js/2.49117c59.chunk.js"
  },
  {
    "revision": "5c797f370a231563f4a2",
    "url": "/static/js/20.68686949.chunk.js"
  },
  {
    "revision": "9c5f1c3141f4779b2835",
    "url": "/static/js/21.5ef3a944.chunk.js"
  },
  {
    "revision": "08a7afbc5db46c298ce9",
    "url": "/static/js/22.0121bab5.chunk.js"
  },
  {
    "revision": "5054af49dbd3a909774c",
    "url": "/static/js/23.0f53fe1a.chunk.js"
  },
  {
    "revision": "b8c09795db3e67f4be75",
    "url": "/static/js/24.bb5c7f6a.chunk.js"
  },
  {
    "revision": "9d7e4364f7acc3ff8d65",
    "url": "/static/js/25.741c4890.chunk.js"
  },
  {
    "revision": "64456d52067822de9856",
    "url": "/static/js/26.758d8907.chunk.js"
  },
  {
    "revision": "d6f83c88a882938f70c3",
    "url": "/static/js/27.f1d7bf27.chunk.js"
  },
  {
    "revision": "590b3df288f6bf7d4c28",
    "url": "/static/js/28.974b437e.chunk.js"
  },
  {
    "revision": "fe815f3b193c87791d8d",
    "url": "/static/js/29.c5deb1e3.chunk.js"
  },
  {
    "revision": "5029363827f498894da2",
    "url": "/static/js/3.953ca42d.chunk.js"
  },
  {
    "revision": "9feb8a760b4e0ccadcc4",
    "url": "/static/js/30.ab1986f2.chunk.js"
  },
  {
    "revision": "6272f4e1fee92e64f435",
    "url": "/static/js/31.40312fdf.chunk.js"
  },
  {
    "revision": "0159b10fba83185f77c0",
    "url": "/static/js/32.f33651ff.chunk.js"
  },
  {
    "revision": "400af5205e9ccb89a969",
    "url": "/static/js/33.c1d0b99a.chunk.js"
  },
  {
    "revision": "42161db2ba36dabd78ef",
    "url": "/static/js/34.e1982e98.chunk.js"
  },
  {
    "revision": "ce1aee2daa86780f4629",
    "url": "/static/js/35.2fba233e.chunk.js"
  },
  {
    "revision": "f3bdc5caba1b3e26c123",
    "url": "/static/js/36.88c5ec06.chunk.js"
  },
  {
    "revision": "49a2989e46d5a6acbef2",
    "url": "/static/js/37.be108233.chunk.js"
  },
  {
    "revision": "879ae23ff8d082b0c208",
    "url": "/static/js/38.a8021278.chunk.js"
  },
  {
    "revision": "fb93f6332fa3c9e65cf5",
    "url": "/static/js/39.f2cf8013.chunk.js"
  },
  {
    "revision": "96c42c49b9475459c739",
    "url": "/static/js/4.6e45ebff.chunk.js"
  },
  {
    "revision": "78b01461158a2f4ca431",
    "url": "/static/js/40.1831b03a.chunk.js"
  },
  {
    "revision": "7986aa27f584fd491170",
    "url": "/static/js/41.8c52f643.chunk.js"
  },
  {
    "revision": "0ffd61aed95a996a4393",
    "url": "/static/js/42.f086b165.chunk.js"
  },
  {
    "revision": "af6c5c8b8b41f1cba934",
    "url": "/static/js/43.dbffff47.chunk.js"
  },
  {
    "revision": "d1d9beb0e29aa7af0d8b",
    "url": "/static/js/44.848a1305.chunk.js"
  },
  {
    "revision": "518507ae5f27da09b83d",
    "url": "/static/js/45.e46ccab3.chunk.js"
  },
  {
    "revision": "57f4e197c0609f795d08",
    "url": "/static/js/46.b4d25af1.chunk.js"
  },
  {
    "revision": "83aa1b1316089f50af9a",
    "url": "/static/js/47.eab66e4c.chunk.js"
  },
  {
    "revision": "a7baa3a0992e34e44215",
    "url": "/static/js/48.255e1828.chunk.js"
  },
  {
    "revision": "d9dfe1e3b35e5ee1af79",
    "url": "/static/js/49.96842b2d.chunk.js"
  },
  {
    "revision": "d920cf9ea6f4f8aa7969",
    "url": "/static/js/5.23e22936.chunk.js"
  },
  {
    "revision": "8a8c648fea8dfeb249c8",
    "url": "/static/js/50.0bae6bd5.chunk.js"
  },
  {
    "revision": "ec19f154e03824561a36",
    "url": "/static/js/51.28bca7ac.chunk.js"
  },
  {
    "revision": "b6176f69d3e585f08dcb",
    "url": "/static/js/52.e31a6a1a.chunk.js"
  },
  {
    "revision": "c06888ed60ec7a2c81d7",
    "url": "/static/js/53.abfa9449.chunk.js"
  },
  {
    "revision": "d16d198ef747407d5557",
    "url": "/static/js/54.94df83e5.chunk.js"
  },
  {
    "revision": "7814538525e70946e50e",
    "url": "/static/js/55.93936e1a.chunk.js"
  },
  {
    "revision": "5509b651a224a71db8d2",
    "url": "/static/js/56.00426200.chunk.js"
  },
  {
    "revision": "77d1b22aa2dc3e8150b3",
    "url": "/static/js/57.aa4ad730.chunk.js"
  },
  {
    "revision": "f203fbf67b715686b076",
    "url": "/static/js/58.0e51a26b.chunk.js"
  },
  {
    "revision": "736b93f8528f19ad1455",
    "url": "/static/js/59.2f7910e4.chunk.js"
  },
  {
    "revision": "15ef6403605ad942a76c",
    "url": "/static/js/6.e7b2f0b6.chunk.js"
  },
  {
    "revision": "06534f7b9d01af295f09",
    "url": "/static/js/60.b229ec39.chunk.js"
  },
  {
    "revision": "629774ad56ed68471e35",
    "url": "/static/js/61.d7e8159b.chunk.js"
  },
  {
    "revision": "0d6518eb62593ef49888",
    "url": "/static/js/62.d6989fd6.chunk.js"
  },
  {
    "revision": "02e8dc73a5775f56b603",
    "url": "/static/js/63.a9d9907c.chunk.js"
  },
  {
    "revision": "e5bb529266d444d1083c",
    "url": "/static/js/7.ef81fb11.chunk.js"
  },
  {
    "revision": "0a5455ac79a040d8949c",
    "url": "/static/js/8.820fe78a.chunk.js"
  },
  {
    "revision": "fe43d84f3e71f5e4c5f8",
    "url": "/static/js/9.a437d890.chunk.js"
  },
  {
    "revision": "d78d020412b9c11e36f5",
    "url": "/static/js/main.db7a80ff.chunk.js"
  },
  {
    "revision": "5ab85e6c414d6abba22b",
    "url": "/static/js/runtime~main.e4d5904f.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);