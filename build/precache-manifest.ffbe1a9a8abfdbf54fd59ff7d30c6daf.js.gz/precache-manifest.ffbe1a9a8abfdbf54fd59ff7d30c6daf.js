self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "55924a9619fcd93875a433186af861b6",
    "url": "/index.html"
  },
  {
    "revision": "8c6449998ff265162c9d",
    "url": "/static/css/9.ad9926b6.chunk.css"
  },
  {
    "revision": "ef768c29d5134a71173a",
    "url": "/static/css/main.35623766.chunk.css"
  },
  {
    "revision": "4c11c1c8c120b01d2a5b",
    "url": "/static/js/0.db8cf1bb.chunk.js"
  },
  {
    "revision": "6be9e546d9a01b71e5e4",
    "url": "/static/js/1.30b69af6.chunk.js"
  },
  {
    "revision": "85d825cc11e1769529c7",
    "url": "/static/js/10.fed08fbd.chunk.js"
  },
  {
    "revision": "aac4b17654e84ef779f0",
    "url": "/static/js/11.0c43c9f0.chunk.js"
  },
  {
    "revision": "f782573dd7f70c805fc6",
    "url": "/static/js/12.8c964e12.chunk.js"
  },
  {
    "revision": "80320816592641a68cf5",
    "url": "/static/js/13.33bcf7ad.chunk.js"
  },
  {
    "revision": "889f1699293745ec3b3a",
    "url": "/static/js/14.9b4d641d.chunk.js"
  },
  {
    "revision": "d69252225b5ab891719f",
    "url": "/static/js/15.1fa86919.chunk.js"
  },
  {
    "revision": "c87dfcaba0098114df59",
    "url": "/static/js/16.b2b411ab.chunk.js"
  },
  {
    "revision": "86db6d8fa6abcdf67c8d",
    "url": "/static/js/17.c7951563.chunk.js"
  },
  {
    "revision": "2e84be75e690fc96fced",
    "url": "/static/js/2.90e347f8.chunk.js"
  },
  {
    "revision": "3f556459d0ab085a4ab4",
    "url": "/static/js/3.602b84d2.chunk.js"
  },
  {
    "revision": "668be5d026983eb63f85",
    "url": "/static/js/4.8a036ab7.chunk.js"
  },
  {
    "revision": "3c88d908f11f68349bfe",
    "url": "/static/js/5.69560fa4.chunk.js"
  },
  {
    "revision": "91c2b44885c4f2ce4e99",
    "url": "/static/js/6.f3f4e9fc.chunk.js"
  },
  {
    "revision": "8c6449998ff265162c9d",
    "url": "/static/js/9.a534bda7.chunk.js"
  },
  {
    "revision": "ef768c29d5134a71173a",
    "url": "/static/js/main.7f9591a1.chunk.js"
  },
  {
    "revision": "a7faafe0ca60d6bf9152",
    "url": "/static/js/runtime~main.1416df06.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);