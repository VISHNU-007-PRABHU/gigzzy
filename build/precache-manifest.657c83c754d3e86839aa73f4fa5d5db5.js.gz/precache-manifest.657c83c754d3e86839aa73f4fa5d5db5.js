self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "75f6b98d8fb87c0aff7c214bf2e6edd6",
    "url": "/index.html"
  },
  {
    "revision": "591bbcde3df47d382be4",
    "url": "/static/css/16.3e70be20.chunk.css"
  },
  {
    "revision": "f6275e753d8b586bcde0",
    "url": "/static/css/main.495501b5.chunk.css"
  },
  {
    "revision": "56b13e2b3070bac572be",
    "url": "/static/js/0.fc05d22d.chunk.js"
  },
  {
    "revision": "cf1a52b164543109c699",
    "url": "/static/js/1.87fbb9fa.chunk.js"
  },
  {
    "revision": "b1606e5622ff40c95db1",
    "url": "/static/js/10.6e137d83.chunk.js"
  },
  {
    "revision": "87bc95dbf28ef9536663",
    "url": "/static/js/11.01db65aa.chunk.js"
  },
  {
    "revision": "564ad96fedb0af36f874",
    "url": "/static/js/12.20406267.chunk.js"
  },
  {
    "revision": "f2738c33eb5efbfa0727",
    "url": "/static/js/13.dedb10e6.chunk.js"
  },
  {
    "revision": "591bbcde3df47d382be4",
    "url": "/static/js/16.006a4402.chunk.js"
  },
  {
    "revision": "f6ff21e899f91a849101",
    "url": "/static/js/17.7a0e4324.chunk.js"
  },
  {
    "revision": "c9b4449e37174e35f8f5",
    "url": "/static/js/18.536a13b4.chunk.js"
  },
  {
    "revision": "cd4157c46cc263de930b",
    "url": "/static/js/19.1ff0b3ac.chunk.js"
  },
  {
    "revision": "9f208430d21dc2fed2e1",
    "url": "/static/js/2.142c168d.chunk.js"
  },
  {
    "revision": "b0a57960951896c4180e",
    "url": "/static/js/20.ae1cb4c1.chunk.js"
  },
  {
    "revision": "a86d1f859e6748c3a225",
    "url": "/static/js/21.ab3a7f65.chunk.js"
  },
  {
    "revision": "62cf24657cfb11497219",
    "url": "/static/js/22.1b9dee87.chunk.js"
  },
  {
    "revision": "d9945304d6c19c851537",
    "url": "/static/js/23.2bae4129.chunk.js"
  },
  {
    "revision": "7cb3e5a80aaa6c3c5445",
    "url": "/static/js/24.d93f7d53.chunk.js"
  },
  {
    "revision": "c38b6a8868b1bc7003bb",
    "url": "/static/js/25.3c816757.chunk.js"
  },
  {
    "revision": "8412489ca438af656ec8",
    "url": "/static/js/26.809ab5eb.chunk.js"
  },
  {
    "revision": "210b513c2de615082f01",
    "url": "/static/js/27.1fc8918a.chunk.js"
  },
  {
    "revision": "f73716b6f328fa362dbd",
    "url": "/static/js/28.990135c8.chunk.js"
  },
  {
    "revision": "8bc8ea71b9468bcbe6c7",
    "url": "/static/js/29.74b276a9.chunk.js"
  },
  {
    "revision": "f7dfedc6e5a8bf464976",
    "url": "/static/js/3.3866aa9d.chunk.js"
  },
  {
    "revision": "5a6ba19f0b863e189934",
    "url": "/static/js/30.827e9b2b.chunk.js"
  },
  {
    "revision": "064b5a5cf630b6e79796",
    "url": "/static/js/31.53df53c6.chunk.js"
  },
  {
    "revision": "e288d3ba8d923eb43367",
    "url": "/static/js/32.9d3411c8.chunk.js"
  },
  {
    "revision": "20ae611f10cc494a6d03",
    "url": "/static/js/33.dc1aa999.chunk.js"
  },
  {
    "revision": "bd469a56f84e1622a69d",
    "url": "/static/js/34.4478bf8c.chunk.js"
  },
  {
    "revision": "642ce7f8414b39e9f320",
    "url": "/static/js/35.bda02cb6.chunk.js"
  },
  {
    "revision": "6d8aaf0a07ff36391175",
    "url": "/static/js/36.cf89f2a3.chunk.js"
  },
  {
    "revision": "bdd1d8ad0b13f44b273e",
    "url": "/static/js/37.7c413176.chunk.js"
  },
  {
    "revision": "305a5c13ef61b66c88ee",
    "url": "/static/js/38.7277731c.chunk.js"
  },
  {
    "revision": "ae9f40e621eca3f12b3c",
    "url": "/static/js/39.eadafa26.chunk.js"
  },
  {
    "revision": "762baf732494c001b84d",
    "url": "/static/js/4.3fd8457f.chunk.js"
  },
  {
    "revision": "4b953ed8792c4a9411e8",
    "url": "/static/js/40.29d92b7d.chunk.js"
  },
  {
    "revision": "8f90b7ffde4cd778916d",
    "url": "/static/js/41.6339ab1c.chunk.js"
  },
  {
    "revision": "83a5a08e8f32fc4532af",
    "url": "/static/js/42.cccb3531.chunk.js"
  },
  {
    "revision": "03b225d058295546e766",
    "url": "/static/js/43.71f580ed.chunk.js"
  },
  {
    "revision": "c41a14a674d0730cc975",
    "url": "/static/js/44.9317bb26.chunk.js"
  },
  {
    "revision": "ddb1d1643e71ee5230b1",
    "url": "/static/js/45.2b21c6c6.chunk.js"
  },
  {
    "revision": "649ab1466a2094999813",
    "url": "/static/js/46.74f0b3b2.chunk.js"
  },
  {
    "revision": "865ada3584da582ef5ef",
    "url": "/static/js/47.1fc7ac69.chunk.js"
  },
  {
    "revision": "d31f40ac6beee69863f0",
    "url": "/static/js/48.f6220efe.chunk.js"
  },
  {
    "revision": "1d6be960cc36f18bbcb5",
    "url": "/static/js/49.00ac2fae.chunk.js"
  },
  {
    "revision": "e47acfce5e82084ad52b",
    "url": "/static/js/5.a9d7e83b.chunk.js"
  },
  {
    "revision": "2f4596d3ab4c9eaab381",
    "url": "/static/js/50.e546a884.chunk.js"
  },
  {
    "revision": "32c5f11c6d46d01da471",
    "url": "/static/js/51.0b72fb1a.chunk.js"
  },
  {
    "revision": "41b755ad85d7eedc158b",
    "url": "/static/js/52.23f14816.chunk.js"
  },
  {
    "revision": "f4a67e3ccb74d4a368f7",
    "url": "/static/js/53.778a9215.chunk.js"
  },
  {
    "revision": "edd87cd5fc76d2de76bb",
    "url": "/static/js/54.3a6bd4ea.chunk.js"
  },
  {
    "revision": "1a90c7d155a6fa2c7858",
    "url": "/static/js/55.14cf590c.chunk.js"
  },
  {
    "revision": "9f93179190aef3afd61f",
    "url": "/static/js/56.d8c5d067.chunk.js"
  },
  {
    "revision": "f45ed23405e15b7a1be9",
    "url": "/static/js/57.14bf23e4.chunk.js"
  },
  {
    "revision": "2a4b9d55182bcf7136ea",
    "url": "/static/js/58.9b9304a8.chunk.js"
  },
  {
    "revision": "7e06a5a06a299fe5ce34",
    "url": "/static/js/59.5d31364a.chunk.js"
  },
  {
    "revision": "748d82092fbdfe08e962",
    "url": "/static/js/6.955c16c3.chunk.js"
  },
  {
    "revision": "4c7d1e7d09c2e6c3a3e8",
    "url": "/static/js/60.7a413967.chunk.js"
  },
  {
    "revision": "9a12be997919ccfb34e9",
    "url": "/static/js/61.5f4d3de6.chunk.js"
  },
  {
    "revision": "971edba79854ad99b2a1",
    "url": "/static/js/62.e3c778aa.chunk.js"
  },
  {
    "revision": "c245ff0e8256c04acf9d",
    "url": "/static/js/63.e602a4ad.chunk.js"
  },
  {
    "revision": "f6e4e6c64ccf8b504356",
    "url": "/static/js/7.686e2935.chunk.js"
  },
  {
    "revision": "dff1ea6a459aa4361f24",
    "url": "/static/js/8.285c0053.chunk.js"
  },
  {
    "revision": "0458cd315f47ea0f817a",
    "url": "/static/js/9.a9f626b0.chunk.js"
  },
  {
    "revision": "f6275e753d8b586bcde0",
    "url": "/static/js/main.4fb11a7e.chunk.js"
  },
  {
    "revision": "24ff0b74205d80bf6c42",
    "url": "/static/js/runtime~main.a84d06f3.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);