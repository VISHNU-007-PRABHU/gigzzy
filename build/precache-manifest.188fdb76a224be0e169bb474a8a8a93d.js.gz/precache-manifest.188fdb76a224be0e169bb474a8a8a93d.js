self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8977af007e517310e908aca3812669cb",
    "url": "/index.html"
  },
  {
    "revision": "091f438a648bc015d92c",
    "url": "/static/css/16.61bc2927.chunk.css"
  },
  {
    "revision": "e8e0590e09adc27b2947",
    "url": "/static/css/main.305c61e6.chunk.css"
  },
  {
    "revision": "d99b12778f0fcf2f6add",
    "url": "/static/js/0.a4efcbf3.chunk.js"
  },
  {
    "revision": "e9ee356ab954e200dbf2",
    "url": "/static/js/1.fd2b1d94.chunk.js"
  },
  {
    "revision": "f9cc1b8e4324e0aad81a",
    "url": "/static/js/10.86aa10b7.chunk.js"
  },
  {
    "revision": "e0eaf58bb4040f77bbdf",
    "url": "/static/js/11.1a48896e.chunk.js"
  },
  {
    "revision": "60d87d0f135cd4343598",
    "url": "/static/js/12.3eed8354.chunk.js"
  },
  {
    "revision": "406a2d98f1836953442c",
    "url": "/static/js/13.c8997b6a.chunk.js"
  },
  {
    "revision": "091f438a648bc015d92c",
    "url": "/static/js/16.2bc3817e.chunk.js"
  },
  {
    "revision": "539fc773554db5cb09c3",
    "url": "/static/js/17.b9321be2.chunk.js"
  },
  {
    "revision": "f52c4e5806eeb1b6f152",
    "url": "/static/js/18.55b739c6.chunk.js"
  },
  {
    "revision": "cd4157c46cc263de930b",
    "url": "/static/js/19.1ff0b3ac.chunk.js"
  },
  {
    "revision": "63d13e11735aa025105e",
    "url": "/static/js/2.d93291dc.chunk.js"
  },
  {
    "revision": "9c9e3058f81ebf49bf0b",
    "url": "/static/js/20.13f701f3.chunk.js"
  },
  {
    "revision": "e3d6886ad3d3fddcfde1",
    "url": "/static/js/21.7cfa5a24.chunk.js"
  },
  {
    "revision": "f90d6430279ae5a247fe",
    "url": "/static/js/22.a582c416.chunk.js"
  },
  {
    "revision": "a19776b91fe34086e300",
    "url": "/static/js/23.c61eec98.chunk.js"
  },
  {
    "revision": "a0708214bd0168a131f6",
    "url": "/static/js/24.838dd965.chunk.js"
  },
  {
    "revision": "f55db946d5e410a35d01",
    "url": "/static/js/25.1056b29a.chunk.js"
  },
  {
    "revision": "458034c361623a078111",
    "url": "/static/js/26.d0a4f60e.chunk.js"
  },
  {
    "revision": "1d06f12ee107ed11d871",
    "url": "/static/js/27.d6b21025.chunk.js"
  },
  {
    "revision": "ae5564a36ffbc273b1a2",
    "url": "/static/js/28.fccded08.chunk.js"
  },
  {
    "revision": "0bb45a1b103cae6146a0",
    "url": "/static/js/29.91771b40.chunk.js"
  },
  {
    "revision": "5029363827f498894da2",
    "url": "/static/js/3.953ca42d.chunk.js"
  },
  {
    "revision": "645cfaeadf2d823df57b",
    "url": "/static/js/30.56523302.chunk.js"
  },
  {
    "revision": "9f77906102068b69ec7a",
    "url": "/static/js/31.0fb30cc0.chunk.js"
  },
  {
    "revision": "1b8dc875d6b867125428",
    "url": "/static/js/32.2877737b.chunk.js"
  },
  {
    "revision": "c6d060cf5c97b7e22266",
    "url": "/static/js/33.53991386.chunk.js"
  },
  {
    "revision": "5e7f8f16f377b408d43b",
    "url": "/static/js/34.338a52c2.chunk.js"
  },
  {
    "revision": "ec0efdd58b18e77ddcc5",
    "url": "/static/js/35.1e503296.chunk.js"
  },
  {
    "revision": "d4b1a116211ec43f3068",
    "url": "/static/js/36.b6d0e35e.chunk.js"
  },
  {
    "revision": "49a2989e46d5a6acbef2",
    "url": "/static/js/37.be108233.chunk.js"
  },
  {
    "revision": "2466535e75ae32bfe5b8",
    "url": "/static/js/38.ae0a6189.chunk.js"
  },
  {
    "revision": "fb93f6332fa3c9e65cf5",
    "url": "/static/js/39.f2cf8013.chunk.js"
  },
  {
    "revision": "96c42c49b9475459c739",
    "url": "/static/js/4.6e45ebff.chunk.js"
  },
  {
    "revision": "7dbec6e25d1d9be51163",
    "url": "/static/js/40.4ce74019.chunk.js"
  },
  {
    "revision": "96cdc2716ae564e28468",
    "url": "/static/js/41.7ac0e30c.chunk.js"
  },
  {
    "revision": "01331e1ab60ecb3048d0",
    "url": "/static/js/42.5aefdeca.chunk.js"
  },
  {
    "revision": "93886f653db96baa94a1",
    "url": "/static/js/43.02009e2f.chunk.js"
  },
  {
    "revision": "63861aee148364324473",
    "url": "/static/js/44.d102db8b.chunk.js"
  },
  {
    "revision": "98e17008a6b21e4f7f18",
    "url": "/static/js/45.6964af1e.chunk.js"
  },
  {
    "revision": "6986ac9b686d002dfd5d",
    "url": "/static/js/46.3ba204ac.chunk.js"
  },
  {
    "revision": "83aa1b1316089f50af9a",
    "url": "/static/js/47.eab66e4c.chunk.js"
  },
  {
    "revision": "cb67d32806892462b464",
    "url": "/static/js/48.3551985f.chunk.js"
  },
  {
    "revision": "0dcf0ea2bec701324bbe",
    "url": "/static/js/49.8a041e4e.chunk.js"
  },
  {
    "revision": "8c69b53eb306c4ddf991",
    "url": "/static/js/5.289782bb.chunk.js"
  },
  {
    "revision": "8a8c648fea8dfeb249c8",
    "url": "/static/js/50.0bae6bd5.chunk.js"
  },
  {
    "revision": "395638cfa287b6b3b35d",
    "url": "/static/js/51.3e8ad5a2.chunk.js"
  },
  {
    "revision": "8ac3fa9677cf640821c3",
    "url": "/static/js/52.a4a2521c.chunk.js"
  },
  {
    "revision": "5f8ccb03434dc3ea3322",
    "url": "/static/js/53.bf1cb8e0.chunk.js"
  },
  {
    "revision": "ac6d397df2c19680ec01",
    "url": "/static/js/54.7d3a828f.chunk.js"
  },
  {
    "revision": "541609df91bcc83fccfe",
    "url": "/static/js/55.0399a38e.chunk.js"
  },
  {
    "revision": "b109990afe3173bd0deb",
    "url": "/static/js/56.239e178d.chunk.js"
  },
  {
    "revision": "26076531adddc92208bb",
    "url": "/static/js/57.24c57291.chunk.js"
  },
  {
    "revision": "2d0ea01e78f045c9eb4f",
    "url": "/static/js/58.3600ebf3.chunk.js"
  },
  {
    "revision": "0a882e3a58d24f240409",
    "url": "/static/js/59.3908f6ea.chunk.js"
  },
  {
    "revision": "4b563f394f2dca036354",
    "url": "/static/js/6.dc4c8584.chunk.js"
  },
  {
    "revision": "1b8da3833f34a9119adf",
    "url": "/static/js/60.ddd315b2.chunk.js"
  },
  {
    "revision": "333f88a88dce20a04414",
    "url": "/static/js/61.738c0376.chunk.js"
  },
  {
    "revision": "957e27c12bf9be096e8c",
    "url": "/static/js/62.8815345b.chunk.js"
  },
  {
    "revision": "c92d43b9b53296320a1c",
    "url": "/static/js/63.4469dbeb.chunk.js"
  },
  {
    "revision": "e9a93d77edccde6ae173",
    "url": "/static/js/7.4b6c18fa.chunk.js"
  },
  {
    "revision": "ce790250a8a64d25dbfe",
    "url": "/static/js/8.36fc8c48.chunk.js"
  },
  {
    "revision": "37d9464dbcf89de3dc18",
    "url": "/static/js/9.b34375c6.chunk.js"
  },
  {
    "revision": "e8e0590e09adc27b2947",
    "url": "/static/js/main.c98855b6.chunk.js"
  },
  {
    "revision": "0affe6e4e91649863250",
    "url": "/static/js/runtime~main.be9e0aa3.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);