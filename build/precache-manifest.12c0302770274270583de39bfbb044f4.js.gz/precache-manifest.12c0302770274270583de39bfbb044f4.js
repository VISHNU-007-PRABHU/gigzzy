self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a1ea102f5d14af4c3b8259cd454aa562",
    "url": "/index.html"
  },
  {
    "revision": "781faa82ded718b0ae68",
    "url": "/static/css/16.3e70be20.chunk.css"
  },
  {
    "revision": "a8e4a86bbf7fae4f2be9",
    "url": "/static/css/main.15347f04.chunk.css"
  },
  {
    "revision": "56b13e2b3070bac572be",
    "url": "/static/js/0.fc05d22d.chunk.js"
  },
  {
    "revision": "eb2337f89996240f982b",
    "url": "/static/js/1.518c047b.chunk.js"
  },
  {
    "revision": "53c24a3ceb4fb9c5dafe",
    "url": "/static/js/10.20151c92.chunk.js"
  },
  {
    "revision": "e0eaf58bb4040f77bbdf",
    "url": "/static/js/11.1a48896e.chunk.js"
  },
  {
    "revision": "60d87d0f135cd4343598",
    "url": "/static/js/12.3eed8354.chunk.js"
  },
  {
    "revision": "406a2d98f1836953442c",
    "url": "/static/js/13.c8997b6a.chunk.js"
  },
  {
    "revision": "781faa82ded718b0ae68",
    "url": "/static/js/16.dc967438.chunk.js"
  },
  {
    "revision": "ba1ac5e9a0457e407863",
    "url": "/static/js/17.d270de8c.chunk.js"
  },
  {
    "revision": "9fbd072eb56800c25c08",
    "url": "/static/js/18.f61964c8.chunk.js"
  },
  {
    "revision": "cd4157c46cc263de930b",
    "url": "/static/js/19.1ff0b3ac.chunk.js"
  },
  {
    "revision": "6b4297cdf89c05d20c88",
    "url": "/static/js/2.e46e1b8d.chunk.js"
  },
  {
    "revision": "393eda137ce0750b9f5a",
    "url": "/static/js/20.412adc5d.chunk.js"
  },
  {
    "revision": "a86d1f859e6748c3a225",
    "url": "/static/js/21.ab3a7f65.chunk.js"
  },
  {
    "revision": "841c402060c68e477aec",
    "url": "/static/js/22.8a0fd458.chunk.js"
  },
  {
    "revision": "a629b2973e0c4a55b609",
    "url": "/static/js/23.60be12ac.chunk.js"
  },
  {
    "revision": "f58992014f985c802256",
    "url": "/static/js/24.ac1b3d32.chunk.js"
  },
  {
    "revision": "b7c6c929b6a392e8783a",
    "url": "/static/js/25.dfc563af.chunk.js"
  },
  {
    "revision": "8412489ca438af656ec8",
    "url": "/static/js/26.809ab5eb.chunk.js"
  },
  {
    "revision": "b77513fc531dc24a0938",
    "url": "/static/js/27.a919a02c.chunk.js"
  },
  {
    "revision": "f73716b6f328fa362dbd",
    "url": "/static/js/28.990135c8.chunk.js"
  },
  {
    "revision": "8bc8ea71b9468bcbe6c7",
    "url": "/static/js/29.74b276a9.chunk.js"
  },
  {
    "revision": "5029363827f498894da2",
    "url": "/static/js/3.953ca42d.chunk.js"
  },
  {
    "revision": "96aa53128cf3a2fe6557",
    "url": "/static/js/30.6e25794b.chunk.js"
  },
  {
    "revision": "d53388f2bd14424742f6",
    "url": "/static/js/31.958110dc.chunk.js"
  },
  {
    "revision": "0c7898d346efb61e3eb9",
    "url": "/static/js/32.6280eb1e.chunk.js"
  },
  {
    "revision": "20ae611f10cc494a6d03",
    "url": "/static/js/33.dc1aa999.chunk.js"
  },
  {
    "revision": "bd469a56f84e1622a69d",
    "url": "/static/js/34.4478bf8c.chunk.js"
  },
  {
    "revision": "f2f6929b7337d35a97f6",
    "url": "/static/js/35.c85470dd.chunk.js"
  },
  {
    "revision": "f149ae79220b23058329",
    "url": "/static/js/36.bf1a7518.chunk.js"
  },
  {
    "revision": "bdd1d8ad0b13f44b273e",
    "url": "/static/js/37.7c413176.chunk.js"
  },
  {
    "revision": "305a5c13ef61b66c88ee",
    "url": "/static/js/38.7277731c.chunk.js"
  },
  {
    "revision": "a54950debf1491b7c581",
    "url": "/static/js/39.5d687d72.chunk.js"
  },
  {
    "revision": "762baf732494c001b84d",
    "url": "/static/js/4.3fd8457f.chunk.js"
  },
  {
    "revision": "c005f2d4aac14608f604",
    "url": "/static/js/40.7aaabd1b.chunk.js"
  },
  {
    "revision": "b1560b36a5cd058657f1",
    "url": "/static/js/41.4f5a0101.chunk.js"
  },
  {
    "revision": "6cfedbd548647b148d9d",
    "url": "/static/js/42.e66a8a8e.chunk.js"
  },
  {
    "revision": "03b225d058295546e766",
    "url": "/static/js/43.71f580ed.chunk.js"
  },
  {
    "revision": "c41a14a674d0730cc975",
    "url": "/static/js/44.9317bb26.chunk.js"
  },
  {
    "revision": "ddb1d1643e71ee5230b1",
    "url": "/static/js/45.2b21c6c6.chunk.js"
  },
  {
    "revision": "649ab1466a2094999813",
    "url": "/static/js/46.74f0b3b2.chunk.js"
  },
  {
    "revision": "03ed0cc303edc7af0cbf",
    "url": "/static/js/47.ba7a509c.chunk.js"
  },
  {
    "revision": "d31f40ac6beee69863f0",
    "url": "/static/js/48.f6220efe.chunk.js"
  },
  {
    "revision": "1d6be960cc36f18bbcb5",
    "url": "/static/js/49.00ac2fae.chunk.js"
  },
  {
    "revision": "95382a55748cc2045df3",
    "url": "/static/js/5.78403c5d.chunk.js"
  },
  {
    "revision": "2f4596d3ab4c9eaab381",
    "url": "/static/js/50.e546a884.chunk.js"
  },
  {
    "revision": "c71bcafa50c1a89ef838",
    "url": "/static/js/51.c49f376e.chunk.js"
  },
  {
    "revision": "2ba89c1ce1d5075a1593",
    "url": "/static/js/52.e2626d68.chunk.js"
  },
  {
    "revision": "9562d4a85001370127b3",
    "url": "/static/js/53.55ef4013.chunk.js"
  },
  {
    "revision": "edd87cd5fc76d2de76bb",
    "url": "/static/js/54.3a6bd4ea.chunk.js"
  },
  {
    "revision": "1a90c7d155a6fa2c7858",
    "url": "/static/js/55.14cf590c.chunk.js"
  },
  {
    "revision": "9f93179190aef3afd61f",
    "url": "/static/js/56.d8c5d067.chunk.js"
  },
  {
    "revision": "f45ed23405e15b7a1be9",
    "url": "/static/js/57.14bf23e4.chunk.js"
  },
  {
    "revision": "2a4b9d55182bcf7136ea",
    "url": "/static/js/58.9b9304a8.chunk.js"
  },
  {
    "revision": "7e06a5a06a299fe5ce34",
    "url": "/static/js/59.5d31364a.chunk.js"
  },
  {
    "revision": "e456c28799669ac3ba66",
    "url": "/static/js/6.61f5af10.chunk.js"
  },
  {
    "revision": "315b33e3f2da7279ec34",
    "url": "/static/js/60.faa8c840.chunk.js"
  },
  {
    "revision": "9a12be997919ccfb34e9",
    "url": "/static/js/61.5f4d3de6.chunk.js"
  },
  {
    "revision": "273c14f2f5a6b5d0d91e",
    "url": "/static/js/62.38469964.chunk.js"
  },
  {
    "revision": "eab5a1b90a8f60274331",
    "url": "/static/js/63.a9385ec5.chunk.js"
  },
  {
    "revision": "e041571e2346812569d9",
    "url": "/static/js/7.dea38d12.chunk.js"
  },
  {
    "revision": "e999e7b5706cc27b33a8",
    "url": "/static/js/8.d86e4eb4.chunk.js"
  },
  {
    "revision": "d3a5d7d9754d8740fdd8",
    "url": "/static/js/9.1dc04f6a.chunk.js"
  },
  {
    "revision": "a8e4a86bbf7fae4f2be9",
    "url": "/static/js/main.7d806333.chunk.js"
  },
  {
    "revision": "d5f8b143b60f8b807602",
    "url": "/static/js/runtime~main.98be903b.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);