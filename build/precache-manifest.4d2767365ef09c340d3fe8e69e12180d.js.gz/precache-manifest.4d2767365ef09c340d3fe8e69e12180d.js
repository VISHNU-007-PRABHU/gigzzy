self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "32c8dafcd3e51c3d410a2293d9bbb699",
    "url": "/index.html"
  },
  {
    "revision": "e355780893057b995072",
    "url": "/static/css/8.cf96be87.chunk.css"
  },
  {
    "revision": "e9c959f3657212554464",
    "url": "/static/css/main.7b743d50.chunk.css"
  },
  {
    "revision": "6400af0601ae231bc11e",
    "url": "/static/js/0.7f3072ca.chunk.js"
  },
  {
    "revision": "5a51211e61ee2e188099",
    "url": "/static/js/1.659d825c.chunk.js"
  },
  {
    "revision": "0141af1e704341fec303",
    "url": "/static/js/10.3c96d94b.chunk.js"
  },
  {
    "revision": "5eaa362482ff3eb9df96",
    "url": "/static/js/11.9c1b0975.chunk.js"
  },
  {
    "revision": "9db9f71696d20317d9e7",
    "url": "/static/js/12.59bcaa99.chunk.js"
  },
  {
    "revision": "2e2e6793612f270c02f3",
    "url": "/static/js/13.001b27ce.chunk.js"
  },
  {
    "revision": "667ac04ed20c5f441ed3",
    "url": "/static/js/14.ffaacee3.chunk.js"
  },
  {
    "revision": "cdee1ce48aa381c8f14d",
    "url": "/static/js/15.3647191d.chunk.js"
  },
  {
    "revision": "feb12f839e76b7a90974",
    "url": "/static/js/2.1f645caf.chunk.js"
  },
  {
    "revision": "5809a743c84b8fceb7f6",
    "url": "/static/js/3.b5b3ae17.chunk.js"
  },
  {
    "revision": "9d1d8860b4d44da641cf",
    "url": "/static/js/4.5c16e0f1.chunk.js"
  },
  {
    "revision": "5b628a568fd602a431bb",
    "url": "/static/js/5.81d7864c.chunk.js"
  },
  {
    "revision": "e355780893057b995072",
    "url": "/static/js/8.8923849d.chunk.js"
  },
  {
    "revision": "ef613ed87d32389f1d95",
    "url": "/static/js/9.68d4994b.chunk.js"
  },
  {
    "revision": "e9c959f3657212554464",
    "url": "/static/js/main.aa00d67c.chunk.js"
  },
  {
    "revision": "61df3db99ca517e0dfe8",
    "url": "/static/js/runtime~main.ee902ede.js"
  },
  {
    "revision": "613b99694464c404c9acf4003083168e",
    "url": "/static/media/Gigzzy.613b9969.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "f24c9cae369f84c1553d9ec29c7cc9dc",
    "url": "/static/media/gigzzypro.f24c9cae.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);