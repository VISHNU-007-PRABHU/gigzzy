self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "49efd3ebf73fe1837cace1df85539855",
    "url": "/index.html"
  },
  {
    "revision": "7ceb1e88192586a30049",
    "url": "/static/css/11.051905ae.chunk.css"
  },
  {
    "revision": "e088e4f583bc6344ff31",
    "url": "/static/css/22.42816916.chunk.css"
  },
  {
    "revision": "2b7f94596eb847f402db",
    "url": "/static/css/23.52aaac88.chunk.css"
  },
  {
    "revision": "96b274718ed1e9963573",
    "url": "/static/css/24.051905ae.chunk.css"
  },
  {
    "revision": "eb1e8896ef4dc046af62",
    "url": "/static/css/25.051905ae.chunk.css"
  },
  {
    "revision": "21de92adea8be1d4887d",
    "url": "/static/css/26.051905ae.chunk.css"
  },
  {
    "revision": "f897de5f0f1c8e2f3089",
    "url": "/static/css/27.051905ae.chunk.css"
  },
  {
    "revision": "ce3524b30049d5c66a59",
    "url": "/static/css/28.cb85cd3b.chunk.css"
  },
  {
    "revision": "4ba9da92cb51bb030c4e",
    "url": "/static/css/29.051905ae.chunk.css"
  },
  {
    "revision": "f5b032b06a3560f4572a",
    "url": "/static/css/30.11000f17.chunk.css"
  },
  {
    "revision": "68365886938cd5c9e15c",
    "url": "/static/css/31.051905ae.chunk.css"
  },
  {
    "revision": "d3abf17f4c5055a3f09e",
    "url": "/static/css/32.051905ae.chunk.css"
  },
  {
    "revision": "179b050e3ea7ae0fa3e3",
    "url": "/static/css/33.11000f17.chunk.css"
  },
  {
    "revision": "e529a6b20f036ba4288c",
    "url": "/static/css/34.051905ae.chunk.css"
  },
  {
    "revision": "335e4d19c327eec1bdac",
    "url": "/static/css/35.051905ae.chunk.css"
  },
  {
    "revision": "abfdba5461eda74d1678",
    "url": "/static/css/36.051905ae.chunk.css"
  },
  {
    "revision": "00afa044d8568672f726",
    "url": "/static/css/37.051905ae.chunk.css"
  },
  {
    "revision": "ac8c206d65f1d4b49eb6",
    "url": "/static/css/38.96762d78.chunk.css"
  },
  {
    "revision": "8632f1e511c7e654b99b",
    "url": "/static/css/39.ad9a9a02.chunk.css"
  },
  {
    "revision": "9c72519936d7536c8329",
    "url": "/static/css/40.051905ae.chunk.css"
  },
  {
    "revision": "1506250c2e6009d704e2",
    "url": "/static/css/41.051905ae.chunk.css"
  },
  {
    "revision": "1aff967c8fcada848915",
    "url": "/static/css/42.051905ae.chunk.css"
  },
  {
    "revision": "97fc066a37d089856f3e",
    "url": "/static/css/43.96d493fd.chunk.css"
  },
  {
    "revision": "c9d51a47e6ef2478db0c",
    "url": "/static/css/44.051905ae.chunk.css"
  },
  {
    "revision": "5ba10784857f5534856d",
    "url": "/static/css/45.11000f17.chunk.css"
  },
  {
    "revision": "6ab223a4f2c5f606a0ae",
    "url": "/static/css/46.fb4a295e.chunk.css"
  },
  {
    "revision": "4bc0afa0268f1b1f2497",
    "url": "/static/css/47.9142c0f9.chunk.css"
  },
  {
    "revision": "3ab24ae1dd7bdb343e87",
    "url": "/static/css/48.82b1d2bb.chunk.css"
  },
  {
    "revision": "a7c06349bb01c24e4516",
    "url": "/static/css/49.42816916.chunk.css"
  },
  {
    "revision": "8a895e116e51695dc9f1",
    "url": "/static/css/50.42816916.chunk.css"
  },
  {
    "revision": "31304b283c1e2199811a",
    "url": "/static/css/51.051905ae.chunk.css"
  },
  {
    "revision": "45ad96d8f56a6f261aed",
    "url": "/static/css/52.051905ae.chunk.css"
  },
  {
    "revision": "a64c1ae66319c7030499",
    "url": "/static/css/55.639685ae.chunk.css"
  },
  {
    "revision": "be23a2584a5b7fd26afa",
    "url": "/static/css/56.5b5fb56a.chunk.css"
  },
  {
    "revision": "f2d6ad909621ef9799fd",
    "url": "/static/css/58.051905ae.chunk.css"
  },
  {
    "revision": "5f482a336772c3a6ff5e",
    "url": "/static/css/main.66a53726.chunk.css"
  },
  {
    "revision": "2a43024ec9358d9659c7",
    "url": "/static/js/0.578c21ea.chunk.js"
  },
  {
    "revision": "27cccbc4602488a2c4ab",
    "url": "/static/js/1.dfe225ec.chunk.js"
  },
  {
    "revision": "075194d3edc19bffa522",
    "url": "/static/js/10.714dbc83.chunk.js"
  },
  {
    "revision": "7ceb1e88192586a30049",
    "url": "/static/js/11.1c315aac.chunk.js"
  },
  {
    "revision": "704e4ff27c62aadd948d",
    "url": "/static/js/12.16e5a81c.chunk.js"
  },
  {
    "revision": "1e062bd009a1f0edb8ed",
    "url": "/static/js/13.1b06bdfa.chunk.js"
  },
  {
    "revision": "29e61a008546c881f45c",
    "url": "/static/js/14.b6791143.chunk.js"
  },
  {
    "revision": "c0dcebd27a814ff1515c",
    "url": "/static/js/15.6d0541a8.chunk.js"
  },
  {
    "revision": "9e626cc04a51cef726e0",
    "url": "/static/js/16.44bda13c.chunk.js"
  },
  {
    "revision": "6cb01c5ff5fa1677f1a3",
    "url": "/static/js/17.6915c49b.chunk.js"
  },
  {
    "revision": "75ea262a2f3f92b3dbb8",
    "url": "/static/js/18.d5b7157a.chunk.js"
  },
  {
    "revision": "b605b5b6afe543cf70fd",
    "url": "/static/js/2.9dce5e74.chunk.js"
  },
  {
    "revision": "0b5d4d35b36aec4c1cde",
    "url": "/static/js/21.9d8aadfd.chunk.js"
  },
  {
    "revision": "e088e4f583bc6344ff31",
    "url": "/static/js/22.c60344e8.chunk.js"
  },
  {
    "revision": "2b7f94596eb847f402db",
    "url": "/static/js/23.36a05b03.chunk.js"
  },
  {
    "revision": "96b274718ed1e9963573",
    "url": "/static/js/24.831e7bcd.chunk.js"
  },
  {
    "revision": "eb1e8896ef4dc046af62",
    "url": "/static/js/25.bd176079.chunk.js"
  },
  {
    "revision": "21de92adea8be1d4887d",
    "url": "/static/js/26.81c40858.chunk.js"
  },
  {
    "revision": "f897de5f0f1c8e2f3089",
    "url": "/static/js/27.ea47fba6.chunk.js"
  },
  {
    "revision": "ce3524b30049d5c66a59",
    "url": "/static/js/28.93a56981.chunk.js"
  },
  {
    "revision": "4ba9da92cb51bb030c4e",
    "url": "/static/js/29.f6a935d1.chunk.js"
  },
  {
    "revision": "3c9c440246a0a9b8d42d",
    "url": "/static/js/3.8675b390.chunk.js"
  },
  {
    "revision": "f5b032b06a3560f4572a",
    "url": "/static/js/30.1209b6ab.chunk.js"
  },
  {
    "revision": "68365886938cd5c9e15c",
    "url": "/static/js/31.b1a6de65.chunk.js"
  },
  {
    "revision": "d3abf17f4c5055a3f09e",
    "url": "/static/js/32.9142d31d.chunk.js"
  },
  {
    "revision": "179b050e3ea7ae0fa3e3",
    "url": "/static/js/33.ec40ded6.chunk.js"
  },
  {
    "revision": "e529a6b20f036ba4288c",
    "url": "/static/js/34.aa78de78.chunk.js"
  },
  {
    "revision": "335e4d19c327eec1bdac",
    "url": "/static/js/35.accb67ac.chunk.js"
  },
  {
    "revision": "abfdba5461eda74d1678",
    "url": "/static/js/36.a492c908.chunk.js"
  },
  {
    "revision": "00afa044d8568672f726",
    "url": "/static/js/37.b41453db.chunk.js"
  },
  {
    "revision": "ac8c206d65f1d4b49eb6",
    "url": "/static/js/38.a0236f22.chunk.js"
  },
  {
    "revision": "8632f1e511c7e654b99b",
    "url": "/static/js/39.68ba9748.chunk.js"
  },
  {
    "revision": "e4f18186fcd65335fa21",
    "url": "/static/js/4.1dca4661.chunk.js"
  },
  {
    "revision": "9c72519936d7536c8329",
    "url": "/static/js/40.83c293be.chunk.js"
  },
  {
    "revision": "1506250c2e6009d704e2",
    "url": "/static/js/41.02f18c0a.chunk.js"
  },
  {
    "revision": "1aff967c8fcada848915",
    "url": "/static/js/42.3df10c01.chunk.js"
  },
  {
    "revision": "97fc066a37d089856f3e",
    "url": "/static/js/43.8e62a742.chunk.js"
  },
  {
    "revision": "c9d51a47e6ef2478db0c",
    "url": "/static/js/44.0632b0d8.chunk.js"
  },
  {
    "revision": "5ba10784857f5534856d",
    "url": "/static/js/45.fbf49223.chunk.js"
  },
  {
    "revision": "6ab223a4f2c5f606a0ae",
    "url": "/static/js/46.0b5b08f5.chunk.js"
  },
  {
    "revision": "4bc0afa0268f1b1f2497",
    "url": "/static/js/47.00558556.chunk.js"
  },
  {
    "revision": "3ab24ae1dd7bdb343e87",
    "url": "/static/js/48.b88f3857.chunk.js"
  },
  {
    "revision": "a7c06349bb01c24e4516",
    "url": "/static/js/49.9867dd16.chunk.js"
  },
  {
    "revision": "4807db760ecec49ef75c",
    "url": "/static/js/5.acf030c6.chunk.js"
  },
  {
    "revision": "8a895e116e51695dc9f1",
    "url": "/static/js/50.d724e2be.chunk.js"
  },
  {
    "revision": "31304b283c1e2199811a",
    "url": "/static/js/51.95cc27dd.chunk.js"
  },
  {
    "revision": "45ad96d8f56a6f261aed",
    "url": "/static/js/52.3cd966c0.chunk.js"
  },
  {
    "revision": "597d4ac344352397cf9c",
    "url": "/static/js/53.6f10a525.chunk.js"
  },
  {
    "revision": "8036778dbde5697c013c",
    "url": "/static/js/54.1c493d94.chunk.js"
  },
  {
    "revision": "a64c1ae66319c7030499",
    "url": "/static/js/55.b3a8e237.chunk.js"
  },
  {
    "revision": "be23a2584a5b7fd26afa",
    "url": "/static/js/56.bbb6a6c7.chunk.js"
  },
  {
    "revision": "e699f0aea1d12467d9ad",
    "url": "/static/js/57.5fe55fe5.chunk.js"
  },
  {
    "revision": "f2d6ad909621ef9799fd",
    "url": "/static/js/58.f6c03382.chunk.js"
  },
  {
    "revision": "93c012c312c43d87cc9d",
    "url": "/static/js/59.2e82a920.chunk.js"
  },
  {
    "revision": "3951e3ec80bc0b9039a6",
    "url": "/static/js/6.f53e7f41.chunk.js"
  },
  {
    "revision": "bac5ed96ae5f5102568d",
    "url": "/static/js/60.88a0afd1.chunk.js"
  },
  {
    "revision": "24685f79bfdcc62d4294",
    "url": "/static/js/61.3b93a0be.chunk.js"
  },
  {
    "revision": "a65388be1c2f2761dccd",
    "url": "/static/js/62.a35f0b67.chunk.js"
  },
  {
    "revision": "c7ff56125263e606757b",
    "url": "/static/js/63.f7038317.chunk.js"
  },
  {
    "revision": "fdfb04e178a331885d45",
    "url": "/static/js/64.329943c5.chunk.js"
  },
  {
    "revision": "8283c8c6e2aef23b59d5",
    "url": "/static/js/65.d7af0e66.chunk.js"
  },
  {
    "revision": "bfe1a24da298a360fb1f",
    "url": "/static/js/66.127fc50e.chunk.js"
  },
  {
    "revision": "00ea8de6cfed46ed2350",
    "url": "/static/js/67.3dd96776.chunk.js"
  },
  {
    "revision": "d395b6e8134df69926ff",
    "url": "/static/js/68.26acbdd6.chunk.js"
  },
  {
    "revision": "2f66b3148f50305ebbb8",
    "url": "/static/js/69.51c19ab5.chunk.js"
  },
  {
    "revision": "970bea93e16fa9029389",
    "url": "/static/js/7.73c8bb15.chunk.js"
  },
  {
    "revision": "e8dc1bdc2b5971ff1dbe",
    "url": "/static/js/70.be34705e.chunk.js"
  },
  {
    "revision": "ef59f73b0d1f072a999e",
    "url": "/static/js/71.d3bad7ea.chunk.js"
  },
  {
    "revision": "96043a8b5eada03ead1d",
    "url": "/static/js/72.ec592003.chunk.js"
  },
  {
    "revision": "c00d9eca031d01a70917",
    "url": "/static/js/73.13055faa.chunk.js"
  },
  {
    "revision": "184baa782d2ab179d545",
    "url": "/static/js/74.479684cb.chunk.js"
  },
  {
    "revision": "a621e147cf7e7aaebf97",
    "url": "/static/js/75.442bc11f.chunk.js"
  },
  {
    "revision": "af106bccd674af398e25",
    "url": "/static/js/76.e67d31fc.chunk.js"
  },
  {
    "revision": "b303d02185cfbf90a73b",
    "url": "/static/js/77.b0285e4a.chunk.js"
  },
  {
    "revision": "64937e506f822dbe422d",
    "url": "/static/js/78.dce811b1.chunk.js"
  },
  {
    "revision": "a41406e512b7b971c16e",
    "url": "/static/js/79.aabeb98d.chunk.js"
  },
  {
    "revision": "b0e26d48a2b515e4721d",
    "url": "/static/js/8.055ed1ea.chunk.js"
  },
  {
    "revision": "5189a50f6df9142911d7",
    "url": "/static/js/80.0ce2a2e0.chunk.js"
  },
  {
    "revision": "1d108d2a572b64b879a6",
    "url": "/static/js/81.b4b09de5.chunk.js"
  },
  {
    "revision": "9a5e4f75e3d2b3e5b07a",
    "url": "/static/js/82.108ae0b6.chunk.js"
  },
  {
    "revision": "55a5d0d8d36118b1a2fa",
    "url": "/static/js/83.dadef86d.chunk.js"
  },
  {
    "revision": "16cf97923b9efaa279b7",
    "url": "/static/js/84.bba650d6.chunk.js"
  },
  {
    "revision": "76049fb418bdf888133c",
    "url": "/static/js/85.ecef8636.chunk.js"
  },
  {
    "revision": "1430adf54c2ba67d94b4",
    "url": "/static/js/9.e0612ba7.chunk.js"
  },
  {
    "revision": "5f482a336772c3a6ff5e",
    "url": "/static/js/main.c1689de8.chunk.js"
  },
  {
    "revision": "250b012f1a73abad9b20",
    "url": "/static/js/runtime~main.deed119d.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);