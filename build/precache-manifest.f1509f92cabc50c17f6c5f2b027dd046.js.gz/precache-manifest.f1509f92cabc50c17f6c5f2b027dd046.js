self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c459dbb9c84f1a0ffd233f11913ae8cf",
    "url": "/index.html"
  },
  {
    "revision": "2fdc7006172b87e11284",
    "url": "/static/css/14.a7bdec9b.chunk.css"
  },
  {
    "revision": "fb7dbf9633a614be22f0",
    "url": "/static/css/main.40671e68.chunk.css"
  },
  {
    "revision": "f6f9019315209fab04e1",
    "url": "/static/js/0.c04142d3.chunk.js"
  },
  {
    "revision": "be19ae683838ec7eb034",
    "url": "/static/js/1.45c9d7be.chunk.js"
  },
  {
    "revision": "2a27967b19f20bbc123d",
    "url": "/static/js/10.e6542b4d.chunk.js"
  },
  {
    "revision": "2b25517932c59908559e",
    "url": "/static/js/11.d7735adc.chunk.js"
  },
  {
    "revision": "2fdc7006172b87e11284",
    "url": "/static/js/14.dd9ee617.chunk.js"
  },
  {
    "revision": "f4f15cc4604f3b312629441f005ba228",
    "url": "/static/js/14.dd9ee617.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1c253a73cfb08c62e6f8",
    "url": "/static/js/15.6e127d9c.chunk.js"
  },
  {
    "revision": "a41cf524454d7a49468eab5f6db267fb",
    "url": "/static/js/15.6e127d9c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7a340f276789bea1b248",
    "url": "/static/js/16.c9bdedbb.chunk.js"
  },
  {
    "revision": "3e54f97d7121a8e82801",
    "url": "/static/js/17.9907b04c.chunk.js"
  },
  {
    "revision": "c57ac83b907ea7e29f8d",
    "url": "/static/js/18.2ccf02eb.chunk.js"
  },
  {
    "revision": "2849e926b59e09cc1299",
    "url": "/static/js/19.1ce29e81.chunk.js"
  },
  {
    "revision": "bcb69c06c5d3aaa46121",
    "url": "/static/js/2.634edb0b.chunk.js"
  },
  {
    "revision": "467b7d4fd0e1fc06ed2d",
    "url": "/static/js/20.c9bde2ea.chunk.js"
  },
  {
    "revision": "435bdaac7a32e8fdbe04",
    "url": "/static/js/21.8007e06b.chunk.js"
  },
  {
    "revision": "f9f8bbe2a0047a6c58f3",
    "url": "/static/js/22.7606252b.chunk.js"
  },
  {
    "revision": "416d1abcf76375406507",
    "url": "/static/js/23.24f594a4.chunk.js"
  },
  {
    "revision": "47628f40419128673271",
    "url": "/static/js/24.ed372fc7.chunk.js"
  },
  {
    "revision": "739219943609c6764d58",
    "url": "/static/js/25.2dcb1a12.chunk.js"
  },
  {
    "revision": "98a4dd670e752d68585a",
    "url": "/static/js/26.dc678bb3.chunk.js"
  },
  {
    "revision": "fcc4ee2400e9d6e6b102",
    "url": "/static/js/27.c9bf9dbc.chunk.js"
  },
  {
    "revision": "43e451bbf75c68fd0431",
    "url": "/static/js/28.d68621a3.chunk.js"
  },
  {
    "revision": "d6012e8af51443faa7e0",
    "url": "/static/js/29.ad1891d4.chunk.js"
  },
  {
    "revision": "66fb9bf63a9b8c940785",
    "url": "/static/js/3.6c51f78a.chunk.js"
  },
  {
    "revision": "647dada6f4fe1f23009d",
    "url": "/static/js/30.dca3a57d.chunk.js"
  },
  {
    "revision": "37126fe0e901a887b276",
    "url": "/static/js/31.172f6c99.chunk.js"
  },
  {
    "revision": "63f5b9ff3cbf7c8ef5b1",
    "url": "/static/js/32.926b1785.chunk.js"
  },
  {
    "revision": "bbb66437d68cb43316d4",
    "url": "/static/js/33.043d9f8d.chunk.js"
  },
  {
    "revision": "17cbca4bd482387715d1",
    "url": "/static/js/34.c5caf272.chunk.js"
  },
  {
    "revision": "f7238576ead53c0f0469",
    "url": "/static/js/35.90702a91.chunk.js"
  },
  {
    "revision": "35f2f63a7760a6f6c2df",
    "url": "/static/js/36.8bd66ab6.chunk.js"
  },
  {
    "revision": "ae3ec59828af082d169c",
    "url": "/static/js/37.171a37ce.chunk.js"
  },
  {
    "revision": "a7a8401d6d674ad96827",
    "url": "/static/js/38.949101ee.chunk.js"
  },
  {
    "revision": "f9b652c9515f51516b5a",
    "url": "/static/js/39.4156d673.chunk.js"
  },
  {
    "revision": "7471cb376379dce0fdd1",
    "url": "/static/js/4.c8468088.chunk.js"
  },
  {
    "revision": "b10620095404622deca4",
    "url": "/static/js/40.3ccc50d4.chunk.js"
  },
  {
    "revision": "8bf5f41952a8726280ab",
    "url": "/static/js/41.1bf1c109.chunk.js"
  },
  {
    "revision": "e780602cbf054dd324e7",
    "url": "/static/js/42.79b3329b.chunk.js"
  },
  {
    "revision": "a6ed509c9f04d7c10cd1",
    "url": "/static/js/43.4a968ddb.chunk.js"
  },
  {
    "revision": "c51a51dfffa1e4df4548",
    "url": "/static/js/44.f1ef1fce.chunk.js"
  },
  {
    "revision": "7c44d4282e3eba594d74",
    "url": "/static/js/45.c81192b0.chunk.js"
  },
  {
    "revision": "a070cdb785358f46ecff",
    "url": "/static/js/46.8bf35d60.chunk.js"
  },
  {
    "revision": "afc42b70bdb774e5343c",
    "url": "/static/js/47.0e15f424.chunk.js"
  },
  {
    "revision": "b5f28636ff6a02999011",
    "url": "/static/js/48.803e87b1.chunk.js"
  },
  {
    "revision": "1a76e83b13f4ba4c4038",
    "url": "/static/js/49.acf8fde7.chunk.js"
  },
  {
    "revision": "cc93402b58e5c741b201",
    "url": "/static/js/5.19677beb.chunk.js"
  },
  {
    "revision": "1c7ef9c7fd3e3281bd00",
    "url": "/static/js/50.8842e137.chunk.js"
  },
  {
    "revision": "0853f41cf6a3e2819205",
    "url": "/static/js/51.912a7304.chunk.js"
  },
  {
    "revision": "c9032a7e56d8305751ad",
    "url": "/static/js/52.3fdec432.chunk.js"
  },
  {
    "revision": "cf2fa3b9d11befd6a832",
    "url": "/static/js/53.e0b15ccd.chunk.js"
  },
  {
    "revision": "29354f940af6a3f19bb7",
    "url": "/static/js/54.c9e79830.chunk.js"
  },
  {
    "revision": "4f510c2b1cc7cbd13253",
    "url": "/static/js/55.6587e994.chunk.js"
  },
  {
    "revision": "13b37d748aff59cc68fb",
    "url": "/static/js/56.1ec7f694.chunk.js"
  },
  {
    "revision": "da634f90ca13ded00721",
    "url": "/static/js/57.a51f0e84.chunk.js"
  },
  {
    "revision": "d0de16a48c457346300b",
    "url": "/static/js/58.1e88ad3f.chunk.js"
  },
  {
    "revision": "4926a0c00425a4d12cc2",
    "url": "/static/js/59.921eb807.chunk.js"
  },
  {
    "revision": "fab7cbc2de079c4ba393",
    "url": "/static/js/6.9c32dbf5.chunk.js"
  },
  {
    "revision": "ea17ec2ccd7eff9fb015",
    "url": "/static/js/60.e08514dd.chunk.js"
  },
  {
    "revision": "6c4d2d8bd54eb5a549e6",
    "url": "/static/js/61.974dcab0.chunk.js"
  },
  {
    "revision": "1de8cae0ac43584ea407",
    "url": "/static/js/62.742dc5b1.chunk.js"
  },
  {
    "revision": "949946e05acf031017be",
    "url": "/static/js/63.a3e8193c.chunk.js"
  },
  {
    "revision": "98361ca906c26fbc5728",
    "url": "/static/js/7.8736d8e4.chunk.js"
  },
  {
    "revision": "27cd10287a3612f6dd8e",
    "url": "/static/js/8.247002e5.chunk.js"
  },
  {
    "revision": "e6b6abb8efbf5c0499be",
    "url": "/static/js/9.c8840f8c.chunk.js"
  },
  {
    "revision": "fb7dbf9633a614be22f0",
    "url": "/static/js/main.6e5274f3.chunk.js"
  },
  {
    "revision": "1e30c0d09e243ce99673",
    "url": "/static/js/runtime-main.6cbdf1b8.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);