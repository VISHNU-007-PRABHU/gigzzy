self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fa2396f4bb28924288c596cceb939ba9",
    "url": "/index.html"
  },
  {
    "revision": "4d8276ca3f3848eca04f",
    "url": "/static/css/20.18585a14.chunk.css"
  },
  {
    "revision": "c267a1915876b6e54629",
    "url": "/static/css/28.051905ae.chunk.css"
  },
  {
    "revision": "5b8017826a530292c09a",
    "url": "/static/css/29.3a6be942.chunk.css"
  },
  {
    "revision": "60c45f4725bdbe556e6b",
    "url": "/static/css/30.88292131.chunk.css"
  },
  {
    "revision": "a8ddd31a721abb0ddbfc",
    "url": "/static/css/35.cb85cd3b.chunk.css"
  },
  {
    "revision": "20b1068d1b5635c0539b",
    "url": "/static/css/37.11000f17.chunk.css"
  },
  {
    "revision": "140053b76dfb20ccc2bd",
    "url": "/static/css/40.11000f17.chunk.css"
  },
  {
    "revision": "1d2db0e3aa0c7d8c8ce5",
    "url": "/static/css/45.7dbeb58c.chunk.css"
  },
  {
    "revision": "2b66caa989642130dd5d",
    "url": "/static/css/46.ecaf69fb.chunk.css"
  },
  {
    "revision": "4ed66c534b802e1bd34e",
    "url": "/static/css/50.f9b90304.chunk.css"
  },
  {
    "revision": "78ddde69ee1181bba35d",
    "url": "/static/css/51.11000f17.chunk.css"
  },
  {
    "revision": "558640f88842e28756a9",
    "url": "/static/css/53.9142c0f9.chunk.css"
  },
  {
    "revision": "994cf1dd7ea24ec2ae0e",
    "url": "/static/css/54.9142c0f9.chunk.css"
  },
  {
    "revision": "f196d182d67e64e7ccee",
    "url": "/static/css/55.0724d5f1.chunk.css"
  },
  {
    "revision": "0d647b7c6b6df5bcf199",
    "url": "/static/css/56.3a6be942.chunk.css"
  },
  {
    "revision": "77b82b6afb451fdff5b9",
    "url": "/static/css/57.3a6be942.chunk.css"
  },
  {
    "revision": "6ee3a60cc1563541cacc",
    "url": "/static/css/61.cdaf15d1.chunk.css"
  },
  {
    "revision": "d14222537276c5dcf38b",
    "url": "/static/css/63.5b5fb56a.chunk.css"
  },
  {
    "revision": "582e9810dd873a7f1679",
    "url": "/static/css/main.2726a05c.chunk.css"
  },
  {
    "revision": "4016a970388eb9e3756f",
    "url": "/static/js/0.f64129e8.chunk.js"
  },
  {
    "revision": "5abe299686b26ddbd2c7",
    "url": "/static/js/1.10bd3c66.chunk.js"
  },
  {
    "revision": "2882f13dc73b5d63c28f",
    "url": "/static/js/10.5b6d9610.chunk.js"
  },
  {
    "revision": "15585824b48a2598c5e2",
    "url": "/static/js/100.70fc5b05.chunk.js"
  },
  {
    "revision": "5ab175290b8bc081cf51",
    "url": "/static/js/101.ceb17a5d.chunk.js"
  },
  {
    "revision": "e948e5202bcb936b0efd",
    "url": "/static/js/102.3274ce22.chunk.js"
  },
  {
    "revision": "3af00344e445a1f0b5c3",
    "url": "/static/js/103.19ca6670.chunk.js"
  },
  {
    "revision": "cc9027fdc1240ba73dc2",
    "url": "/static/js/104.24c4d535.chunk.js"
  },
  {
    "revision": "b5cf16bd5b70a0675e86",
    "url": "/static/js/105.ac901aeb.chunk.js"
  },
  {
    "revision": "ff3ca1a544d69b23e7ff",
    "url": "/static/js/106.d5e2b2c1.chunk.js"
  },
  {
    "revision": "57023229148272e51a8d",
    "url": "/static/js/107.81fcebae.chunk.js"
  },
  {
    "revision": "2b9279c4cd9aa7f395b3",
    "url": "/static/js/108.d8194ffb.chunk.js"
  },
  {
    "revision": "0bd5f2a31854cd45f227",
    "url": "/static/js/109.9dc75104.chunk.js"
  },
  {
    "revision": "af054656e4ffb465a97a",
    "url": "/static/js/11.901805d0.chunk.js"
  },
  {
    "revision": "ad350951ea1d21a054fb",
    "url": "/static/js/110.dbd45c98.chunk.js"
  },
  {
    "revision": "ef2bfdc8bef7909ff59e",
    "url": "/static/js/111.14c80263.chunk.js"
  },
  {
    "revision": "a067aee855b56863c6b4",
    "url": "/static/js/112.11e9e706.chunk.js"
  },
  {
    "revision": "4a92432b6510e9ddc03a",
    "url": "/static/js/113.48dfd544.chunk.js"
  },
  {
    "revision": "d4b5168d196646a3e88b",
    "url": "/static/js/114.ac9b2cd4.chunk.js"
  },
  {
    "revision": "d1335f701cb16747c7e6",
    "url": "/static/js/115.82888215.chunk.js"
  },
  {
    "revision": "8c87a3ee3b1687f933cc",
    "url": "/static/js/12.3d2d6d67.chunk.js"
  },
  {
    "revision": "a687cd33d18be29cea9e",
    "url": "/static/js/13.addba30d.chunk.js"
  },
  {
    "revision": "c2b94cd95767ccd23c93",
    "url": "/static/js/14.e19cadcd.chunk.js"
  },
  {
    "revision": "dea1458d6a3e7585ef7f",
    "url": "/static/js/15.ffc6ad83.chunk.js"
  },
  {
    "revision": "f25ccf23e109290cefd4",
    "url": "/static/js/16.2f5752a0.chunk.js"
  },
  {
    "revision": "50498a0bd2098589d308",
    "url": "/static/js/17.da9aee37.chunk.js"
  },
  {
    "revision": "6460f89cbfad88b0d1a3",
    "url": "/static/js/18.b3a7a1c2.chunk.js"
  },
  {
    "revision": "c27925bebfd18f26dfdf",
    "url": "/static/js/19.14055909.chunk.js"
  },
  {
    "revision": "dae881426d578d927faa",
    "url": "/static/js/2.da6f8150.chunk.js"
  },
  {
    "revision": "4d8276ca3f3848eca04f",
    "url": "/static/js/20.b6e4a6c0.chunk.js"
  },
  {
    "revision": "3fbccee4aee06bfff694",
    "url": "/static/js/21.9bca81c4.chunk.js"
  },
  {
    "revision": "b43259377283a82bdefa",
    "url": "/static/js/22.fa74ecda.chunk.js"
  },
  {
    "revision": "bf6b85a49d404b496399",
    "url": "/static/js/23.50d07d2d.chunk.js"
  },
  {
    "revision": "45dfe4309e1575f70194",
    "url": "/static/js/24.f0cccc72.chunk.js"
  },
  {
    "revision": "25661387c8a3a0fe6a28",
    "url": "/static/js/25.32e4f29c.chunk.js"
  },
  {
    "revision": "c267a1915876b6e54629",
    "url": "/static/js/28.4802956c.chunk.js"
  },
  {
    "revision": "5b8017826a530292c09a",
    "url": "/static/js/29.0b463339.chunk.js"
  },
  {
    "revision": "fc7269694a963504f0f6",
    "url": "/static/js/3.be93ef5b.chunk.js"
  },
  {
    "revision": "60c45f4725bdbe556e6b",
    "url": "/static/js/30.f64a3683.chunk.js"
  },
  {
    "revision": "27233e1dfdbb7aadb07b",
    "url": "/static/js/31.a95e7ce3.chunk.js"
  },
  {
    "revision": "e019945967bfd9084dc8",
    "url": "/static/js/32.8b14d27c.chunk.js"
  },
  {
    "revision": "1efa2526384a40c713e2",
    "url": "/static/js/33.ae372574.chunk.js"
  },
  {
    "revision": "164af402244f93ea2711",
    "url": "/static/js/34.4e19b1b9.chunk.js"
  },
  {
    "revision": "a8ddd31a721abb0ddbfc",
    "url": "/static/js/35.69a293c5.chunk.js"
  },
  {
    "revision": "157a6ae89419e3050088",
    "url": "/static/js/36.b668e290.chunk.js"
  },
  {
    "revision": "20b1068d1b5635c0539b",
    "url": "/static/js/37.8564451d.chunk.js"
  },
  {
    "revision": "281df902495809cdbdde",
    "url": "/static/js/38.25fee973.chunk.js"
  },
  {
    "revision": "796cf7fb0180db08f2fb",
    "url": "/static/js/39.079b4149.chunk.js"
  },
  {
    "revision": "a3a40798b71dc070f92e",
    "url": "/static/js/4.83d3223d.chunk.js"
  },
  {
    "revision": "140053b76dfb20ccc2bd",
    "url": "/static/js/40.93afed0f.chunk.js"
  },
  {
    "revision": "631a6c0035c217c74010",
    "url": "/static/js/41.0aea56c6.chunk.js"
  },
  {
    "revision": "2c5ee2393f4b50fb2344",
    "url": "/static/js/42.17636420.chunk.js"
  },
  {
    "revision": "c7c5dcb1a128a2bd07a6",
    "url": "/static/js/43.c752b62d.chunk.js"
  },
  {
    "revision": "93c18abc680fd257e996",
    "url": "/static/js/44.4f48fbf3.chunk.js"
  },
  {
    "revision": "1d2db0e3aa0c7d8c8ce5",
    "url": "/static/js/45.9699bb91.chunk.js"
  },
  {
    "revision": "2b66caa989642130dd5d",
    "url": "/static/js/46.561d6fcb.chunk.js"
  },
  {
    "revision": "bf8785c148af1e1c32a6",
    "url": "/static/js/47.a031a2a6.chunk.js"
  },
  {
    "revision": "2b92750b9e4769a02615",
    "url": "/static/js/48.7d4944f7.chunk.js"
  },
  {
    "revision": "b57bb549c80e560211ed",
    "url": "/static/js/49.21f1b31b.chunk.js"
  },
  {
    "revision": "768bceb2affa1801628d",
    "url": "/static/js/5.c1b72971.chunk.js"
  },
  {
    "revision": "4ed66c534b802e1bd34e",
    "url": "/static/js/50.da31f39b.chunk.js"
  },
  {
    "revision": "78ddde69ee1181bba35d",
    "url": "/static/js/51.321f1eba.chunk.js"
  },
  {
    "revision": "f28b10ee558197b5a426",
    "url": "/static/js/52.0a651efc.chunk.js"
  },
  {
    "revision": "558640f88842e28756a9",
    "url": "/static/js/53.aa2c9a73.chunk.js"
  },
  {
    "revision": "994cf1dd7ea24ec2ae0e",
    "url": "/static/js/54.3eaf0476.chunk.js"
  },
  {
    "revision": "f196d182d67e64e7ccee",
    "url": "/static/js/55.7255f6fb.chunk.js"
  },
  {
    "revision": "0d647b7c6b6df5bcf199",
    "url": "/static/js/56.42cdaa36.chunk.js"
  },
  {
    "revision": "77b82b6afb451fdff5b9",
    "url": "/static/js/57.13b9a059.chunk.js"
  },
  {
    "revision": "df84b48d3c9ec8a0f9bb",
    "url": "/static/js/58.5a7cef2e.chunk.js"
  },
  {
    "revision": "f4b04faa94d544a569fb",
    "url": "/static/js/59.4cc038a1.chunk.js"
  },
  {
    "revision": "1935f111cbd79d217d18",
    "url": "/static/js/6.6a8c5a84.chunk.js"
  },
  {
    "revision": "a9ed28b66729c1e0ab55",
    "url": "/static/js/60.23b84039.chunk.js"
  },
  {
    "revision": "6ee3a60cc1563541cacc",
    "url": "/static/js/61.9da0a6ec.chunk.js"
  },
  {
    "revision": "ce7e74f5c7916e6ea1db",
    "url": "/static/js/62.07c0a806.chunk.js"
  },
  {
    "revision": "d14222537276c5dcf38b",
    "url": "/static/js/63.d35b4712.chunk.js"
  },
  {
    "revision": "dfe408d55ea813610f6f",
    "url": "/static/js/64.6b726a14.chunk.js"
  },
  {
    "revision": "535ec53bf3390616fff7",
    "url": "/static/js/65.cfd94f60.chunk.js"
  },
  {
    "revision": "43d04a46bba1ea2dced2",
    "url": "/static/js/66.5886981f.chunk.js"
  },
  {
    "revision": "69af067e7c1f63af604e",
    "url": "/static/js/67.fdd82264.chunk.js"
  },
  {
    "revision": "5d24e45d7677d2f7a433",
    "url": "/static/js/68.81f938d2.chunk.js"
  },
  {
    "revision": "c5b7d39661da2ed31b9a",
    "url": "/static/js/69.c9d25dde.chunk.js"
  },
  {
    "revision": "d2584beabe99338ccb99",
    "url": "/static/js/7.bbbed47f.chunk.js"
  },
  {
    "revision": "1966a5533f529f8d78a1",
    "url": "/static/js/70.88e38bc6.chunk.js"
  },
  {
    "revision": "9d4fa032a123a7c9c125",
    "url": "/static/js/71.807be93d.chunk.js"
  },
  {
    "revision": "f310a0bb9973a28400bc",
    "url": "/static/js/72.161626e8.chunk.js"
  },
  {
    "revision": "eaf7272ce74fcc181edf",
    "url": "/static/js/73.34ea7078.chunk.js"
  },
  {
    "revision": "b847de4ad4c3da67ccb4",
    "url": "/static/js/74.a6b661a5.chunk.js"
  },
  {
    "revision": "35eae057640f3388ce81",
    "url": "/static/js/75.4c57e9c5.chunk.js"
  },
  {
    "revision": "06d7d09ff01b3b003981",
    "url": "/static/js/76.a84f1705.chunk.js"
  },
  {
    "revision": "3aa61edb41cc74122d3d",
    "url": "/static/js/77.d161da4c.chunk.js"
  },
  {
    "revision": "24153c8ec7ea29980bbe",
    "url": "/static/js/78.79285a9c.chunk.js"
  },
  {
    "revision": "846aca40579785255133",
    "url": "/static/js/79.f2125335.chunk.js"
  },
  {
    "revision": "813d01313c9c7c01b4da",
    "url": "/static/js/8.77889fc5.chunk.js"
  },
  {
    "revision": "28924416283eb576047e",
    "url": "/static/js/80.8622e886.chunk.js"
  },
  {
    "revision": "4af1822cf4d72b269c07",
    "url": "/static/js/81.9418512d.chunk.js"
  },
  {
    "revision": "0ff20db6a3555cc4a24f",
    "url": "/static/js/82.0aedd6b0.chunk.js"
  },
  {
    "revision": "9d7fe0bbd99be602667c",
    "url": "/static/js/83.9d66f237.chunk.js"
  },
  {
    "revision": "480ec9976cceb4a69dbe",
    "url": "/static/js/84.099694dc.chunk.js"
  },
  {
    "revision": "a6d68e3ee63f5f2d2072",
    "url": "/static/js/85.51b81ea2.chunk.js"
  },
  {
    "revision": "e676094593b42542724a",
    "url": "/static/js/86.5a96c964.chunk.js"
  },
  {
    "revision": "1991263826213ef2b24f",
    "url": "/static/js/87.d5f61e20.chunk.js"
  },
  {
    "revision": "2762feae1cf66d363666",
    "url": "/static/js/88.69ffb15d.chunk.js"
  },
  {
    "revision": "b6228b234665ea37106e",
    "url": "/static/js/89.fb5ff960.chunk.js"
  },
  {
    "revision": "b51ccf924b01792b6bc5",
    "url": "/static/js/9.3d0c2041.chunk.js"
  },
  {
    "revision": "c8d5949993ff8c93a876",
    "url": "/static/js/90.0cd28398.chunk.js"
  },
  {
    "revision": "876a64150ae8cdb934a7",
    "url": "/static/js/91.02b9bd98.chunk.js"
  },
  {
    "revision": "43b6ae2cf183aca34e6b",
    "url": "/static/js/92.597cff2f.chunk.js"
  },
  {
    "revision": "14c2361dd2fa831e9aca",
    "url": "/static/js/93.78d5fbf3.chunk.js"
  },
  {
    "revision": "8fb498f58306cefbf162",
    "url": "/static/js/94.5004fa32.chunk.js"
  },
  {
    "revision": "e30711361910708442f7",
    "url": "/static/js/95.8c4a8274.chunk.js"
  },
  {
    "revision": "9641d06791ac5fdfe449",
    "url": "/static/js/96.c19120d7.chunk.js"
  },
  {
    "revision": "c080e226e656f976071a",
    "url": "/static/js/97.e423f966.chunk.js"
  },
  {
    "revision": "6018b47b9cc7dd4676b2",
    "url": "/static/js/98.95994150.chunk.js"
  },
  {
    "revision": "335837628a1917c3a4a8",
    "url": "/static/js/99.46ecd92e.chunk.js"
  },
  {
    "revision": "582e9810dd873a7f1679",
    "url": "/static/js/main.1ed9d277.chunk.js"
  },
  {
    "revision": "ed09eab7a1abace43486",
    "url": "/static/js/runtime~main.670399b1.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "a36e1590e88034eead1feb6c0eae93e6",
    "url": "/static/media/c1.a36e1590.png"
  },
  {
    "revision": "cb347b61228b2ad5df1d0ee0cfed6449",
    "url": "/static/media/carpet_cleaning.cb347b61.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "494d10925dc7a6008ca86897a72df6ac",
    "url": "/static/media/hb1.494d1092.png"
  },
  {
    "revision": "3a29e909044b92b8e37e3d1e48da6921",
    "url": "/static/media/hb2.3a29e909.png"
  },
  {
    "revision": "ab99bd7a3cbf46d2487b36b75b29fb06",
    "url": "/static/media/hb3.ab99bd7a.png"
  },
  {
    "revision": "f279ef3d571a6e19474a1e14c3653b64",
    "url": "/static/media/hb4.f279ef3d.png"
  },
  {
    "revision": "2729aa8015f5e63f692b48a7ccb78f1f",
    "url": "/static/media/hb5.2729aa80.png"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "58c893a77f8dbd7c6e13c50c8f6357a7",
    "url": "/static/media/ht1.58c893a7.png"
  },
  {
    "revision": "5cad2bf6cf38f3a41adf2cbc4b586815",
    "url": "/static/media/ht2.5cad2bf6.png"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);