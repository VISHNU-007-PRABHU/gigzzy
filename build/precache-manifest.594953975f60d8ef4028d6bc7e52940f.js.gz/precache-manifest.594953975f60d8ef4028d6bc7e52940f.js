self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e86a0d8d33e28e8251acbcb002f97ca7",
    "url": "/index.html"
  },
  {
    "revision": "8a6da44996ca6b52fdd1",
    "url": "/static/css/8.9ba107ea.chunk.css"
  },
  {
    "revision": "3d796d165c592480d6ef",
    "url": "/static/css/main.b1a64f37.chunk.css"
  },
  {
    "revision": "f38c3a91fe2a763cb2ba",
    "url": "/static/js/0.16694612.chunk.js"
  },
  {
    "revision": "8cfa151972561cfc1487",
    "url": "/static/js/1.2c4b169b.chunk.js"
  },
  {
    "revision": "6f9fd1d09e3a3c2babf3",
    "url": "/static/js/10.37091675.chunk.js"
  },
  {
    "revision": "82a6b3ed93f612c8285a",
    "url": "/static/js/11.6b9a4100.chunk.js"
  },
  {
    "revision": "b74c8273a2d09cf44e27",
    "url": "/static/js/2.242bc745.chunk.js"
  },
  {
    "revision": "fea5f3c81374616ff2eb",
    "url": "/static/js/3.2c8be9f2.chunk.js"
  },
  {
    "revision": "e914942cce7e2ba086ac",
    "url": "/static/js/4.363471d0.chunk.js"
  },
  {
    "revision": "d26633abb508448442ac",
    "url": "/static/js/5.3995e1cd.chunk.js"
  },
  {
    "revision": "8a6da44996ca6b52fdd1",
    "url": "/static/js/8.e6952be1.chunk.js"
  },
  {
    "revision": "22880787cd28f9c17251",
    "url": "/static/js/9.c6363c49.chunk.js"
  },
  {
    "revision": "3d796d165c592480d6ef",
    "url": "/static/js/main.d74f0200.chunk.js"
  },
  {
    "revision": "f8770da916fe41a8abf5",
    "url": "/static/js/runtime~main.664b41af.js"
  },
  {
    "revision": "ec10c675411b4ad7e25db55b6bd01577",
    "url": "/static/media/Gigzzy.ec10c675.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "2503bfccaf0f52c9a8f73ea079b10d56",
    "url": "/static/media/gigzzypro.2503bfcc.png"
  },
  {
    "revision": "018dfbf7ecb4f4d0e720ca04bc73fcf0",
    "url": "/static/media/handyman.018dfbf7.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  }
]);