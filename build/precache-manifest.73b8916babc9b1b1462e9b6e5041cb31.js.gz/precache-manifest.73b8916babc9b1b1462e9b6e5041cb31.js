self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1f3a97f8d165bb440713b3e59809b517",
    "url": "/index.html"
  },
  {
    "revision": "f68f8a67fdaff933b3db",
    "url": "/static/css/14.75a79a19.chunk.css"
  },
  {
    "revision": "5fdf93eb07cc415326d8",
    "url": "/static/css/main.b30c303b.chunk.css"
  },
  {
    "revision": "acb6e081cfd44328782e",
    "url": "/static/js/0.dd67f006.chunk.js"
  },
  {
    "revision": "3e25c37fb49be8256e3e",
    "url": "/static/js/1.8da2f7a4.chunk.js"
  },
  {
    "revision": "d1c65f09e94a5b2e4d1e",
    "url": "/static/js/10.dd73bed3.chunk.js"
  },
  {
    "revision": "95dd01008c92607b846f",
    "url": "/static/js/11.142b59be.chunk.js"
  },
  {
    "revision": "f68f8a67fdaff933b3db",
    "url": "/static/js/14.e9e5ee85.chunk.js"
  },
  {
    "revision": "ba9bcb927a7b86b7dbee",
    "url": "/static/js/15.9950083e.chunk.js"
  },
  {
    "revision": "cf8c3735080c6975a928",
    "url": "/static/js/16.c90d5b72.chunk.js"
  },
  {
    "revision": "d7e18a78d18264a47bee",
    "url": "/static/js/17.e7ba486d.chunk.js"
  },
  {
    "revision": "c0e60478021f5b6e6d8b",
    "url": "/static/js/18.6ae3a018.chunk.js"
  },
  {
    "revision": "419dceeee00b8cd37f5f",
    "url": "/static/js/19.5196740b.chunk.js"
  },
  {
    "revision": "d4b1c51978b6ad9d36af",
    "url": "/static/js/2.d5432a7e.chunk.js"
  },
  {
    "revision": "2e484a46e534c9461d91",
    "url": "/static/js/20.3cc103d9.chunk.js"
  },
  {
    "revision": "22d3507e8363304a4dca",
    "url": "/static/js/21.fffe37b3.chunk.js"
  },
  {
    "revision": "c33d98b47c94f6028133",
    "url": "/static/js/22.51464280.chunk.js"
  },
  {
    "revision": "4669785b981344f921ec",
    "url": "/static/js/23.edff62b9.chunk.js"
  },
  {
    "revision": "9c2bbcb56432ed080aaf",
    "url": "/static/js/24.cdf5da0c.chunk.js"
  },
  {
    "revision": "eacf32733282f0f84d5a",
    "url": "/static/js/25.6f2626c2.chunk.js"
  },
  {
    "revision": "6b82a6ab423dee2b67af",
    "url": "/static/js/26.d7109afd.chunk.js"
  },
  {
    "revision": "3ba56380bc98f533b538",
    "url": "/static/js/27.48bd0043.chunk.js"
  },
  {
    "revision": "77f87d535f434fcd7eb5",
    "url": "/static/js/28.567bfa7b.chunk.js"
  },
  {
    "revision": "428cf8b89aa7935e7ed6",
    "url": "/static/js/29.f5767c9d.chunk.js"
  },
  {
    "revision": "0f3de97d33e7d4d8f2a8",
    "url": "/static/js/3.50aaffc3.chunk.js"
  },
  {
    "revision": "1bd21ef81aa73c791c4b",
    "url": "/static/js/30.0af683ca.chunk.js"
  },
  {
    "revision": "738d69ff8e11240716dd",
    "url": "/static/js/31.96ca0a6e.chunk.js"
  },
  {
    "revision": "487af90757ee82e73f60",
    "url": "/static/js/32.c3cf2b5c.chunk.js"
  },
  {
    "revision": "3d0c675cbcc907dfdf51",
    "url": "/static/js/33.57e99e59.chunk.js"
  },
  {
    "revision": "a23f4ae75e18892a0502",
    "url": "/static/js/34.2feb77b2.chunk.js"
  },
  {
    "revision": "26267ec764b6b87a5c41",
    "url": "/static/js/35.fb2565e4.chunk.js"
  },
  {
    "revision": "dd13a94a5913ef76f450",
    "url": "/static/js/36.fafa93a7.chunk.js"
  },
  {
    "revision": "98747db3f4289b105003",
    "url": "/static/js/37.e1cff103.chunk.js"
  },
  {
    "revision": "a825ad6d39a1219e6c4b",
    "url": "/static/js/38.b15bb05f.chunk.js"
  },
  {
    "revision": "6c30d252f38c2c0445a9",
    "url": "/static/js/4.67805fe9.chunk.js"
  },
  {
    "revision": "308b8b2803c89b0f817d",
    "url": "/static/js/5.c831a882.chunk.js"
  },
  {
    "revision": "1a86327692a3a419eb9f",
    "url": "/static/js/6.f057dc33.chunk.js"
  },
  {
    "revision": "a5a66b2256e249a2770d",
    "url": "/static/js/7.ae0f6289.chunk.js"
  },
  {
    "revision": "ad26405113503ef86d15",
    "url": "/static/js/8.a3e16a94.chunk.js"
  },
  {
    "revision": "c0e436c0b1bab4b9a7b3",
    "url": "/static/js/9.7cfd38e7.chunk.js"
  },
  {
    "revision": "5fdf93eb07cc415326d8",
    "url": "/static/js/main.6cbbaff8.chunk.js"
  },
  {
    "revision": "17de0e29e55c549ddc41",
    "url": "/static/js/runtime~main.a9fe0780.js"
  },
  {
    "revision": "b988be48ccc19979ea6a27433ccabf1e",
    "url": "/static/media/Gigzzy.b988be48.png"
  },
  {
    "revision": "3e2074676586b45449dcf05cdca01ca6",
    "url": "/static/media/bookLater.3e207467.png"
  },
  {
    "revision": "ffbc2894f77a527feb876c97335d504a",
    "url": "/static/media/gigzzypro.ffbc2894.png"
  },
  {
    "revision": "b01d3874df5e40b2d6a44a50e52b8231",
    "url": "/static/media/handyman.b01d3874.jpg"
  },
  {
    "revision": "f5f904a6806a0db8497d0dfe9f70bc4f",
    "url": "/static/media/handyman2.f5f904a6.jpg"
  },
  {
    "revision": "c0ffe352c874081526f4348ef1888631",
    "url": "/static/media/handyman3.c0ffe352.jpg"
  },
  {
    "revision": "6b0de07fc3c8996c2057d52b27f2bd80",
    "url": "/static/media/howcustomer.6b0de07f.jpg"
  },
  {
    "revision": "99747bdfd46a97cd676958a9bb05d806",
    "url": "/static/media/howprovider.99747bdf.jpg"
  },
  {
    "revision": "c57228a882cbf3bfe440b15d20efd7ce",
    "url": "/static/media/main.c57228a8.png"
  },
  {
    "revision": "18a5790cc74efc767c66c5ab482e134c",
    "url": "/static/media/mpesa_logo.18a5790c.png"
  },
  {
    "revision": "cf173470f3d4490e5936219f2d1d589d",
    "url": "/static/media/no_booking.cf173470.png"
  },
  {
    "revision": "27ec6daccf8d94ff6c16fa1b1bd7b28b",
    "url": "/static/media/sac.27ec6dac.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/static/media/slick.f97e3bbf.svg"
  },
  {
    "revision": "186dbce6ef367c3e0f5c38519c4d8ca4",
    "url": "/static/media/test.186dbce6.png"
  }
]);